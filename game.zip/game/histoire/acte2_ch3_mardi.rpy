## Acte II — chapitre 3 : lundi 20 (les partiels) et mardi 21 (le chantage).
##
## Six créneaux sur la carte, du lundi après-midi au mardi soir. Les pistes du
## week-end pointaient vers Halvard ; celles-ci pointent vers Ferrière. Mardi
## soir, Halvard avoue et propose sa protection : l'accepter ferme la porte du
## gala (Fin 8, « Le prix d'une bourse »).

default note_partiels = None

define CRENEAUX3 = [
    (15, "après-midi", "LUNDI · 14 H 00"),
    (15, "soir", "LUNDI · 19 H 00"),
    (15, "nuit", "LUNDI · 23 H 00"),
    (16, "matin", "MARDI · 09 H 00"),
    (16, "après-midi", "MARDI · 14 H 00"),
    (16, "soir", "MARDI · 18 H 00"),
]

init 1 python:

    PREUVES.update({
        "main_courante": dict(
            nom="Main courante du commissariat",
            image="preuves/main_courante.png",
            desc="Registre de la garde à vue, nuit du 16 au 17 octobre. Recopié par Malo depuis la sauvegarde informatique.",
            detail="« 21 h 35 — visite du commissaire divisionnaire, cellule 3, pour s'assurer du confort de la gardée à vue. Un gobelet d'eau. » Sur le registre papier, la ligne a été raturée.",
        ),
        "requisitions": dict(
            nom="Réquisitions de la capitainerie",
            image="preuves/requisitions.png",
            desc="Toutes les levées d'inspection de l'Ondine depuis 2016. Chaque réquisition porte le même matricule : 0417.",
            detail="0417 est le matricule du commissaire divisionnaire Paul Ferrière. Il signe lui-même, depuis huit ans.",
        ),
        "lettres_c": dict(
            nom="Lettres du Capitaine",
            image="preuves/lettres_c.png",
            desc="Douze ans de lettres de chantage reçues par Henri Halvard, tapées à la machine, signées « C. ».",
            detail="L'une d'elles est tapée au dos d'un papier à en-tête du commissariat central, mal découpé. On lit encore « …ARIAT CENTRAL — CABINET DU DIVI… ».",
        ),
        "temoignage_eleonore": dict(
            nom="Ardoise d'Éléonore",
            image="preuves/ardoise.png",
            desc="Réveillée mardi, intubée, Éléonore Lambert a écrit trois mots sur une ardoise devant Malo et un médecin.",
            detail="« FERRIÈRE. L'EAU. CAPITAINE. » Le médecin a signé et daté l'ardoise.",
        ),
    })

    def lieux_acte2b():
        j, mo = store.jour, store.moment
        L = []
        if j == 16 and mo == "matin":
            L.append(("b2_cours", "Aller en cours", "images/bg/bg classe.jpg", "Les résultats des partiels tombent ce matin.", True))
        L.append(("b2_hopital", "Hôpital", "images/bg/bg hopital.jpg",
                  "Éléonore. Et la question de qui la garde." if mo != "nuit" else "Visites terminées.", mo != "nuit"))
        cap_ok = mo in ("matin", "après-midi")
        L.append(("b2_capitainerie", "Capitainerie du port", "images/bg/bg capitainerie.jpg",
                  "Les archives des réquisitions." if cap_ok else "Ouverte en journée.", cap_ok))
        L.append(("b2_commissariat", "Commissariat", "images/bg/bg commissariat.jpg",
                  "Malo, et les oreilles dans les murs." if mo != "nuit" else "Malo est de garde de nuit. Seul.", True))
        L.append(("b2_redaction", "Café du port — la Gazette", "images/bg/bg redaction.jpg",
                  "Préparer le gala de mercredi." if mo != "nuit" else "Fermé.", mo != "nuit"))
        L.append(("b2_toit", "Le toit", "images/bg/bg toit.jpg", "Clara y dessine le soir. Iris y boit des cafés sans goût.", mo in ("soir", "nuit", "après-midi")))
        biblio_ok = mo != "nuit" or possede("marque_page")
        L.append(("b2_bibliotheque", "Bibliothèque", "images/bg/bg bibliotheque.jpg",
                  "Mme Bernier. Relire tout le dossier." if mo != "nuit" else ("Le marque-page est tiède…" if biblio_ok else "Fermée la nuit."), biblio_ok))
        L.append(("b2_chambre", "Chambre", "images/bg/bg chambre.jpg", "Dormir, appeler la maison, préparer le gala.", True))
        return L

    def pistes_acte2b():
        P = []
        if not fait("malo_allie"):
            P.append(("Commissariat", "Malo doute. Il faudrait le convaincre qu'il ne trahit personne en cherchant."))
        elif not a("main_courante"):
            P.append(("Commissariat", "Malo cherche le registre de la garde à vue. Qui est descendu aux cellules, ce soir-là ?"))
        if not a("requisitions"):
            P.append(("Capitainerie", "Quelqu'un signe les levées d'inspection de l'Ondine. Les archives gardent les signatures."))
        if not a("temoignage_eleonore"):
            P.append(("Hôpital", "Si Éléonore se réveille, il faudra qu'un policier de confiance soit là avant les autres."))
        if not fait("invitations_gala"):
            P.append(("Café du port", "Le gala est sur invitation. Il faut trouver comment entrer."))
        if not fait("clara_reve"):
            P.append(("Le toit", "Clara a dit qu'elle faisait des rêves bizarres. Des rêves de parloir."))
        if fatigue():
            P.append(("Chambre", "Je dors debout. Le gala demandera toute ma tête."))
        return P[:5]


################################################################################
## Lundi 20 — les partiels
################################################################################

label acte2_partiels:
    $ echeance_carte = "avant le gala"
    scene bg classe eleves with fondu
    $ poser_heure("LUNDI · 08 H 00")
    narrator "Quatre heures d'épreuve. Droit des obligations, puis une dissertation."
    narrator "Le sujet de la dissertation tient en une ligne au tableau : {i}« Le secret est-il compatible avec la justice ? »{/i}"
    pensee "Il y a des jours où l'univers a un sens de l'humour très particulier."
    menu:
        "Écrire sur les secrets qui protègent : celui du médecin, de l'avocat, de la source d'un journaliste.":
            $ bon_plan = True
            narrator "J'écris sur Amélie sans la nommer. Sur Iris qui ne donne jamais ses sources. Sur ce qu'on doit taire pour pouvoir dire le reste."
        "Écrire sur les secrets qui tuent : ceux des institutions qui se protègent.":
            $ bon_plan = True
            narrator "J'écris sur une Académie sans la nommer. Sur un commissariat sans le nommer. L'encre va plus vite que ma prudence."
        "Écrire tout ce qui me passe par la tête.":
            $ bon_plan = False
            narrator "J'écris beaucoup. Trop. À la troisième page, je ne sais plus ce que je défends."
    python:
        note_partiels = 6 + 3 * min(revisions_partiels, 4)
        if bon_plan:
            note_partiels += 2
        if energie >= 5:
            note_partiels += 2
        elif energie <= 2:
            note_partiels -= 2
        if filiere == "droit":
            note_partiels += 1
        note_partiels = max(4, min(18, note_partiels))
    $ souvenir("Partiels de mi-semestre. « Le secret est-il compatible avec la justice ? »", None, "bg classe eleves")
    $ cocher("partiels")
    $ varier(energie=-2)

    ############################################################################
    ## Midi — le commissaire à l'Académie
    ############################################################################
    scene bg cantine with fondu
    $ poser_heure("LUNDI · 12 H 40")
    $ musique_jouer("mystere")
    narrator "À la sortie des partiels, un attroupement devant la cantine. Le commissaire Ferrière est venu « rassurer les étudiants ». Il serre des mains, il sourit, il rassure."
    show ferriere normal at centre with fondu
    if fait("une_capitaine"):
        narrator "Il tient à la main un exemplaire de « [gazette_nom] », plié en quatre. Il me voit. Il vient vers moi."
        fe "« Qui est le Capitaine ? » Belle question. Les belles questions ont parfois de vilaines réponses, vous savez."
        fe "Je dis ça en grand-père. Les jeunes gens qui jouent aux journalistes finissent parfois par tomber de haut."
        fe "Votre mère travaille de nuit à la blanchisserie de l'hôpital de Saint-Aubin, je crois ? Un métier pénible. Il faut lui épargner les soucis."
        narrator "Il le dit avec douceur. Il me tapote l'épaule. Il s'en va."
        pensee "Je n'ai jamais parlé de Maman à la police. Jamais."
        $ noter("menace_ferriere")
        $ varier(moral=-2)
    elif fait("une_azur"):
        fe "« L'Azur n'est pas mort. » Excellente initiative de prévention. Je l'ai dit au préfet."
        fe "Qui vous a renseignés sur les ventes de la rentrée, au fait ? Il faudrait que mes hommes l'entendent. Pour sa sécurité."
        menu:
            "« Nos sources restent nos sources. »":
                fe "Évidemment. Le secret des sources. On vous l'apprend en première année, maintenant ?"
                narrator "Il sourit encore. Mais pendant une seconde, ses yeux ne sourient plus."
            "« Hugo, un étudiant hospitalisé. »":
                fe "Merci. Je lui enverrai quelqu'un. Quelqu'un de bien."
                pensee "Pourquoi est-ce que cette phrase me glace ?"
                $ noter("hugo_donne")
    else:
        fe "On m'a dit que vous écriviez un journal, avec vos amis. Je ne vois rien paraître. C'est sage."
        fe "Les écrits restent. Les gens, eux, passent."
    if fait("chevaliere_vue") or "photo_gala" in preuves_examinees:
        narrator "Quand il serre la main du doyen, la chevalière accroche la lumière. Une ancre, gravée dans l'or."
    hide ferriere with fondu
    $ souvenir("Le commissaire Ferrière est venu « rassurer » les étudiants.", "ferriere normal", "bg cantine")

    $ creneau3_idx = 0
    jump acte2_carte3

default creneau3_idx = 0

label acte2_carte3:
    if creneau3_idx >= len(CRENEAUX3):
        call acte2_toit_declaration
        call resume_jour("Mardi")
        jump acte2_gala

    $ jour, moment, _h = CRENEAUX3[creneau3_idx]
    $ actions_restantes = len(CRENEAUX3) - creneau3_idx

    if creneau3_idx == 1:
        call acte2_malo_soir
    if creneau3_idx == 3:
        $ jour = 15
        call resume_jour("Lundi")
        $ jour = 16
        call acte2_mardi_reveil
    if creneau3_idx == 5:
        call acte2_halvard_aveu
        if fait("protection_halvard"):
            jump fin_prix_bourse

    $ poser_heure(_h)
    $ musique_jouer("enquete")
    if creneau3_idx == 0:
        pensee "Mercredi soir, le gala de la Fondation. Tout Valcourt. Et Ferrière y sera décoré pour « le démantèlement du réseau Azur »."
        pensee "Il me reste six moments pour trouver de quoi le faire tomber devant tout le monde."
    elif moment == "nuit":
        pensee "Minuit approche. Dormir, ou aller voir Malo pendant qu'il est seul ?"
    window hide
    $ lieu = renpy.call_screen("carte_enquete", lieux=lieux_acte2b())

    if moment == "nuit" and lieu != "b2_chambre":
        $ dormi_cette_nuit = False
    call expression lieu

    if moment == "nuit":
        if dormi_cette_nuit:
            $ energie = borner(energie + 5)
        else:
            $ nuits_blanches += 1
            $ varier(energie=-2, moral=-1)
        $ dormi_cette_nuit = False
        $ cafes_du_jour = 0

    $ creneau3_idx += 1
    jump acte2_carte3


################################################################################
## Événements imposés
################################################################################

label acte2_malo_soir:
    scene bg redaction with fondu
    $ poser_heure("LUNDI · 19 H 00")
    $ musique_jouer("tension")
    if fait("malo_reconnait"):
        narrator "Malo entre dans l'arrière-salle du café sans frapper. Il a les yeux de quelqu'un qui n'a pas dormi depuis jeudi."
        show malo souci at centre with fondu
        m "J'ai vérifié. La bague. C'est la sienne. Ferrière."
        m "Au port, les vieux l'appellent « le Capitaine ». Je croyais que c'était affectueux."
        m "Parce qu'il a fait partir plus de bateaux que n'importe quel capitaine, sans jamais monter sur un seul."
        if a("carnet_pere"):
            pensee "« Le Capitaine n'est pas un marin. Il ne monte jamais à bord. » Papa l'avait écrit en 2018."
        m determine "Il m'a appris le métier. Il m'a appris à boire du café froid. Et il a fait empoisonner une femme dans ma garde à vue."
        m "Je suis avec vous. Pas avec lui. Plus jamais avec lui."
        $ noter("malo_allie")
        $ lien("malo", 2)
        $ souvenir("Malo a reconnu la bague. Le Capitaine, c'est le commissaire Ferrière.", "malo determine", "bg redaction")
        hide malo with fondu
    elif fait("malo_doute") and niveau("malo") >= 6:
        $ son("vibreur")
        narrator "Un message de Malo, sans ponctuation, comme toujours quand il est nerveux."
        call sms("Malo", [("malo", "les registres des cellules ont une sauvegarde informatique"), ("malo", "je regarde cette nuit"), ("malo", "si j'ai raison je ne suis plus flic demain. si j'ai tort non plus")], "Lundi, 19:02")
        $ noter("malo_allie")
        $ lien("malo", 1)
    else:
        $ son("vibreur")
        call sms("Malo", [("malo", "Je ne peux plus t'aider. On m'a mis aux archives."), ("malo", "Fais attention.")], "Lundi, 19:02")
        pensee "Il est seul, aux archives, avec ses doutes. Il faudrait lui montrer de quoi les changer en certitudes."
    return

label acte2_mardi_reveil:
    call titre(9, "Mardi", "21 octobre", "Le chantage")
    scene bg classe with fondu
    $ poser_heure("MARDI · 08 H 30")
    $ cafes_du_jour = 0
    $ musique_jouer("quotidien")
    narrator "Les résultats des partiels sont affichés dans le hall. Une foule, des cris, des silences."
    narrator "Je cherche mon nom. Je le trouve. {b}[note_partiels]/20.{/b}"
    if note_partiels >= 12:
        pensee "Je respire. Même en poursuivant un Capitaine, j'ai tenu."
        $ varier(etudes=1, moral=1)
    elif note_partiels <= 8:
        pensee "Le chiffre me tombe dessus comme une gifle. Maman. La bourse. « Ne gâche pas ça. »"
        $ varier(etudes=-2, moral=-1)
    else:
        pensee "Ni bien ni mal. Un chiffre qui ne dit rien de la semaine que j'ai vécue."
    $ souvenir("Partiels : %d/20." % note_partiels, None, "bg classe")
    if bourse_en_danger():
        narrator "Un courriel de la Fondation : {i}« Le conseil des bourses, présidé par M. Henri Halvard, examinera votre dossier mercredi soir, en marge du gala. Moyenne actuelle : [moyenne()]/20. »{/i}"
        $ recevoir("Fondation de Valcourt", "Conseil des bourses mercredi soir. Votre dossier sera examiné.", "Mar. 08:31")
        $ noter("bourse_menacee")
        pensee "Présidé par Henri Halvard. Évidemment."
    show dorian normal at centre with fondu
    d "[joueur_nom]. Un mot."
    d "Ma sœur m'a laissé ses invitations pour le gala de demain. Elle ne veut plus mettre les pieds à la Fondation. Moi, je dois y aller : je siège au conseil."
    d pensif "Je ne sais pas ce que vous préparez, vous et vos amis du café du port. Je ne veux pas le savoir. Je suis professeur, je n'ai rien vu."
    d "Mais si vous préparez quelque chose, préparez-le bien. On n'accuse pas un homme puissant en public deux fois."
    narrator "Il pose quatre cartons dorés sur la table et s'en va."
    $ noter("invitations_gala")
    $ lien("dorian", 1)
    hide dorian with fondu
    call acte2_trahison
    return

label acte2_halvard_aveu:
    scene bg villa nuit with noir
    $ poser_heure("MARDI · 18 H 00")
    $ musique_jouer("mystere")
    $ ambiance("pluie")
    narrator "À dix-sept heures, un chauffeur en livrée m'attendait devant la résidence. « Monsieur Halvard souhaite vous voir. Seul{g=/e}. »"
    narrator "La villa, à la tombée de la nuit. Pas de majordome, cette fois. Halvard m'ouvre lui-même, en pull, sans manteau d'armateur. Il a l'air plus petit."
    show halvard normal at centre with fondu
    hal "Asseyez-vous. Je vais vous dire une chose que je n'ai dite à personne en douze ans."
    hal "En 2014, Halvard Maritime était en faillite. Trois bateaux sur quatre à quai, cent vingt employés. Un homme est venu me voir. Il signait « C. »"
    hal "Il m'a proposé de « protéger » ma compagnie. Un bateau par semaine, l'Ondine, sans questions. En échange, plus de contrôles, plus de procès, plus de banquiers."
    hal "J'ai dit oui. J'ai sauvé cent vingt emplois. Et je suis devenu le paravent de quelqu'un dont je ne connaissais même pas le visage."
    if fait("verite_papa") or fait("article_2018"):
        hal "En 2018, un docker est venu me voir. Il avait ouvert une caisse de l'Ondine. Il voulait que je parle avec lui à la police."
        hal "Je lui ai dit d'attendre. Le lendemain, un conteneur."
        if fait("verite_papa"):
            pensee "Papa."
            narrator "Je n'arrive pas à parler. Halvard voit quelque chose sur mon visage. Il ne demande pas quoi. Il baisse les yeux, comme sur la photo du gala."
            $ varier(moral=-1)
            $ noter("halvard_papa")
    if fait("une_capitaine"):
        hal "Votre petit journal. Votre « Qui est le Capitaine ? »… Il l'a lu, lui aussi. Ce matin, j'ai reçu une nouvelle lettre."
    elif fait("une_azur"):
        hal "Votre petit journal sur l'Azur… Il l'a lu, lui aussi. Ce matin, j'ai reçu une nouvelle lettre."
    else:
        hal "Vous posez des questions partout. Au port, à l'hôpital, chez moi. Il le sait. Ce matin, j'ai reçu une nouvelle lettre."
    hal "Il veut vos noms. Ceux de la rédaction. Et il veut que la Gazette ne reparaisse jamais."
    hal "Alors voici ce que je vous propose."
    hal "Votre bourse, garantie jusqu'au diplôme, quelles que soient vos notes. Celles de vos amis aussi. Je paierai ce qu'il faudra au Capitaine pour qu'il vous oublie."
    hal "Vous arrêtez tout. Demain, vous venez au gala, vous applaudissez, vous rentrez chez vous. Et vous vivez."
    if fait("bourse_menacee"):
        pensee "Ma bourse est examinée demain soir. Par lui."
    if fait("menace_ferriere"):
        pensee "« Votre mère travaille de nuit à Saint-Aubin. » Halvard pourrait la mettre à l'abri. Lui, il le pourrait."
    pensee "Iris disait que tout le monde finit par proposer un marché. Isabella, la semaine dernière. Halvard, ce soir."
    menu:
        "Accepter la protection d'Halvard.":
            $ noter("protection_halvard")
            $ souvenir("J'ai accepté la protection d'Henri Halvard.", "halvard normal", "bg villa nuit")
            hal "Vous êtes plus sage que moi à votre âge. C'est peut-être une mauvaise nouvelle pour vous."
            hide halvard with fondu
            $ ambiance(None)
            return
        "Refuser, et lui demander de témoigner.":
            moi "Non. Vous avez dit oui il y a douze ans. Regardez où ça vous a mené. Où ça a mené ce docker."
            moi "Demain, au gala, dites la vérité. Avec nous."
            hal "Vous ne savez pas ce que vous me demandez."
            moi "Si. Je vous demande de faire ce que vous auriez dû faire en 2018."
            narrator "Il se lève. Il va jusqu'à un coffre dans le mur, l'ouvre, en sort une liasse de lettres entourée d'un élastique."
            hal "Douze ans. Je les ai toutes gardées, sauf celles que j'ai brûlées samedi, quand j'ai eu peur. Je n'ai jamais eu le courage de les lire jusqu'au bout."
            $ obtenir("lettres_c")
            hal "Demain, je parlerai. Si vous lui faites assez peur pour qu'il ne puisse plus rien contre moi. Sinon, je me tairai, et je coulerai avec vous."
            $ noter("halvard_temoin")
            $ souvenir("Henri Halvard m'a donné douze ans de lettres de chantage signées « C. ».", "halvard normal", "bg villa nuit")
    hide halvard with fondu
    $ ambiance(None)
    return


################################################################################
## Les lieux (lundi et mardi)
################################################################################

label b2_cours:
    scene bg classe eleves with fondu
    $ musique_jouer("quotidien")
    narrator "Correction collective de la dissertation. Le professeur lit une copie anonyme à voix haute, « pour l'exemple »."
    narrator "C'est la mienne. Je reconnais mes phrases. Personne ne sait que c'est moi. Quelqu'un au fond applaudit."
    $ varier(etudes=1, moral=1, energie=-1)
    return

label b2_hopital:
    scene bg hopital with fondu
    $ musique_jouer("mystere")
    $ n = visite("hopital3")
    if jour == 15:
        narrator "Hugo est sorti ce matin. Il m'a laissé un mot à l'accueil : {i}« Je te dois une partie de cartes. Sans tricher. Enfin, presque. »{/i}"
        narrator "Devant la chambre 12, le policier de garde a changé. Celui-là ne fume pas. Il ne lit pas. Il regarde tout le monde."
        if fait("malo_allie"):
            pensee "Il faudrait que Malo mette quelqu'un à lui devant cette porte. Avant que quelqu'un d'autre ne vienne « s'occuper de ses gens »."
            narrator "J'appelle Malo depuis le couloir. Il jure, longuement, puis : « J'envoie Benoît. Il me doit trois ans de cafés. »"
            $ noter("eleonore_protegee")
        else:
            pensee "Un policier qui ne quitte pas la porte des yeux. Pour la protéger, ou pour la surveiller ?"
        $ varier(energie=-1)
        return
    ## Mardi
    if fait("eleonore_protegee") or fait("malo_allie"):
        scene bg hopital chambre with fondu
        show malo souci at gauche with fondu
        show eleonore normal at droite with fondu
        narrator "Malo est là, assis au chevet. Et Éléonore Lambert a les yeux ouverts."
        m "Réveillée cette nuit. Intubée, elle ne peut pas parler. Mais elle entend. Et elle écrit."
        narrator "Un médecin tient une ardoise blanche. Éléonore prend le feutre. Sa main tremble tellement que chaque lettre lui coûte."
        narrator "{b}FERRIÈRE.{/b}"
        narrator "{b}L'EAU.{/b}"
        narrator "{b}CAPITAINE.{/b}"
        narrator "Puis elle lâche le feutre et ferme les yeux. Une larme roule vers son oreille."
        m "Le docteur signe, je signe, tu signes. Trois témoins. Personne ne pourra dire qu'on l'a inventé."
        $ obtenir("temoignage_eleonore")
        $ souvenir("Éléonore s'est réveillée. Sur une ardoise : « Ferrière. L'eau. Capitaine. »", "eleonore normal", "bg hopital chambre")
        hide malo
        hide eleonore
        with fondu
    else:
        scene bg hopital with fondu
        narrator "On me dit qu'Éléonore s'est réveillée cette nuit. On me dit aussi que les visites sont interdites « sur ordre du commissariat central »."
        narrator "À travers la vitre, je la vois. Elle me voit. Elle secoue la tête, très lentement. {i}Non. Pas ici. Pas avec eux.{/i}"
        pensee "Sans quelqu'un de confiance à cette porte, elle ne dira jamais rien."
    $ varier(energie=-1)
    return

label b2_capitainerie:
    scene bg capitainerie with fondu
    $ ambiance("port")
    $ musique_jouer("enquete")
    $ acces = a("capitainerie") or filiere == "droit" or possede("carte_presse") or temperament == "audacieux" or fait("malo_allie")
    if not acces:
        employe_port "Encore vous ? Les archives des réquisitions, c'est encore moins public que les registres."
        $ noter("capitainerie_refus")
        $ varier(energie=-1)
        $ ambiance(None)
        return
    if a("requisitions"):
        narrator "L'agent me fait un signe de la main sans lever la tête : il a déjà tout dit. Sur le quai, l'Ondine attend toujours, toute bleue."
        $ ambiance(None)
        return
    narrator "Les archives sont au sous-sol, dans des boîtes en carton gondolées par l'humidité. L'agent me laisse seul{g=/e} une heure, « pour sa santé mentale »."
    narrator "Je cherche l'Ondine. Je trouve quatre cents réquisitions. Toutes sur le même formulaire du commissariat central."
    narrator "Toutes avec le même matricule, en bas à droite. {b}0417{/b}."
    $ obtenir("requisitions")
    if fait("malo_allie") or filiere == "droit":
        if filiere == "droit":
            pensee "Les matricules des officiers signataires sont publiés au recueil des actes administratifs. Dorian nous l'a fait consulter en TD."
        else:
            narrator "J'envoie une photo à Malo. La réponse arrive en quarante secondes."
            call sms("Malo", [("malo", "0417"), ("malo", "c'est lui")], "")
        narrator "0417 : commissaire divisionnaire Paul Ferrière. Huit ans de signatures. De sa propre main."
        $ examiner("requisitions")
        $ souvenir("Quatre cents réquisitions, un seul matricule : 0417. Ferrière.", None, "bg capitainerie")
    else:
        pensee "0417. Un matricule. Il me faudrait quelqu'un, dans la police, pour me dire à qui il appartient."
    $ varier(energie=-1)
    $ ambiance(None)
    return

label b2_commissariat:
    if moment == "nuit":
        scene bg commissariat with fondu
        $ musique_jouer("tension")
        $ poser_heure("LUNDI · 23 H 40")
        show malo fatigue at centre with fondu
        if fait("malo_allie") and not a("main_courante"):
            narrator "Le commissariat, la nuit. Une seule lampe allumée, au bout du couloir. Malo, devant un ordinateur des archives."
            m "La sauvegarde informatique de la garde à vue. Le registre papier, quelqu'un l'a raturé. L'ordinateur, personne n'a pensé à lui."
            m "Regarde. Nuit du 16. Vingt et une heures trente-cinq."
            narrator "{i}« Visite du commissaire divisionnaire, cellule 3. Motif : s'assurer du confort de la gardée à vue. Un gobelet d'eau. »{/i}"
            m "Un gobelet d'eau. Le toxico dit : ingestion entre vingt et une heures et vingt-deux heures."
            m triste "Il est descendu lui-même. Il ne délègue jamais rien, le patron. C'est ce que j'admirais le plus chez lui."
            $ obtenir("main_courante")
            $ examiner("main_courante")
            $ souvenir("Nuit du 16, 21 h 35 : Ferrière est descendu en cellule avec un gobelet d'eau.", "malo triste", "bg commissariat")
            $ lien("malo", 1)
        elif not fait("malo_allie"):
            narrator "Malo est de garde de nuit, seul. Il sursaute en me voyant."
            call b2_convaincre_malo
        else:
            m "On a ce qu'il faut. Va dormir. Demain, il faudra que tu tiennes debout devant tout Valcourt."
        hide malo with fondu
        $ varier(energie=-1)
        return
    scene bg commissariat with fondu
    $ musique_jouer("enquete")
    show malo normal at centre with fondu
    if not fait("malo_allie"):
        m "Pas ici. Pas de jour. Il y a des oreilles dans les murs."
        call b2_convaincre_malo
    elif not a("main_courante"):
        m "Je ne peux pas sortir les registres de jour. Reviens ce soir. Tard. Quand il ne reste que moi."
        if fait("malo_reconnait") and jour == 16:
            m "…Non. Tant pis. Tiens. Je l'ai imprimée ce matin, à six heures, en tremblant comme un voleur."
            $ obtenir("main_courante")
            $ examiner("main_courante")
    else:
        m "Le gala est demain. Tu as tout ? Montre-moi ce que tu comptes dire. Non. Ne me montre pas. Je veux être surpris, comme les autres."
        $ lien("malo", 1)
    hide malo with fondu
    $ varier(energie=-1)
    return

label b2_convaincre_malo:
    ## Malo hésite : il faut lui donner de quoi ne plus pouvoir détourner les yeux.
    $ poids = sum(1 for p in ("capitainerie", "toxico", "photo_gala", "carnet_pere", "lettre_brulee", "requisitions") if a(p))
    $ poids += (1 if "photo_gala" in preuves_examinees else 0) + (1 if fait("cambriolage_iris") else 0) + (1 if fait("menace_ferriere") else 0)
    narrator "Je pose sur son bureau tout ce que j'ai. Une pièce après l'autre."
    if poids >= 3 or niveau("malo") >= 8:
        m "Arrête. Arrête, j'ai compris."
        m souci "Le central. Les réquisitions. La garde à vue. Il n'y a qu'un homme qui touche aux trois."
        m determine "Je suis avec vous. Que Dieu me pardonne, ou que les syndicats me pardonnent, je ne sais plus lequel est le plus dur."
        $ noter("malo_allie")
        $ lien("malo", 2)
    else:
        m "Des coïncidences. Des tampons, des rumeurs. Avec ça, devant un juge, c'est moi qu'on suspend."
        m "Apporte-moi quelque chose qui ne s'explique pas autrement. Et vite."
    return

label b2_redaction:
    scene bg redaction with fondu
    $ musique_jouer("enquete")
    $ n = visite("redaction_b")
    show iris normal at gauche with fondu
    show amelie normal at droite with fondu
    if n == 1:
        narrator "Le mur du café a changé. Au milieu de la feuille blanche, sous le point d'interrogation, Amélie a punaisé une photo du commissaire Ferrière découpée dans le journal officiel."
        if not fait("invitations_gala"):
            am "Le gala est sur invitation. Trois cents personnes, toutes triées sur le volet. Nous, on n'est sur aucun volet."
            if possede("carte_presse") or filiere == "lettres":
                am "Sauf si… La presse est invitée. Pas la nôtre. Mais un badge de presse, ça s'imprime."
                $ noter("invitations_gala")
            else:
                ir "On trouvera. Il y a toujours une porte de service."
        ir "Le plan est simple. Ferrière reçoit sa médaille à vingt et une heures. Il fera un discours. Et quand il aura fini, quelqu'un posera une question."
        ir "Toi."
        moi "Pourquoi moi ?"
        ir "Parce que moi, il m'a déjà tuée une fois. Dans une autre boucle. Je ne veux pas lui donner l'occasion de recommencer."
        am "Et parce que tu as une tête qu'on a envie de croire. C'est injuste, mais c'est comme ça."
        $ noter("plan_gala")
    else:
        narrator "On répète. Amélie joue Ferrière, avec une moustache dessinée au feutre. Elle est très, très mauvaise. Iris rit pour la première fois depuis jeudi."
        ir "Il va nier. Il niera chaque pièce, une par une, en souriant. Il faudra que chaque pièce réponde à un mensonge précis."
        ir "Pas tout jeter d'un coup. Une à la fois. Comme au tribunal, la semaine… la semaine qui n'a pas eu lieu."
        $ noter("repetition_gala")
        $ lien("iris", 1)
        $ lien("amelie", 1)
    hide iris
    hide amelie
    with fondu
    $ varier(energie=-1)
    return

label b2_toit:
    scene bg toit with fondu
    $ musique_jouer("clara")
    if not fait("clara_reve"):
        show clara pensif at centre with fondu
        narrator "Clara dessine le port au crépuscule. Elle ne m'entend pas arriver. Elle sursaute quand je m'assois à côté d'elle."
        c "Je fais des rêves bizarres, depuis jeudi. Toujours le même."
        c "Je suis dans une petite pièce grise, avec une vitre. Tu es de l'autre côté. Tu as l'air très triste, et tu me promets quelque chose."
        c "Je n'ai jamais été dans une pièce comme ça. Pourtant, je pourrais la dessiner les yeux fermés."
        narrator "Elle me montre le carnet. C'est le parloir. Exactement le parloir, jusqu'à la fissure dans la vitre."
        pensee "Elle ne devrait pas s'en souvenir. Personne ne devrait s'en souvenir, sauf Iris et moi."
        menu:
            "Lui dire la vérité sur le Livre.":
                moi "Ce n'est pas un rêve, Clara. C'est arrivé. Dans une semaine qui n'existe plus."
                narrator "Je lui raconte. Le Livre, le mercredi, le parloir. Elle m'écoute sans m'interrompre, en dessinant."
                c "…Je te crois. Je ne sais pas pourquoi, mais je te crois. Peut-être parce que je me souviens de ta promesse."
                $ noter("clara_sait")
                $ lien("clara", 2)
            "Lui dire que ce n'est qu'un rêve.":
                moi "C'est juste un rêve. Tu as eu peur, cette semaine. Tout le monde a eu peur."
                c "Oui. Sûrement."
                narrator "Elle referme le carnet. Elle ne me croit pas. Elle a la politesse de faire semblant."
                $ lien("clara", 1)
        $ noter("clara_reve")
        $ souvenir("Clara a dessiné le parloir. Elle n'y est jamais allée, dans ce monde-ci.", "clara pensif", "bg toit")
        hide clara with fondu
    else:
        show iris normal at centre with fondu
        narrator "Iris est là, avec deux cafés, comme jeudi. Elle m'en tend un."
        ir "Raconte-moi ce que tu vois. En bas. Le port."
        moi "Les grues s'allument une par une. L'Ondine est toujours à quai, bleue même dans le noir. Un chat traverse le parking de la capitainerie."
        ir "Demain soir, si tout se passe bien, l'Ondine ne repartira jamais."
        ir "Et si tout se passe mal…"
        moi "Il n'y a pas de « si tout se passe mal »."
        ir "Il y en a toujours un. J'en ai vécu huit."
        $ lien("iris", 1)
        $ varier(moral=1)
        hide iris with fondu
    return

label b2_bibliotheque:
    if moment == "nuit":
        scene bg reserve with fondu
        show halo_or
        $ musique_jouer("boucle")
        narrator "Le Livre est ouvert sur la page de mon nom. L'encre a encore pâli. Les deux premières lettres ne sont plus qu'un souvenir de lettres."
        pensee "Je pense à Maman. À son anniversaire. Au gâteau. Je pense à Papa, à la photo sur le quai."
        pensee "Tout est là. Pour l'instant, tout est là."
        $ varier(moral=-1)
        hide halo_or
        return
    scene bg bibliotheque with fondu
    $ musique_jouer("quotidien")
    show bernier normal at centre with fondu
    ob "Vous avez la tête de quelqu'un qui prépare un procès. J'en ai vu passer, des têtes comme ça, à cette table."
    narrator "J'étale tout le dossier sur la grande table. Mme Bernier m'apporte une lampe et ne pose aucune question."
    python:
        for _c in preuves:
            examiner(_c)
    $ noter("dossier_relu")
    narrator "Je relis chaque pièce. Je cherche, pour chacune, le mensonge auquel elle répond."
    if possede("marque_page"):
        ob "Avant que vous partiez… Le Livre a été écrit par un homme qui s'appelait Aurèle. Aurèle de Valcourt. Il voulait sauver sa fille."
        ob "Je vous raconterai la fin quand vous aurez fini, vous. Une histoire à la fois."
        $ noter("aurele_nomme")
    hide bernier with fondu
    $ varier(energie=-1)
    return

label b2_chambre:
    if moment == "nuit":
        scene bg chambre nuit with fondu
    else:
        scene bg chambre with fondu
    $ musique_jouer("quotidien")
    menu:
        "Dormir." if moment == "nuit":
            narrator "Je dors. Je rêve d'un discours, d'une médaille, et d'un gobelet d'eau."
            $ dormi_cette_nuit = True
        "Faire une sieste." if moment != "nuit":
            narrator "Une heure de sommeil. C'est peu. C'est beaucoup, par les temps qui courent."
            $ varier(energie=3)
        "Appeler Maman.":
            mam "Allô ? Il est arrivé quelque chose ?"
            moi "Non. Je voulais juste entendre ta voix."
            mam "Ça, c'est quelque chose qui arrive. Ça n'arrive pas souvent."
            if fait("menace_ferriere"):
                moi "Maman… Si quelqu'un vient te poser des questions sur moi, au travail ou à la maison, tu appelles Maëlle. Tout de suite."
                mam "…D'accord. Je ne demande pas pourquoi. Je n'ai jamais demandé pourquoi à ton père non plus."
                $ noter("maman_prevenue")
            $ rencontrer("maman")
            $ varier(moral=2)
            if moment == "nuit":
                $ dormi_cette_nuit = True
        "Préparer ce que je dirai au gala.":
            narrator "J'écris sur une fiche ce que je dirai. Puis je déchire la fiche. Puis j'en écris une autre, plus courte."
            python:
                for _c in preuves:
                    examiner(_c)
            $ noter("dossier_relu")
            $ varier(energie=-1)
    return


################################################################################
## Fin 8 — Le prix d'une bourse
################################################################################

label fin_prix_bourse:
    $ code_fin_courant = "prix_bourse"
    scene bg bal with noir_long
    $ musique_jouer("tristesse")
    $ poser_heure("MERCREDI · 21 H 00")
    narrator "Mercredi soir, au gala de la Fondation, le commissaire Ferrière reçoit sa médaille sous les applaudissements."
    narrator "J'applaudis aussi. Halvard, au premier rang, ne se retourne pas une seule fois."
    narrator "La Gazette clandestine ne reparaît pas. Amélie m'a demandé pourquoi. Je n'ai pas su répondre. Elle a cessé de demander."
    if fait("bourse_menacee"):
        narrator "Ma bourse est maintenue « à titre exceptionnel ». Je garde la lettre dans un tiroir que je n'ouvre jamais."
    else:
        narrator "Ma bourse est garantie jusqu'au diplôme. Celle de Clara aussi. Elle ne sait pas pourquoi. Je ne lui dirai jamais."
    show iris normal at centre with fondu
    ir "Tu as fait ce que j'ai fait, la troisième fois. J'ai accepté, moi aussi. Je voulais vivre."
    ir "J'ai vécu. Six jours de plus. Puis le Capitaine a décidé que je savais trop de choses quand même."
    ir "Fais attention à toi, [joueur_nom]. Il n'oublie jamais personne."
    hide iris with fondu
    narrator "Le jeudi suivant, au quai 7, l'Ondine a repris la mer à vingt-trois heures. Sans inspection."
    narrator "Personne ne l'a regardée partir. Sauf moi, depuis le toit de l'Académie."
    call terminer("prix_bourse", 8, "Le Prix d'une bourse", "Il paie toujours, celui qui croit avoir acheté sa tranquillité.")
    return


################################################################################
## Départ de chapitre (tests et Extras)
################################################################################

label depart_lundi2:
    $ quick_menu = True
    $ noter("marque_page", "lettre_iris", "souvenirs", "iris_alliee", "malo_prevenu", "acte2", "iris_vivante", "capitaine_nomme",
            "eleonore_coma", "chevaliere_vue", "malo_ecarte", "malo_doute", "malo_reconnait", "hopital_visite", "halvard_vu", "halvard_peur",
            "une_capitaine", "livre_page_vue", "ondine_halvard", "jeudis_capitaine")
    $ donner("marque_page", silencieux=True)
    $ rencontrer("clara", "iris", "dorian", "isabella", "eleonore", "malo", "maelle", "amelie", "lucas", "hugo", "nathan", "bernier", "halvard", "ferriere", "maman")
    $ rel.update({"clara": 6, "malo": 8, "iris": 8, "amelie": 5, "isabella": 3, "dorian": 4})
    python:
        for _p in ("capitainerie", "toxico", "photo_gala"):
            obtenir(_p, silencieux=True)
        examiner("photo_gala")
    $ pages = 2
    $ boucle = 2
    $ acte = 2
    $ gazette_nom = "La Lanterne"
    $ revisions_partiels = 2
    $ argent = 24
    jump acte2_lundi
