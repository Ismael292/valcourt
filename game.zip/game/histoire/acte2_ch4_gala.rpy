## Acte II — chapitre 4 : le gala de la Fondation (mercredi 22 octobre).
##
## Une confrontation publique, sur le modèle de l'audience de l'Acte I : trois
## séries de déclarations de Ferrière, la patience de la salle à la place des
## marteaux du juge, puis la preuve qui le rattache « de sa main » au Capitaine.
## Fin 9 : il tombe, et l'histoire continue (le prix du Livre, puis l'Acte III).
## Fin 7 : il gagne, et le port engloutit tout.

init 1 python:

    TEMOIGNAGES.update({
        "ferriere_a": dict(
            temoin="Commissaire Ferrière",
            succes="ci_ferriere_a_brise",
            declarations=[
                dict(texte="Rongée par le remords, Éléonore Lambert a tenté de mettre fin à ses jours dans sa cellule.",
                     presser=[("fe", "Une tragédie. Elle avait dû cacher quelque chose sur elle. Les fouilles ne sont jamais parfaites.")],
                     preuves=("toxico",), contradiction=True),
                dict(texte="Cette nuit-là, personne n'est descendu aux cellules en dehors des rondes réglementaires.",
                     presser=[("fe", "Le registre de garde à vue en fait foi. Je l'ai relu moi-même, le lendemain.")],
                     preuves=("main_courante",), contradiction=True),
                dict(texte="Je ne suis, pour ma part, jamais entré dans cette cellule.",
                     presser=[("fe", "Un commissaire divisionnaire ne fait pas les rondes, mon jeune ami. Il a des gens pour ça.")],
                     preuves=("main_courante", "temoignage_eleonore"), contradiction=True),
            ]),
        "ferriere_b": dict(
            temoin="Commissaire Ferrière",
            succes="ci_ferriere_b_brise",
            declarations=[
                dict(texte="Le quai 7 a été fouillé dès que nous avons eu connaissance du registre de Mademoiselle Delaunay.",
                     presser=[("fe", "À l'aube, avec vingt hommes. Le hangar était vide. Les trafiquants sont prudents.")]),
                dict(texte="L'Ondine appartient à Monsieur Halvard. C'est à lui de répondre de ce qu'elle transporte.",
                     presser=[("fe", "Je ne fais qu'énoncer un fait. Monsieur Halvard est un ami de cette Fondation, mais la loi est la loi.")],
                     preuves=("lettres_c", "lettre_brulee"), contradiction=True),
                dict(texte="La police n'a jamais rien eu à voir avec les mouvements de ce navire.",
                     presser=[("fe", "Les bateaux, c'est l'affaire des douanes et de la capitainerie. Pas la mienne.")],
                     preuves=("capitainerie", "requisitions"), contradiction=True),
            ]),
        "ferriere_c": dict(
            temoin="Commissaire Ferrière",
            succes="ci_ferriere_c_brise",
            declarations=[
                dict(texte="Ce « Capitaine » est une légende de docker : un contrebandier des îles, un marin qui n'existe pas.",
                     presser=[("fe", "Chaque port a son fantôme. Le nôtre a une casquette et un bateau. C'est du folklore.")],
                     preuves=("carnet_pere",), contradiction=True),
                dict(texte="Je n'ai aucun lien personnel avec Monsieur Halvard. Nous nous croisons, une fois l'an, à ce gala.",
                     presser=[("fe", "Une poignée de main polie, une fois l'an. Rien de plus.")],
                     preuves=("photo_gala",), contradiction=True),
                dict(texte="Je signe des centaines de documents chaque année. Aucun ne concerne ce navire.",
                     presser=[("fe", "Vous pouvez vérifier. Je suis un homme de procédure.")],
                     preuves=("requisitions",), contradiction=True),
            ]),
    })

    PREUVES_DECISIVES_GALA = ("requisitions", "main_courante", "temoignage_eleonore", "lettres_c")

    def preuve_de_sa_main(code):
        """Une preuve qui rattache Ferrière lui-même au Capitaine, et pas seulement « la police »."""
        if code in ("main_courante", "temoignage_eleonore"):
            return True
        if code in ("requisitions", "lettres_c"):
            return code in store.preuves_examinees
        return False


label acte2_gala:
    $ jour = 17
    $ moment = "soir"
    $ cafes_du_jour = 0
    call titre(10, "Mercredi", "22 octobre", "Le gala")

    scene bg chambre with fondu
    $ poser_heure("MERCREDI · 18 H 00")
    $ musique_jouer("tension")
    narrator "Je repasse ma seule chemise blanche. Deux fois. La deuxième fois, je la brûle un peu. Personne ne verra."
    if possede("photo_pere"):
        narrator "Je glisse la photo de Papa dans ma poche intérieure. Contre le marque-page."
    if fait("menace_ferriere") and not fait("maman_prevenue"):
        pensee "« Votre mère travaille de nuit à Saint-Aubin. » Si ce soir rate, il saura où frapper."

    scene bg bal with fondu_long
    show poussiere
    $ poser_heure("MERCREDI · 20 H 00")
    $ ambiance("foule")
    narrator "Les lustres de la Fondation, le parquet ciré, trois cents invités en noir et or. Au fond, une estrade, un micro, une médaille dans un écrin de velours."
    if fait("invitations_gala"):
        narrator "Nous entrons par la grande porte, Iris, Clara, Amélie et moi, nos cartons dorés à la main. Personne ne nous regarde. C'est le but."
    else:
        narrator "Nous entrons par la porte de service, en veste blanche, un plateau à la main. Lucas fait des extras chez le traiteur : il nous a trouvé quatre tenues et aucune excuse."
        $ noter("gala_serveur")
    if fait("malo_allie"):
        narrator "Près de l'entrée, Malo, en civil, avec deux collègues qui ont l'air de ne jamais avoir porté de cravate. Il ne me regarde pas. C'est voulu."

    $ marteaux = marteaux_max()
    menu:
        "Avant le discours, je vais…"
        "Trouver Henri Halvard.":
            show halvard normal at centre with fondu
            if fait("halvard_temoin"):
                hal "Vous êtes venu{g=/e}. Je n'en étais pas sûr."
                hal "Je parlerai. Si vous tenez assez longtemps pour qu'il ait peur. Pas avant."
                $ noter("halvard_rassure")
            else:
                narrator "Halvard me voit, et regarde ailleurs. Il serre son verre si fort que ses jointures blanchissent."
            hide halvard with fondu
        "Aller saluer le commissaire Ferrière.":
            show ferriere sourire at centre with fondu
            fe "Tiens. Vous êtes venu{g=/e} applaudir ? C'est gentil. Les jeunes applaudissent si peu, de nos jours."
            if temperament == "audacieux":
                moi "Je suis venu{g=/e} voir l'Ondine partir. Ah non, c'est vrai. Elle ne part plus le jeudi."
                narrator "Une seconde. Une seule. Le sourire de Ferrière disparaît, puis revient, un peu trop large."
                pensee "Il a eu peur. Devant moi, il a eu peur."
                $ noter("ferriere_ebranle")
                $ marteaux += 1
            else:
                narrator "Il me tapote l'épaule, comme lundi. Sa chevalière brille sous les lustres."
            hide ferriere with fondu
        "Rester avec mes amis.":
            show clara peur at gauche_c with fondu
            show iris normal at droite_c with fondu
            c "Si tu trembles, regarde-moi. Je dessinerai ta tête. Elle sera très drôle, ça te détendra."
            ir "Une pièce à la fois. Un mensonge, une pièce. Tu sais faire."
            $ varier(moral=1)
            hide clara
            hide iris
            with fondu
    if fait("repetition_gala"):
        $ marteaux += 1
    if fait("lucas_double"):
        narrator "Lucas, en veste de serveur, passe près de moi avec un plateau. « Ils croient que tu vas accuser Halvard. Regarde. »"
        narrator "Ferrière ne regarde même pas de notre côté. Il surveille Halvard, et sourit d'avance."
        $ marteaux += 1
    if coeur and fait("declaration") and not (coeur == "lucas" and fait("lucas_chasse")):
        $ cnom = prenom_coeur(coeur)
        amour "Je suis là. Juste là, au troisième rang. Si tu doutes, cherche-moi des yeux."
        $ marteaux += 1
    if energie <= 2:
        narrator "Je n'ai pas assez dormi. Les lustres tournent un peu."
        $ marteaux -= 1
    if moral <= 2:
        narrator "Une petite voix me dit que personne ne croira un{g=/e} étudiant{g=/e} contre trente ans de service."
        $ marteaux -= 1
    $ marteaux = max(2, min(marteaux, marteaux_max()))

    ############################################################################
    ## 21 h — la médaille
    ############################################################################
    $ poser_heure("MERCREDI · 21 H 00")
    $ musique_jouer("mystere")
    show ferriere normal at centre with fondu
    narrator "Halvard remet la médaille. Ferrière la reçoit avec modestie, presque avec gêne. Les applaudissements durent longtemps."
    fe "Je ne suis qu'un vieux policier. Cette médaille appartient à mes hommes."
    fe "Le réseau Azur est tombé. Une femme, Éléonore Lambert, en était la tête. Rongée par le remords, elle a tenté de mettre fin à ses jours."
    fe "Valcourt peut dormir tranquille. Le port est propre."
    fe "Je crois qu'il y a des journalistes dans la salle. Des questions ?"
    narrator "Amélie me met le micro dans la main. Il est lourd. Bien plus lourd qu'un micro."
    hide ferriere with fondu
    $ ambiance(None)
    window hide
    $ accusation = saisie("Vous prenez le micro. Trois cents personnes se taisent. Que dites-vous ?",
                          "Nommez celui que vous accusez.")
    $ cible = comprendre(accusation, [("ferriere", ["ferriere", "commissaire", "paul", "capitaine", "vous"]),
                                      ("halvard", ["halvard", "armateur", "henri"])])
    if cible is None:
        narrator "Ma voix sort, mais pas les mots. Il y a un silence. Quelqu'un tousse."
        pensee "Respire. Dis son nom. Juste son nom."
        window hide
        $ accusation = saisie("Dites qui est le Capitaine.", "Un nom. Rien qu'un nom.")
        $ cible = comprendre(accusation, [("ferriere", ["ferriere", "commissaire", "paul", "capitaine", "vous"]),
                                          ("halvard", ["halvard", "armateur", "henri"])])
    if cible == "halvard":
        jump gala_accuse_halvard
    elif cible is None:
        narrator "Je repose le micro. Je n'ai rien dit. Ferrière me remercie « pour ce moment d'émotion », et la salle rit, gentiment."
        jump fin_port_engloutit

    moi "Commissaire Ferrière. Le Capitaine, c'est vous."
    $ son("verre")
    narrator "Un verre se brise quelque part au fond de la salle. Personne ne le ramasse."
    show ferriere sourire at centre with fondu
    fe "…Pardon ?"
    narrator "Il rit. La salle rit avec lui, mal à l'aise, en attendant de savoir de quel côté rire."
    fe "Voilà donc l'étudiant{g=/e} du petit journal. Allez-y, mon ami. Je vous écoute. Nous vous écoutons tous."
    fe normal "Mais je vous préviens : chaque accusation sans preuve, dans cette salle, est une diffamation. Et Valcourt a une très longue mémoire."

    $ ci_mode = "gala"
    $ contradictions = set()
    $ musique_jouer("objection")
    call contre_interrogatoire("ferriere_a")
    fe "Soit. Admettons qu'un de mes hommes ait commis une faute. Cela ne fait pas de moi un trafiquant."
    call contre_interrogatoire("ferriere_b")
    fe "Des papiers. Des tampons. N'importe qui peut tamponner au nom du central. Où est votre Capitaine, dans tout ça ?"
    call contre_interrogatoire("ferriere_c")
    $ ci_mode = "audience"
    jump gala_derniere_piece


################################################################################
## Contradictions brisées
################################################################################

label ci_ferriere_a_brise:
    if derniere_preuve == "toxico":
        moi "Le poison retrouvé dans le sang d'Éléonore Lambert est un sédatif à usage hospitalier. Il ne se cache pas dans un ourlet. Il ne se trouve pas en cellule."
        moi "Quelqu'un le lui a apporté. Entre vingt et une heures et vingt-deux heures."
    elif derniere_preuve == "main_courante":
        moi "Voici la sauvegarde informatique de la main courante. Nuit du 16 octobre, vingt et une heures trente-cinq."
        moi "« Visite du commissaire divisionnaire, cellule 3. Un gobelet d'eau. » Sur le registre papier, cette ligne a été raturée."
    else:
        moi "Éléonore Lambert s'est réveillée hier. Elle a écrit trois mots, devant un médecin et un inspecteur."
        moi "« Ferrière. L'eau. Capitaine. »"
    show ferriere normal
    narrator "Un murmure traverse la salle, comme du vent dans des voiles."
    if fait("malo_allie"):
        show malo determine at droite with fondu
        m "Je confirme. J'ai extrait moi-même la sauvegarde. Malo Deschamps, inspecteur. Votre élève, patron."
        hide malo with fondu
    return

label ci_ferriere_b_brise:
    if derniere_preuve in ("capitainerie", "requisitions"):
        moi "Depuis 2016, chaque jeudi, l'Ondine part sans inspection. Les douanes ont été écartées « sur réquisition du commissariat central »."
        if derniere_preuve == "requisitions":
            moi "Quatre cents réquisitions. Toutes signées du même matricule : 0417."
    else:
        moi "Monsieur Halvard ne répond pas de l'Ondine. Il obéit. Depuis douze ans, il reçoit des lettres de chantage signées « C. »."
    if fait("halvard_temoin"):
        show halvard normal at gauche with fondu
        narrator "Au premier rang, Henri Halvard se lève. Lentement. Comme un homme qui sort de l'eau froide."
        hal "C'est vrai. Tout est vrai. On me fait chanter depuis 2014. L'Ondine ne m'appartient plus que sur le papier."
        hal "Et l'homme qui me fait chanter est assis… non. Debout. Là. Avec sa médaille."
        $ noter("halvard_a_parle")
        $ contradictions.add("halvard")
        hide halvard with fondu
    if fait("isabella_temoin") or niveau("isabella") >= 5:
        show isabella normal at droite with fondu
        narrator "Une porte s'ouvre au fond de la salle. Isabella Varga entre, en manteau, sans invitation. Personne n'ose l'arrêter."
        isa "Moi aussi, je reçois des lettres signées « C. ». Depuis que j'ai osé parler d'audit des donateurs, l'an dernier."
        isa "Ma démission de vendredi ? On me l'a dictée. « Partez, ou votre frère paiera. »"
        isa colere "J'ai protégé la mauvaise personne pendant douze ans. Je ne protégerai plus personne, ce soir. Pas même moi."
        $ noter("isabella_gala")
        $ marteaux = min(marteaux_max(), marteaux + 1)
        hide isabella with fondu
    show ferriere normal
    fe "Halvard est un homme fatigué. Il dirait n'importe quoi pour sauver sa compagnie."
    return

label ci_ferriere_c_brise:
    if derniere_preuve == "carnet_pere":
        moi "En 2018, un docker du quai 7 a écrit ceci, une semaine avant de mourir sous un conteneur :"
        moi "« Le Capitaine n'est pas un marin. Il ne monte jamais à bord. Il a les clés du port comme d'autres celles d'une école. »"
        moi "Ce docker, c'était mon père."
        narrator "La salle se tait d'un coup. Même Ferrière."
        $ noter("papa_dit")
    elif derniere_preuve == "photo_gala":
        moi "Le gala de l'an dernier. Monsieur Halvard vous serre la main, les yeux baissés, comme on salue son patron."
        moi "Et à votre doigt, la même chevalière qu'aujourd'hui. Une ancre."
        narrator "Instinctivement, Ferrière cache sa main droite dans sa poche. Trois cents personnes le voient faire."
    else:
        moi "Quatre cents réquisitions pour l'Ondine. Un seul matricule. Le vôtre : 0417."
    show ferriere colere
    return


################################################################################
## La dernière pièce
################################################################################

label gala_derniere_piece:
    $ brisees = len([k for k in ("ferriere_a", "ferriere_b", "ferriere_c") if k in contradictions])
    show ferriere normal at centre
    $ musique_jouer("tension")
    fe "Des gribouillis d'une femme dans le coma. Des lettres sans signature. Des tampons que n'importe qui peut apposer."
    fe "Mesdames et messieurs, qui ici croira un étudiant contre trente ans de service ?"
    if brisees < 2:
        narrator "Personne ne répond. Mais personne ne me regarde plus, non plus. Ils regardent leurs chaussures, leurs verres, le plafond."
        pensee "Je n'ai pas assez. Il le sait. Ils le savent."
        jump fin_port_engloutit
    pensee "Il faut une pièce qui ne parle pas de « la police ». Une pièce qui parle de lui. De sa main."
    window hide
    $ code = renpy.call_screen("dossier", presenter=True, question="Quelle pièce rattache Ferrière, de sa main, au Capitaine ?")
    if code is not None and preuve_de_sa_main(code):
        $ examiner(code)
        $ son("objection")
        show objection_bulle
        with tremblement_ecran
        if code == "requisitions":
            moi "0417. Pas « le central ». Vous. Votre matricule, de votre main, quatre cents fois."
        elif code == "main_courante":
            moi "Vingt et une heures trente-cinq. Pas « un de vos hommes ». Vous. Avec un gobelet d'eau."
        elif code == "temoignage_eleonore":
            moi "Elle a écrit votre nom. Pas « la police ». Le vôtre. Devant un médecin qui a signé."
        else:
            moi "Cette lettre est tapée au dos de votre papier à en-tête. « Cabinet du divisionnaire. » Il n'y a qu'un divisionnaire à Valcourt."
        hide objection_bulle
        jump fin_lumieres_port
    narrator "Je présente une pièce. Ferrière la regarde à peine."
    fe "Encore « la police ». Encore « quelqu'un ». Vous ne m'avez toujours pas montré MOI, mon ami."
    jump fin_port_engloutit

label penalite_gala:
    $ son("choc")
    with tremblement_ecran
    $ marteaux -= 1
    fe "Vous voyez ? Des pièces au hasard, des accusations en l'air. Voilà le sérieux de ce petit journal."
    narrator "Des rires, dans la salle. Quelques-uns. Puis davantage."
    if marteaux <= 0:
        narrator "Quelqu'un me reprend doucement le micro des mains. Le maître de cérémonie, avec un sourire désolé."
        jump fin_port_engloutit
    elif marteaux == 1:
        pensee "Encore une erreur, et ils ne m'écouteront plus jamais."
    return

label gala_accuse_halvard:
    moi "Monsieur Halvard. L'Ondine est à vous. Le Capitaine, c'est vous."
    show halvard normal at centre with fondu
    narrator "Halvard devient blanc. Puis il éclate d'un rire terrible, et sort de la salle sans un mot."
    hide halvard with fondu
    show ferriere sourire at centre with fondu
    fe "Eh bien. Voilà une soirée pleine d'émotions. Je crois que Monsieur Halvard nous doit quelques explications."
    fe "Mes hommes s'en occuperont. Merci, {g=jeune_homme/jeune_femme}, pour votre courage."
    pensee "Il me remercie. Il me remercie, et je viens de lui offrir son coupable."
    $ noter("halvard_accuse")
    jump fin_port_engloutit


################################################################################
## Fin 7 — Le port engloutit tout
################################################################################

label fin_port_engloutit:
    $ code_fin_courant = "port_engloutit"
    $ ci_mode = "audience"
    scene bg port nuit with noir_long
    show pluie_fine
    $ ambiance("port")
    $ musique_jouer("tristesse")
    narrator "Le lendemain, la Fondation a porté plainte contre « [gazette_nom] » pour diffamation. Le journal ne reparaîtra pas."
    if fait("malo_allie"):
        narrator "Malo a été suspendu pour « manquement grave à la loyauté ». Il a rendu sa carte sans un mot, et il est parti travailler sur les ferries."
    else:
        narrator "Malo a été muté dans une autre ville. Il ne m'a pas dit au revoir. Je crois qu'il avait honte, et je ne sais pas de quoi."
    if fait("halvard_accuse"):
        narrator "Henri Halvard a été mis en examen. On a trouvé dans ses comptes tout ce qu'il fallait pour le faire tomber. Quelqu'un les avait préparés depuis longtemps."
    else:
        narrator "Henri Halvard a vendu sa compagnie et quitté le pays. L'Ondine a changé de nom. Elle est toujours bleue."
    narrator "Éléonore Lambert a été transférée dans un hôpital de la capitale. On dit qu'elle ne se souvient de rien. On dit beaucoup de choses."
    show iris normal at centre with fondu
    ir "Huit fois. Neuf, maintenant. Il gagne toujours, [joueur_nom]. Il a les clés de tout."
    ir "Mais tu as dit son nom devant trois cents personnes. Personne ne l'avait jamais fait. Ce n'est pas rien."
    hide iris with fondu
    call epilogue_famille
    narrator "Le jeudi suivant, à vingt-trois heures, un bateau bleu a quitté le quai 7. Sans inspection."
    narrator "Sur le quai, sous la pluie, un vieux commissaire le regardait partir en tournant une bague à son doigt."
    $ ambiance(None)
    call terminer("port_engloutit", 7, "Le port engloutit tout", "Il ne suffit pas de dire la vérité. Il faut qu'elle tienne debout.")
    return


################################################################################
## Fin 9 — Les Lumières du port, puis le prix du Livre
################################################################################

label fin_lumieres_port:
    $ code_fin_courant = "lumieres_port"
    $ ci_mode = "audience"
    $ musique_jouer("espoir")
    narrator "Le silence, d'abord. Puis une chaise qui grince. Puis quelqu'un, au fond, qui commence à applaudir. Pas Ferrière. Pas pour Ferrière."
    show ferriere colere at centre with fondu
    narrator "Il regarde la salle. La salle le regarde. Pour la première fois en trente ans, Paul Ferrière n'a personne pour baisser les yeux devant lui."
    fe "Vous ne savez pas ce que vous venez de faire. Ce port tenait parce que quelqu'un le tenait."
    fe "Demain, ce sera pire. Vous verrez."
    if fait("malo_allie"):
        show malo determine at droite with fondu
        m "Paul Ferrière, vous êtes en état d'arrestation pour tentative de meurtre sur la personne d'Éléonore Lambert, trafic de stupéfiants en bande organisée, et extorsion."
        m "Vous avez le droit de garder le silence. Vous me l'avez appris. Je vous conseille de vous en servir."
        narrator "Il lui passe les menottes. Doucement. Presque avec respect. Comme on referme un livre qu'on a aimé, avant de comprendre qu'il mentait."
        hide malo with fondu
    else:
        narrator "Le préfet, au premier rang, se lève. Il parle à voix basse dans son téléphone. À vingt-deux heures, l'inspection générale de la police est dans la salle."
    hide ferriere with fondu
    $ noter("ferriere_tombe", "reseau_demantele")
    $ debloquer_fin("lumieres_port")
    $ souvenir("Au gala de la Fondation, le Capitaine est tombé devant tout Valcourt.", "ferriere colere", "bg bal")

    scene bg port nuit with noir_long
    $ ambiance("port")
    $ poser_heure("JEUDI · 23 H 00")
    narrator "Le jeudi suivant, à vingt-trois heures, l'Ondine est restée à quai. Des scellés sur la passerelle, un agent sur le ponton."
    narrator "Le port s'est allumé comme tous les soirs, lumière après lumière. Mais ce soir-là, j'ai eu l'impression que c'était pour nous."
    if fait("verite_papa"):
        narrator "J'ai posé la main sur la rambarde du quai 7, à l'endroit où, sur la photo, Papa riait de quelque chose hors du cadre."
    $ ambiance(None)
    call acte2_le_prix
    return

label acte2_le_prix:
    scene bg chambre nuit with noir_long
    $ poser_heure("JEUDI · 23 H 50")
    $ musique_jouer("boucle")
    $ son("vibreur")
    narrator "Maëlle. Elle a vu les informations. Elle crie de joie dans le téléphone, puis elle pleure, puis elle rit."
    if fait("rentre_maison"):
        ma "Maman a vu ton visage à la télé. Elle dit que tu avais exactement la même tête que dimanche, quand tu as soufflé ses bougies avec elle."
        moi "…Dimanche ?"
        ma "Son anniversaire. Tu es venu{g=/e}, tu as dormi à la maison, tu as même mangé deux parts de poulet."
        narrator "Je cherche. Le train, la cuisine, les bougies. Il n'y a rien. Un dimanche blanc, lisse comme une page."
        narrator "Dans mon sac, il y a un billet de train composté. Valcourt – Saint-Aubin, aller-retour. Je ne me souviens pas de l'avoir acheté."
    else:
        ma "Tu as quand même raté l'anniversaire de Maman, hein. Je dis ça, je ne dis rien."
        moi "Son anniversaire ? Il est… il est en mars, non ?"
        ma "…Le 19 octobre. Depuis cinquante-deux ans. Tu le sais très bien."
        narrator "Je le savais. Je sais que je le savais. Mais la date a glissé hors de ma tête comme une pièce d'une poche trouée."
    $ varier(moral=-2)
    narrator "Après avoir raccroché, je fais ce que je redoutais de faire."
    if possede("photo_pere"):
        narrator "Je sors la photo de ma poche. Un homme, sur un quai, au soleil, qui rit de quelque chose hors du cadre."
        narrator "Je sais que c'est Papa. Maman me l'a dit. C'est écrit au dos."
        narrator "Mais ce visage, je ne le reconnais pas. C'est le visage d'un inconnu sympathique."
    else:
        narrator "J'essaie de me souvenir du visage de Papa. Ses yeux, que j'ai, paraît-il. Ses sourcils, quand il mentait."
        narrator "Il y a un trou. Exactement à l'endroit où il devrait être."
    $ noter("prix_paye")
    $ souvenir("Le Livre a pris sa part : un anniversaire, et le visage de Papa.", None, "bg chambre nuit")
    call acte2_prix_coeur

    scene bg toit with fondu
    $ musique_jouer("tristesse")
    show iris normal at centre with fondu
    narrator "Iris est sur le toit. Évidemment. Deux cafés. Elle me regarde arriver et elle comprend tout de suite."
    ir "Qu'est-ce qu'il t'a pris ?"
    moi "Un dimanche. Et le visage de mon père."
    ir "…Bienvenue. Moi, c'était le café. Puis la voix de ma grand-mère. Puis des choses dont je ne sais même plus qu'elles ont existé."
    if coeur == "iris" and fait("declaration"):
        ir "Et mardi soir ? Sur ce toit ? Tu t'en souviens ?"
        narrator "Je cherche. Il n'y a rien. Iris le voit. Elle ferme les yeux une seconde."
        ir "Il t'a pris ça aussi. Évidemment. Il prend toujours le meilleur."
        ir "Alors écoute-moi bien, parce que je vais le dire pour deux : tu m'as dit que tu m'aimais. Et je t'ai répondu oui."
        ir "Ça, il ne me le prendra pas. Je l'ai écrit partout. Sur mes mains, s'il le faut."
        $ noter("declaration_oubliee")
        $ souvenir("Le Livre m'a pris le soir sur le toit. Iris s'en souvient pour deux.", "iris normal", "bg toit")
    ir "Le Livre se paie en souvenirs. Personne ne le dit au début. On le découvre en cherchant quelque chose qui n'est plus là."
    if possede("marque_page"):
        narrator "Dans ma poche, le marque-page est froid. Pour la première fois, il est froid."
    ir "Mme Bernier veut nous voir. Toi et moi. Elle dit qu'il est temps de raconter la fin de l'histoire d'Aurèle."
    ir "Et que pour refermer le Livre, il faudra écrire un nom sur la dernière page."
    hide iris with fondu
    window hide
    $ poser_heure("")
    $ musique_jouer("theme", 2.0)
    call screen carte_acte(2, "Le Capitaine", "Le Capitaine est tombé. Le Livre a pris sa part.", "ACTE III", "La dernière page")
    jump acte3_debut

label acte3_debut:
    $ renpy.force_autosave()
    window hide
    call screen a_suivre("Acte III — La dernière page", "Le monde commence à oublier [joueur_nom]. Trois jours d'adieux, et un dernier nom à écrire, à minuit, dans la réserve.")
    $ renpy.full_restart()
    return
