## Acte II — chapitre 1 : le vrai jeudi (16 octobre) et le vendredi matin.

label acte2:
    $ acte = 2
    $ chapitre = "acte2"
    $ jour = 11
    $ moment = "matin"
    $ cafes_du_jour = 0
    $ nuits_blanches = 0
    $ echeance_carte = "avant les partiels"
    $ oublier("drame")
    $ noter("acte2", "iris_vivante")
    $ rel.setdefault("lucas", 3)
    $ rencontrer("iris", "clara", "malo", "eleonore", "nathan", "amelie", "lucas", "hugo", "maelle")
    $ noter_journal("partiels", "Partiels de mi-semestre (la bourse en dépend encore).", "Lundi 20, 8 h")
    $ debut_jour_etat = instantane()
    call titre(4, "Jeudi", "16 octobre", "Un vrai jeudi")

    ############################################################################
    ## 7 h 30 — le toit
    ############################################################################
    scene bg toit with fondu_long
    show poussiere
    $ poser_heure("JEUDI · 07 H 30")
    $ musique_jouer("espoir")
    narrator "Un message d'Iris, à sept heures : {i}« Sur le toit. J'ai pris deux cafés. »{/i}"
    narrator "Elle est assise sur le muret, les jambes dans le vide, emmitouflée dans un manteau trop grand. Elle regarde le soleil comme on regarde un tour de magie."
    show iris normal at centre with fondu
    ir "Tu sais ce que c'est ?"
    moi "Le soleil ?"
    ir "Un jeudi. Le soleil d'un jeudi. Je n'en avais pas vu depuis…"
    ir "Je ne sais plus. C'est ça le pire. Je ne sais plus depuis combien de temps."
    narrator "Elle me tend un gobelet. Le café est noir, trop sucré. Elle boit le sien d'une traite, sans grimacer."
    ir "Tu as écrit ton nom combien de fois ?"
    $ _fois = boucle - 1
    if boucle > 2:
        moi "[_fois] fois."
    else:
        moi "Une fois."
    ir "Moi, sept. Peut-être huit. À partir d'un moment, on arrête de compter les mercredis."
    ir "On compte ce qu'on perd."
    moi "Qu'est-ce que tu as perdu ?"
    ir "Le goût du café, par exemple. Celui-là, j'aurais pu le boire froid, salé, je ne l'aurais pas su. Depuis la quatrième fois, tout a le goût de l'eau tiède."
    ir "Et la voix de ma grand-mère. Je sais qu'elle chantait en faisant la vaisselle. Je ne sais plus ce qu'elle chantait."
    narrator "Elle dit ça simplement, comme on donne l'heure."

    menu:
        "« Alors on n'ouvrira plus jamais ce Livre. »":
            ir "Jamais, c'est long. Mais d'accord. Pas aujourd'hui, en tout cas."
            $ noter("promesse_livre")
            $ lien("iris", 1)
        "« Ça valait le coup. Tu es là. »":
            ir "…Tu es la première personne à me dire ça. D'habitude, à ce stade, tout le monde est mort, ou ne me connaît pas."
            $ lien("iris", 1)
        "Lui décrire le goût du café.":
            moi "Il est trop sucré. Noir. Un peu brûlé au fond. Il sent la cartonnerie du gobelet. C'est le pire café de Valcourt."
            ir "…Merci. Je crois que je vais te demander ça souvent."
            $ lien("iris", 2)
            $ noter("gout_cafe")

    ir "Il y a une chose que je ne t'ai pas dite. Mon message, mercredi. « Pas la police. »"
    ir "Je ne l'ai pas écrit par hasard. Dans une boucle, il y a longtemps, j'ai appelé la police. J'ai tout donné : le registre, le quai, les noms."
    ir "Le lendemain, la clé avait disparu des scellés du commissariat. Et moi, je suis morte deux jours plus tôt que prévu."
    moi "Malo nous a aidés, cette fois."
    ir "Malo, oui. Je l'ai vu hier soir, il avait les mains qui tremblaient en passant les menottes. Ce n'est pas lui."
    ir "Mais au-dessus de Malo, il y a quelqu'un. Et quelqu'un au-dessus de ce quelqu'un."
    $ noter("iris_pas_police")
    $ souvenir("Sur le toit, Iris a bu son café sans en sentir le goût.", "iris normal")
    hide iris with fondu

    ############################################################################
    ## Midi — la cantine
    ############################################################################
    scene bg cantine with fondu
    $ poser_heure("JEUDI · 12 H 30")
    $ musique_jouer("quotidien")
    narrator "À la cantine, on ne parle que de ça. « L'assistante de la directrice. » « Une drogue fabriquée dans NOTRE labo. » « Il paraît qu'il y avait un étudiant. »"
    show amelie normal at gauche with fondu
    show clara joie at droite with fondu
    am "Te voilà ! Assieds-toi, assieds-toi. Tu as vu ? Tout Valcourt en parle, et la Gazette a le scoop du siècle. Iris écrit depuis six heures du matin."
    c "Amélie n'a pas dormi. Elle a bu quatre cafés. Je les ai comptés."
    am "Cinq."
    narrator "Clara rit. Elle a de la peinture bleue sur le pouce, et des cernes de quelqu'un qui a dormi tard, pas de quelqu'un qui a pleuré toute la nuit."
    pensee "Pour elle, il ne s'est rien passé. Pas de parloir, pas de « Je n'ai rien fait », pas de pluie. Rien."
    pensee "Je me souviens d'une semaine qu'elle n'a pas vécue."
    if fait("clara_protegee"):
        c sourire "Merci pour hier soir. Le film était nul. Je me suis endormie au bout de vingt minutes, c'est un compliment."
    c pensif "Tu as une drôle de tête, [joueur_nom]. Comme quelqu'un qui revient de très loin. C'était comment, là-bas ?"
    window hide
    $ rep = saisie("Clara vous demande : « C'était comment, là-bas ? »", "Répondez ce que vous voulez. Elle écoute.")
    $ sujet = comprendre(rep, [("livre", ["livre", "boucle", "mercredi", "recommence", "temps", "revivre"]),
                                ("elle", ["toi", "tu m as manque", "manque", "content de te voir", "contente de te voir", "heureux", "heureuse", "ici", "avec toi", "ensemble"]),
                                ("dur", ["dur", "difficile", "horrible", "long", "peur", "fatigue", "seul", "seule"])])
    if sujet == "livre":
        show clara surprise
        c "…Tu parles comme Iris. Elle dit des choses comme ça, parfois. « La dernière fois, tu avais mis ton pull vert. » Je n'ai pas de pull vert."
        c pensif "Un jour, vous m'expliquerez. D'accord ?"
        $ noter("clara_intriguee")
    elif sujet == "elle":
        show clara timide
        c "Oh. Euh. Moi aussi. Enfin. Je veux dire, je suis contente que tu sois revenu{g=/e}. D'où que tu reviennes."
        $ lien("clara", 1)
    elif sujet == "dur":
        c souci "Alors tu es revenu{g=/e} au bon endroit. Ici, on ne te demande rien. On mange des frites froides et on se plaint des cours."
        $ lien("clara", 1)
    else:
        c sourire "Tu n'es pas obligé{g=/e} de répondre. Je dessine des gens qui ne répondent jamais. C'est mon genre préféré."
    hide clara
    hide amelie
    with fondu

    ############################################################################
    ## Après-midi — un créneau libre
    ############################################################################
    $ moment = "après-midi"
    $ poser_heure("JEUDI · 14 H 00")
    pensee "La police m'attend à dix-sept heures pour ma déposition. D'ici là, l'après-midi est à moi. Pour une fois."
    $ choix = choisir_creneau("Jeudi — après-midi", [
        ("cours", "Aller en cours", "La vie normale. Les partiels sont lundi.", {"etudes": 1, "energie": -1}, True, ""),
        ("gazette", "Aider à la Gazette", "Iris et Amélie bouclent l'édition spéciale.", {"energie": -1}, True, ""),
        ("sieste", "Dormir enfin", "Trois mercredis dans les jambes.", {"energie": 3}, True, ""),
        ("maelle", "Appeler Maëlle", "Elle a appelé deux fois ce matin.", {"moral": 2}, True, ""),
    ], "Jusqu'à la déposition de 17 h")
    if choix == "cours":
        scene bg classe eleves with fondu
        narrator "Un cours d'histoire du droit. Le professeur parle des lettres de cachet. Je prends des notes comme on se raccroche à une rambarde."
        $ varier(etudes=1, energie=-1)
    elif choix == "gazette":
        scene bg redaction with fondu
        show iris normal at gauche_c with fondu
        show amelie normal at droite_c with fondu
        narrator "La Gazette loge dans l'arrière-salle d'un café du port, depuis que l'Académie lui a retiré son local il y a deux ans. Le patron leur fait crédit."
        am "Titre ? « Le laboratoire de la honte » ? Trop. « Azur : l'enquête » ? Trop plat."
        ir "« Veritas. » Juste ça. En gros. Ils comprendront."
        narrator "Je relis les épreuves, je corrige trois fautes, je découpe des photos. Pendant deux heures, je fais partie de quelque chose."
        $ lien("iris", 1)
        $ lien("amelie", 1)
        $ varier(energie=-1)
        hide iris
        hide amelie
        with fondu
    elif choix == "sieste":
        scene bg chambre with fondu
        narrator "Je dors trois heures d'un sommeil sans rêves, sans mercredi, sans rien."
        $ varier(energie=3)
    else:
        scene bg chambre with fondu
        ma "Enfin ! J'ai vu les infos. Valcourt, une drogue, une arrestation… Dis-moi que tu n'as rien à voir là-dedans."
        moi "J'ai… un peu à voir là-dedans. Mais du bon côté."
        ma "Évidemment. Tu as toujours été du bon côté. C'est pour ça que je m'inquiète."
        ma "Maman ne sait rien. Laisse-la ne rien savoir, d'accord ? Elle a assez de ses nuits."
        $ cocher("appeler_maelle")
        $ varier(moral=2)

    ############################################################################
    ## 17 h — la déposition
    ############################################################################
    scene bg commissariat with fondu
    $ poser_heure("JEUDI · 17 H 00")
    $ musique_jouer("enquete")
    show malo fatigue at gauche with fondu
    m "Assieds-toi. Café ? Il est froid. Il est toujours froid. Certaines choses ne changent pas, même un jeudi."
    m "Je prends ta déposition, tu signes, tu rentres. Et tu oublies tout ça pendant quelques jours."
    narrator "Il tape mes réponses avec deux doigts. Puis il s'arrête, les mains au-dessus du clavier."
    m souci "Le quai 7. On y est allés à l'aube, avec vingt hommes et un mandat."
    m "Vide. Le hangar balayé. Pas une caisse, pas un sachet. Le bateau bleu à quai, propre comme un sou neuf."
    m colere "Quelqu'un les a prévenus. Entre minuit et cinq heures du matin, quelqu'un les a prévenus."
    $ son("porte")
    show ferriere normal at droite with fondu
    $ rencontrer("ferriere")
    fe_inconnu "Deschamps, vous allez effrayer notre témoin avec vos théories."
    narrator "Un homme d'une soixantaine d'années, imperméable gris, cravate claire. Il a une voix de grand-père qui lit des histoires."
    fe "Paul Ferrière. Je dirige ce commissariat. Je voulais vous serrer la main."
    fe "Valcourt vous doit beaucoup, [joueur_nom]. Mademoiselle Delaunay vous doit la vie, d'après ce qu'on me dit."
    if temperament == "logique":
        narrator "En me serrant la main, il tourne machinalement une chevalière à son annulaire. Une ancre est gravée dessus."
        pensee "Une ancre. Curieux, pour un policier."
        $ noter("chevaliere_vue")
    elif temperament == "empathique":
        pensee "Malo se tient plus droit depuis que Ferrière est entré. Comme un fils devant son père."
    fe "Une question, une seule, et je vous laisse. Ce registre trouvé par Mademoiselle Delaunay… Garde-t-elle une copie quelque part ?"
    fe "Ces choses-là se perdent, se volent. Ici, elle serait à l'abri."
    menu:
        "« Iris en garde une copie, oui. »":
            fe "Très prudent de sa part. Dites-lui de me l'apporter, à l'occasion. Rien ne presse."
            $ noter("ferriere_sait_copie")
        "« Tout ce qu'on avait est déjà chez vous. »":
            fe "Parfait. Alors tout est entre de bonnes mains."
            pensee "C'est faux. Iris garde toujours une copie de tout. Je ne sais pas pourquoi j'ai menti. Ou plutôt si."
            $ noter("ferriere_menti")
        "« Pourquoi cette question ? »":
            fe "Déformation professionnelle. Trente ans à voir des preuves disparaître, on devient maniaque."
            narrator "Il sourit. Malo regarde ses mains."
            $ noter("ferriere_esquive")
    fe "Reposez-vous. Cette histoire est entre de bonnes mains, désormais."
    hide ferriere with fondu
    m normal "Le patron. Trente ans de maison. C'est lui qui m'a appris le métier. Et à boire du café froid."
    m "Signe là. Et rentre."
    $ souvenir("J'ai serré la main du commissaire Ferrière. Il voulait savoir où était le registre.", "ferriere normal")
    hide malo with fondu

    ############################################################################
    ## Soir — la fête
    ############################################################################
    $ moment = "soir"
    scene bg chambre clara with fondu
    $ poser_heure("JEUDI · 20 H 30")
    $ musique_jouer("clara")
    narrator "Le soir, Lucas débarque avec trois pizzas et une guirlande lumineuse volée au bal. Amélie apporte l'édition spéciale, encore chaude de l'imprimante."
    narrator "Une page entière, un seul mot en capitales : {b}VERITAS{/b}. Et en dessous, en petit : {i}« par Iris Delaunay »{/i}."
    narrator "On s'entasse dans la chambre de Clara. Quelqu'un met de la musique trop fort. Pour la première fois depuis lundi, personne n'a peur."
    pensee "Pas encore."
    narrator "Lucas pose beaucoup de questions, ce soir. Sur la Gazette, sur le registre, sur qui sait quoi. Il rit trop fort. Hugo lui manque, sans doute."
    menu:
        "Rester près de Clara, qui dessine dans un coin.":
            $ noter("penchant_clara")
            show clara sourire at centre with fondu
            c "Ne bouge pas. Tu as la tête de quelqu'un qui vient de gagner quelque chose et qui ne sait pas encore quoi."
            narrator "Elle me dessine en dix minutes. Sur le papier, j'ai l'air plus calme que je ne le suis."
            c "Garde-le. Comme ça, si un jour tu ne te reconnais plus, tu sauras à quoi tu ressembles."
            $ lien("clara", 1)
            $ noter("portrait_clara")
            hide clara with fondu
        "Rejoindre Iris à la fenêtre.":
            $ noter("penchant_iris")
            show iris normal at centre with fondu
            ir "Décris-moi la pizza."
            moi "Trop de fromage. La pâte est molle au milieu, croustillante sur les bords. Lucas a pris celle à l'ananas, et c'est un crime."
            ir "…C'est un crime, je confirme. Même sans le goût."
            narrator "Elle s'appuie contre mon épaule, à peine, juste assez pour que je ne sois pas sûr{g=/e} de ne pas l'avoir rêvé."
            $ lien("iris", 1)
            hide iris with fondu
        "Parler avec Amélie de la Gazette.":
            $ noter("penchant_amelie")
            show amelie normal at centre with fondu
            am "Tu sais ce qui me rend folle ? L'Ondine. Le bateau bleu. Il appartient à Halvard Maritime."
            am "Henri Halvard, le président de la Fondation, celui qui paie la moitié des bourses de l'Académie. Et personne ne pose la question."
            am "Moi, je la pose. Demain."
            $ noter("halvard_connu")
            am "Et toi, tu poses les bonnes questions. C'est très énervant. Et très… enfin. Tu vois."
            $ lien("amelie", 1)
            hide amelie with fondu
        "Aider Lucas à servir les pizzas.":
            $ noter("penchant_lucas")
            show lucas normal at centre with fondu
            lu "Ananas ou pas ananas ? Attention, c'est un test de personnalité."
            moi "Pas d'ananas."
            lu "Mauvaise réponse. Mais je te pardonne. Tu as de beaux yeux pour quelqu'un qui a tort."
            narrator "Il rougit de ce qu'il vient de dire, et part chercher des serviettes dont personne n'a besoin."
            $ rel["lucas"] = min(10, rel.get("lucas", 3) + 1)
            hide lucas with fondu

    ############################################################################
    ## 23 h 40 — l'appel
    ############################################################################
    scene bg chambre nuit with noir
    $ moment = "nuit"
    $ poser_heure("JEUDI · 23 H 40")
    $ musique_jouer("tension")
    $ son("vibreur")
    narrator "Je suis à moitié endormi{g=/e} quand le téléphone vibre. Malo."
    m "Tu dors ? Tant mieux. Réveille-toi."
    m "Éléonore Lambert. On l'a retrouvée inconsciente dans sa cellule, il y a une heure. Empoisonnée."
    moi "Elle est…"
    m "Vivante. Dans le coma. Les médecins ne savent pas si elle se réveillera."
    m "Dans MA garde à vue. Sous MES yeux. Tu comprends ce que ça veut dire ?"
    narrator "Un silence. J'entends une sirène derrière lui, et sa respiration."
    m "Il y a autre chose. Avant qu'on le transfère, Nathan a parlé. Il avait peur, une peur que je n'ai jamais vue chez un gamin."
    m "Il a dit : « Vous ne comprenez pas. Elle n'était rien. C'est le Capitaine qui décide. »"
    moi "Le Capitaine ? Qui est-ce ?"
    m "Je ne sais pas. Personne ne sait. Nathan a refusé d'en dire plus. Il a demandé un avocat, et un lit loin des fenêtres."
    m "Écoute-moi bien. Tu ne parles de ça à personne. Pas à tes amis, pas à… personne. D'accord ?"
    $ noter("capitaine_nomme", "eleonore_coma")
    $ souvenir("Éléonore a été empoisonnée en cellule. Nathan a prononcé un nom : le Capitaine.", "malo souci", "bg chambre nuit")
    pensee "J'ai sauvé Iris. J'ai cru que c'était la fin."
    pensee "Ce n'était que la première page."
    $ dormi_cette_nuit = True
    call resume_jour("Jeudi")
    jump acte2_vendredi


################################################################################
## Vendredi 17 — la Gazette clandestine
################################################################################

label acte2_vendredi:
    $ jour = 12
    $ moment = "matin"
    $ cafes_du_jour = 0
    $ energie = borner(energie + 4)
    call titre(5, "Vendredi", "17 octobre", "La Gazette clandestine")

    scene bg amphi with fondu
    $ poser_heure("VENDREDI · 08 H 00")
    $ musique_jouer("mystere")
    narrator "Huit heures. Toute l'Académie est convoquée à l'amphithéâtre. Même les professeurs ont l'air d'élèves."
    show isabella normal at centre with fondu
    isa "Je serai brève. C'est ce que je fais de mieux, paraît-il."
    isa pensif "Pendant douze ans, j'ai confié mes clés, mes rendez-vous et mes secrets à une personne qui a transformé notre laboratoire en usine à poison."
    isa "Je ne l'ai pas vu. C'était mon métier de le voir. Je quitte la direction de Valcourt aujourd'hui."
    narrator "Un murmure traverse l'amphithéâtre. Au premier rang, Dorian baisse la tête."
    isa normal "Le conseil de la Fondation assurera l'intérim. Son président va vous dire quelques mots."
    hide isabella with fondu
    show halvard normal at centre with fondu
    $ rencontrer("halvard")
    hal "Henri Halvard. Certains d'entre vous me connaissent : je paie vos bourses."
    narrator "Il le dit sans sourire. C'est un homme massif, au manteau d'armateur, la barbe taillée court. Sa voix couvre l'amphithéâtre sans micro."
    hal "Valcourt traverse une tempête. Un bon capitaine ne quitte pas le navire au premier grain."
    hal "Pour protéger l'enquête et la réputation de cette maison, la Gazette de Valcourt est suspendue jusqu'à nouvel ordre."
    narrator "Au fond de l'amphi, j'entends Amélie se lever d'un bond. Puis se rasseoir, tirée par la manche par quelqu'un."
    hal "Je vous remercie."
    pensee "« Un bon capitaine. » Il a dit ça comme on dit bonjour."
    if fait("halvard_connu"):
        pensee "Le bateau bleu est à sa compagnie. Et la première chose qu'il fait, c'est fermer le seul journal qui en parle."
    $ souvenir("Henri Halvard a suspendu la Gazette. « Un bon capitaine ne quitte pas le navire. »", "halvard normal")
    hide halvard with fondu

    ############################################################################
    ## Midi — la fondation de la Gazette clandestine
    ############################################################################
    scene bg redaction with fondu
    $ poser_heure("VENDREDI · 12 H 15")
    $ musique_jouer("enquete")
    narrator "Le café du port. L'arrière-salle sent le marc de café et l'encre d'imprimante. Amélie a punaisé au mur le plan du port, une carte de l'Académie et une feuille blanche."
    show amelie normal at gauche with fondu
    show iris normal at centre with fondu
    show clara pensif at droite with fondu
    am "Suspendue. SUSPENDUE. Soixante ans de Gazette, et un armateur la ferme en une phrase."
    ir "Alors on continue sans eux. Pas de local, pas d'imprimerie officielle, pas d'autorisation."
    c "Un journal clandestin ? Comme dans les films de guerre ?"
    ir "Comme dans les films de guerre. Moins les bottes."
    am "Il nous faut un nom. Un vrai. Pas « Gazette ». La Gazette, c'est la leur, maintenant."
    ir "[joueur_nom] ? C'est toi qui as trouvé le registre. Tu baptises."
    window hide
    $ gazette_nom = saisie("Quel nom donnez-vous au journal clandestin ?", "Deux mots suffisent. Amélie l'écrira en capitales sur la feuille blanche.")
    $ gazette_nom = gazette_nom[:40].strip(" .!?«»\"")
    if normaliser(gazette_nom) in ("", "je ne sais pas", "aucun", "rien", "merci"):
        $ gazette_nom = "La Lanterne"
        am "Bon. Alors je décide : « La Lanterne ». Ça éclaire, ça ne coûte rien, et ça fait peur aux rats."
    elif mentionne(gazette_nom, ["veritas"]):
        ir "« [gazette_nom] ». Évidemment. La devise qu'ils ont oubliée."
        $ lien("iris", 1)
    else:
        am "« [gazette_nom] ». J'adore. Je n'aurais pas trouvé mieux. Bon, si, mais je ne le dirai pas."
    narrator "Amélie l'écrit en haut de la feuille blanche, au marqueur noir : {b}[gazette_nom!u]{/b}. En dessous, elle trace un grand point d'interrogation."
    am "Notre première question : qui est le Capitaine ?"
    if fait("capitaine_nomme"):
        pensee "Malo m'a demandé de ne rien dire. Mais Iris le sait sans doute déjà. Elle sait toujours tout avant les autres."
        menu:
            "Leur dire ce que Nathan a dit à Malo.":
                moi "Nathan a parlé, avant son transfert. « Elle n'était rien. C'est le Capitaine qui décide. »"
                ir "Alors Éléonore n'était qu'une main. Et le Capitaine a coupé la main avant qu'elle ne parle."
                $ noter("gazette_sait_capitaine")
                $ lien("iris", 1)
            "Garder la parole donnée à Malo.":
                pensee "Je me tais. Malo m'a fait confiance. C'est rare, chez lui."
                ir "Tu sais quelque chose. Tu as le même visage que moi quand je sais quelque chose."
                ir "Garde-le. Mais ne le garde pas trop longtemps."
                $ lien("malo", 1, silencieux=True)
    am "Ce qu'on sait : le bateau bleu s'appelle l'Ondine. Il appartient à Halvard Maritime. Et Halvard vient de nous fermer."
    ir "Ça fait beaucoup de coïncidences pour un seul homme."
    menu:
        "« C'est trop simple. Un coupable ne se montre pas autant. »":
            ir "Peut-être. Ou peut-être qu'il se croit intouchable. Les gens riches se montrent beaucoup."
            $ noter("doute_halvard")
        "« Alors on commence par lui. »":
            am "Voilà ! Enfin quelqu'un de raisonnable."
            $ lien("amelie", 1)

    ir "On se partage le travail. Amélie, les archives de la Gazette : tout ce qu'on a publié sur Halvard en vingt ans."
    am "Les archives sont dans ma cave. Avec les araignées. Merci, Iris."
    c "Moi, je peux aller voir Hugo à l'hôpital. Je n'aime pas les hôpitaux, mais j'aime bien Hugo."
    ir "Et moi, je ne peux pas m'approcher du port. Ils me connaissent. [joueur_nom], la capitainerie, l'hôpital, Halvard… c'est toi qui iras."
    if filiere == "lettres" or niveau("amelie") >= 4:
        am "Tiens. Ma carte de presse. Ne la perds pas, c'est la seule chose officielle qu'il nous reste."
        $ donner("carte_presse")
    ir "Une dernière chose. Les partiels sont lundi. Si l'un de nous perd sa bourse, le Capitaine aura gagné quelque chose. Alors on révise aussi."
    c "Elle parle comme ma mère."
    ir "Ta mère a raison."
    $ _t = "Au café du port est née la Gazette clandestine : « " + gazette_nom + " »."
    $ souvenir(_t, "iris normal")
    hide amelie
    hide iris
    hide clara
    with fondu

    $ creneau2_idx = 0
    jump acte2_carte
