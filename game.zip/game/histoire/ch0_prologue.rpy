## Prologue — l'audience, vue de loin, avant de remonter le temps.

label prologue:
    $ chapitre = "prologue"
    scene black
    $ ambiance("pluie")
    pause 1.0
    window hide

    show bg tribunal at lente_poussee
    show grain
    show vignette_forte
    with fondu_long
    $ ambiance("salle", canal="ambiance2")

    narrator "La pluie frappe les hautes fenêtres du tribunal de Valcourt."
    narrator "Derrière moi, deux cents personnes retiennent leur souffle. Devant moi, un dossier ouvert, des notes qui tremblent un peu."
    pensee "Ou c'est peut-être ma main qui tremble."

    $ son("coeur")
    voix "La défense est-elle prête ?"

    narrator "Je lève les yeux vers la balance gravée au-dessus du juge."
    narrator "{i}Veritas. Justitia. Libertas.{/i}"
    narrator "Sept jours plus tôt, ces trois mots n'étaient pour moi qu'une devise sur un portail."
    pensee "Sept jours plus tôt, je ne connaissais même pas le nom de la personne que je m'apprête à accuser."

    $ son("marteau")
    with flash
    $ ambiance(None, canal="ambiance2")
    scene black with Dissolve(0.3)
    $ ambiance(None)
    pause 0.8

    $ video("intro")

    jump lundi
