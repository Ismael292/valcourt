## Les lieux de l'enquête (jeudi et vendredi). Chaque label = un créneau.

init python:
    def visite(lieu):
        """Compte les visites d'un lieu et renvoie le numéro de celle-ci (1, 2…)."""
        n = sum(1 for v in store.lieux_visites if v.startswith(lieu + ":")) + 1
        store.lieux_visites.add("%s:%d" % (lieu, n))
        return n

    def pistes_connues():
        p = ["Iris", "mercredi soir"]
        if fait("piste_azur") or fait("piste_azur_iris") or a("azur"):
            p.append("Azur")
        if a("badges"):
            p.append("badge")
        if fait("vu_eleonore") or a("photo_bal"):
            p.append("enveloppe")
        if a("usb") or fait("quai7_tot"):
            p.append("quai 7")
        if fait("vu_eleonore") or a("usb"):
            p.append("Nathan")
        if fait("odeur_violette") or fait("violette_clara"):
            p.append("violette")
        return p

################################################################################
## Cours
################################################################################

label lieu_cours:
    scene bg classe eleves with fondu
    $ musique_jouer("quotidien")
    $ n = visite("cours")
    narrator "J'assiste au cours. Je prends des notes. Je fais semblant que le monde n'a pas basculé."
    if n == 1:
        narrator "Au deuxième rang, deux étudiants chuchotent : « Nathan Roussel n'est pas venu depuis mercredi. Il paraît qu'il a vidé son casier. »"
        $ noter("rumeur_nathan")
    elif n == 2:
        narrator "Le professeur annonce que le laboratoire restera fermé « jusqu'à la fin de l'enquête ». Quelqu'un au fond murmure : « Enfin. On ne verra plus les lumières bleues la nuit. »"
        $ noter("lumieres_bleues")
    else:
        narrator "Rien de nouveau. Juste le soulagement d'avoir été là, pour une fois."
    $ varier(etudes=1, energie=-1)
    $ cocher("cours_jeudi")
    return

################################################################################
## Oral de Dorian (vendredi, 9 h)
################################################################################

label lieu_oral:
    scene bg amphi with fondu
    $ musique_jouer("tension")
    show dorian normal at centre with fondu
    d "[joueur_nom]. Vous êtes venu{g=/e}. Je n'en étais pas sûr."
    d "Votre sujet : {i}« Peut-on condamner sur un seul témoignage ? »{/i} Vous avez dix minutes."
    if fait("oral_prepare"):
        pensee "Mon plan est là, dans ma tête. Mercredi soir, je l'avais écrit, rayé, réécrit."
    menu:
        "Défendre que non : un témoin voit ce qu'il croit voir.":
            moi "Un témoin voit ce qu'il croit voir. Il complète avec ses peurs, ses attentes, ce qu'on lui a dit avant. Un juge doit voir ce qui est."
            $ bon_argument = True
        "Défendre que oui, si le témoin est crédible.":
            moi "Si le témoin est honnête et sans intérêt dans l'affaire, son témoignage peut suffire."
            d pensif "Et qui décide qu'un témoin est sans intérêt ? Celui qui a besoin d'un coupable ?"
            $ bon_argument = False
        "Parler de Clara.":
            moi "Clara est en prison à cause d'un carnet et d'un témoin qu'on n'a même pas encore entendu."
            d "Ce n'est pas un oral sur Clara. Mais vous n'avez pas tort, et vous le savez."
            $ bon_argument = True
            $ lien("dorian", 1, silencieux=True)
    python:
        note_oral = 8
        if fait("oral_prepare"):
            note_oral += 4
        if bon_argument:
            note_oral += 4
        if energie >= 4:
            note_oral += 2
        if filiere == "droit":
            note_oral += 2
        note_oral = max(4, min(19, note_oral))
    d normal "[note_oral]/20."
    if note_oral >= 12:
        d "Vous serez à ma table demain. Tâchez d'être aussi {g=clair/claire} devant le juge."
        $ varier(etudes=1, moral=1)
    elif note_oral < 9:
        d "Vous valez mieux que ça. Je le sais, et vous aussi."
        $ varier(etudes=-1)
    $ lien("dorian", 1)
    $ cocher("oral")
    $ noter("oral_passe")
    $ varier(energie=-1)
    hide dorian with fondu
    return

label oral_manque:
    $ cocher("oral", "rate")
    $ varier(etudes=-2)
    $ lien("dorian", -1)
    $ recevoir("Dorian Varga", "Absent{} à l'oral. Zéro. Je vous avais prévenu{}. Nous en reparlerons après l'audience.".format(accord("", "e"), accord("", "e")), "Ven. 10:02")
    return

################################################################################
## Parloir — Clara
################################################################################

label lieu_parloir:
    scene bg parloir with fondu
    $ musique_jouer("clara")
    $ n = visite("parloir")
    if n == 1 and argent >= 6 and not possede("chocolats"):
        menu:
            "En chemin, acheter une boîte de chocolats pour Clara (6 €) ?"
            "Oui.":
                $ acheter("chocolats", 6)
            "Non.":
                pass
    if fait("clara_mensonge_connu") and not fait("aveu_clara") and not fait("clara_nie"):
        call parloir_aveu
        $ varier(energie=-1)
        hide clara with fondu
        return
    show clara triste at centre with fondu
    if n == 1:
        narrator "Le parloir sent la peinture fraîche et le désinfectant. Clara porte un survêtement gris trop grand. Elle a les yeux gonflés."
        c "Tu es venu{g=/e}."
        c "Ils m'ont posé les mêmes questions pendant six heures. Pourquoi j'étais au labo. Pourquoi je me suis disputée avec Iris. Pourquoi mon carnet était à côté d'elle."
        c "Je n'ai jamais mis les pieds dans ce laboratoire, [joueur_nom]. Jamais."
        if possede("chocolats"):
            narrator "Je pousse la boîte de chocolats vers elle. Le surveillant fait semblant de ne rien voir."
            c timide "Tu es bête. …Merci."
            $ retirer("chocolats")
            $ lien("clara", 1)
            $ varier(moral=1)
        $ reponse = saisie("Que lui demandez-vous ?", indice="Interrogez-la sur ce qui vous semble important.", sujets=["21 h 30", "carnet", "silhouette", "Iris", "parents"])
        $ sujet = comprendre(reponse, [
            ("silhouette", ["silhouette", "quelqu un", "personne", "ombre", "vu", "personnage", "dessin"]),
            ("carnet", ["carnet", "banc", "oublie", "pluie", "cour"]),
            ("iris", ["iris", "dispute", "cantine"]),
            ("heure", ["heure", "21", "22", "quand", "horloge"]),
            ("parents", ["parents", "pere", "mere", "famille"]),
        ])
        if sujet == "silhouette":
            call clara_silhouette
        elif sujet == "carnet":
            c "Je l'ai laissé sur le banc de la cour, sous l'auvent, quand l'orage a éclaté. Vers vingt et une heures quarante-cinq."
            c "Quelqu'un l'a pris. Quelqu'un l'a posé à côté d'elle. Pour que ce soit moi."
            $ noter("mise_en_scene")
        elif sujet == "iris":
            c "Elle m'a crié dessus à la cantine. Je lui ai crié dessus. Tout le monde a entendu. C'est ce que la police répète."
            c pensif "Mais maintenant… je me demande si elle ne voulait pas me protéger. Elle m'a dit de ne pas y aller. Ni ce soir-là, ni après."
        elif sujet == "heure":
            c "J'ai dessiné de vingt et une heures dix à vingt et une heures quarante. Je note toujours l'heure, c'est une manie. Regarde la dernière page du carnet."
            $ examiner("carnet")
            narrator "Je me souviens du dessin : l'horloge du laboratoire, peinte avec soin. Ses aiguilles indiquent {b}21 h 30{/b}."
        elif sujet == "parents":
            c triste "Ils ne sont pas venus. Mon père a appelé l'avocat, pas moi."
            $ lien("clara", 1)
        else:
            c "Je… je ne sais pas. Je ne sais plus rien."
        if empathie_possible():
            c "Tu crois que je vais sortir ?"
            menu:
                "« Je te le promets. »":
                    c "Ne promets pas. Mais… merci de le dire."
                    $ noter("promesse_clara")
                    $ lien("clara", 1)
                "« Je vais tout faire pour. »":
                    c "C'est déjà plus que ce que fait le reste du monde."
    else:
        c normal "Encore toi. Tu vas finir par connaître le surveillant mieux que moi."
        if not fait("silhouette_racontee"):
            call clara_silhouette
        elif rel["clara"] >= 5 and not fait("dossier_v"):
            c pensif "J'ai repensé à la silhouette. Le dossier qu'elle portait… il avait quelque chose de doré sur la couverture. Comme une lettre."
            c "Un V. Je crois que c'était un V."
            $ noter("dossier_v")
        else:
            c sourire "Raconte-moi quelque chose de normal. N'importe quoi. Le temps qu'il fait. Ce que tu as mangé."
            narrator "Je lui raconte la cantine, les plateaux, Lucas qui renverse son jus. Elle rit. Le surveillant aussi, un peu."
            $ lien("clara", 1)
            $ varier(moral=1)
    $ varier(energie=-1)
    hide clara with fondu
    return

label clara_silhouette:
    $ noter("silhouette_racontee")
    c pensif "La silhouette ? Derrière les vitres, à vingt et une heures trente. Je l'ai dessinée sans réfléchir, dans le coin."
    c "Quelqu'un de petit. Les cheveux relevés. Un dossier contre la poitrine."
    $ examiner("carnet")
    if temperament == "empathique" or rel["clara"] >= 6:
        c "Et… c'est bête, mais en repartant, quand on est passés près de la porte de côté, ça sentait la violette. Un parfum de vieille dame chic."
        $ noter("violette_clara")
    return

################################################################################
## Laboratoire
################################################################################

label lieu_labo:
    $ n = visite("labo")
    if moment == "nuit":
        scene bg labo nuit with fondu
        show neon_gresille
    else:
        scene bg labo with fondu
    $ musique_jouer("nuit")

    $ peut_entrer = filiere == "sciences" or niveau("malo") >= 4 or temperament == "audacieux"
    if not peut_entrer:
        narrator "Un agent en uniforme garde la porte. Il ne me regarde même pas."
        agent "Scellés. Personne n'entre. Circulez."
        narrator "En repartant, j'aperçois dans la cour un grand étudiant mince qui fixe les fenêtres du laboratoire. Quand il me voit, il s'en va."
        $ noter("vu_nathan_labo")
        $ varier(energie=-1)
        return

    if niveau("malo") >= 4 and moment != "nuit":
        show malo normal at centre with fondu
        m "Tiens. {g=Le/La} détective amateur."
        m "Je n'ai rien vu. Tu as dix minutes. Tu ne touches à rien sans gants."
        hide malo with fondu
    elif filiere == "sciences":
        narrator "Par la salle d'analyse attenante, que mon badge d'étudiant en sciences ouvre encore, je me glisse jusqu'au laboratoire."
    else:
        narrator "J'attends que l'agent parte fumer. Quatre minutes. Je soulève le ruban et j'entre."
        $ noter("scelles_forces")

    narrator "Le laboratoire. La craie sur le sol. La paillasse du fond, avec son angle de pierre noire."
    if a("epingle"):
        narrator "Je refais le tour de la pièce. Je ne trouve rien de plus que la dernière fois."
    elif fatigue() and filiere != "sciences":
        narrator "Je fouille, mais mes yeux brûlent. Les carreaux se brouillent. Je passe la main sous les paillasses sans rien sentir."
        pensee "Si seulement j'avais dormi. Il y a peut-être quelque chose ici, et je ne le vois pas."
        $ noter("rate_epingle")
    elif M("epingle") == "escalier":
        narrator "Je regarde sous chaque paillasse, derrière chaque armoire. Rien."
        narrator "Mais au fond de la salle, la petite porte de service est entrouverte. Elle donne sur l'escalier qui monte vers l'administration."
        pensee "Celui par lequel l'ombre s'est enfuie. Il faudrait le fouiller, depuis le couloir de l'administration."
        $ noter("piste_escalier")
    else:
        narrator "La police a fouillé autour du corps. Pas dessous. Je m'allonge sur le carrelage froid et je regarde sous la paillasse."
        narrator "Quelque chose brille contre la plinthe."
        $ obtenir("epingle")
        pensee "Clara a les cheveux lâchés. Toujours."

    if filiere == "sciences" and a("azur") and "azur" not in preuves_examinees:
        narrator "Dans la salle d'analyse, je passe une pastille d'Azur au spectromètre. Il me faut vingt minutes pour comprendre ce que je lis."
        $ examiner("azur")
        narrator "Le réactif principal porte un marqueur de lot : {b}VAL-23{/b}. Le stock du laboratoire de Valcourt."
        pensee "L'Azur n'arrive pas à Valcourt. Il en sort."
        $ noter("azur_analyse")

    if fait("scelles_forces"):
        narrator "En ressortant, je tombe nez à nez avec l'agent qui revient. Il me fixe, puis note quelque chose dans son carnet."
        $ lien("malo", -1, silencieux=True)
    $ varier(energie=-1)
    return

################################################################################
## Bibliothèque — Mme Bernier et le Livre
################################################################################

label lieu_bibliotheque:
    $ n = visite("bibliotheque")
    if moment == "nuit":
        scene bg bibliotheque nuit with fondu
    else:
        scene bg bibliotheque with fondu
    $ musique_jouer("boucle")
    $ ambiance("horloge")

    if n == 1 and moment != "nuit":
        show bernier normal at centre with fondu
        $ rencontrer("bernier")
        ob "Vous êtes {g=l'ami/l'amie} de la petite Delaunay. Elle venait tous les soirs, vous savez. Toujours à la réserve."
        ob "Elle lisait un seul livre. Toujours le même."
        moi "Lequel ?"
        ob "Le {i}Livre des Sept Jours{/i}. Un manuscrit du fondateur, Aurèle de Valcourt. Une curiosité."
        ob "La légende dit que celui qui y écrit son nom revit le troisième jour, autant de fois qu'il reste de pages."
        ob "Des bêtises de vieux bibliothécaires. Mais la petite y croyait. Elle disait qu'il ne restait plus que trois pages."
        ob "Depuis mercredi, le livre a disparu de son étagère. Je l'ai cherché partout."
        $ noter("legende_livre")
        hide bernier with fondu

    if not possede("marque_page"):
        narrator "Je parcours la réserve. Des milliers de reliures, et aucune qui me parle."
        pensee "Iris disait que son marque-page « connaissait le chemin ». Je ne l'ai pas pris. Je ne le saurai jamais."
        $ varier(energie=-1)
        $ ambiance(None)
        return

    if a("usb"):
        narrator "Le Livre est à sa place, derrière les encyclopédies. Il ne me dit rien de plus. Pas encore."
        $ ambiance(None)
        return

    if fait("livre_trouve"):
        narrator "Je retourne au Livre. La clé USB m'attend toujours entre les deux dernières pages."
        jump biblio_mot_de_passe

    narrator "Dans ma poche, le marque-page est tiède. Plus je m'enfonce dans la réserve, plus il chauffe."
    narrator "Il devient presque brûlant devant une rangée d'encyclopédies reliées. Derrière elles, cachée, une reliure dorée."
    show livre_ferme at Transform(xalign=0.5, yalign=0.45, zoom=0.6) with fondu
    $ son("livre")
    narrator "{i}Le Livre des Sept Jours.{/i} Le cuir est usé, le titre presque effacé. Les pages sont couvertes de noms, tous barrés, sauf le dernier."
    narrator "{i}Iris Delaunay.{/i} Écrit quatre fois. Barré trois fois."
    if M("cache_usb") == "gazette":
        narrator "Il reste trois pages blanches. Et entre les deux dernières, une enveloppe. Pas de clé."
    else:
        narrator "Il reste trois pages blanches. Et entre les deux dernières, une enveloppe et une petite clé USB."
    hide livre_ferme with fondu
    $ noter("livre_trouve", "lettre_iris")
    $ donner("lettre_iris")
    $ musique_jouer("tristesse")
    narrator "{i}« [joueur_nom],"
    narrator "{i}si tu lis ceci, c'est que j'ai encore échoué. Ce sera la quatrième fois.{/i}"
    narrator "{i}Je sais que tu ne me crois pas. Moi non plus, la première fois, je n'y croyais pas.{/i}"
    narrator "{i}À chaque fois, je meurs mercredi soir. À chaque fois, j'essaie de faire autrement, et à chaque fois, elle arrive avant moi.{/i}"
    $ _rang = M("rang_mdp", "premier")
    if M("cache_usb") == "gazette":
        narrator "{i}Le registre est sur une clé. Je l'ai confiée à Amélie, à la Gazette : elle ne sait pas ce qu'elle contient. Le mot de passe est le [_rang] mot de notre devise.{/i}"
    else:
        narrator "{i}Le registre est sur la clé. Le mot de passe est le [_rang] mot de notre devise.{/i}"
    narrator "{i}Et si jamais tu écris ton nom dans ce livre, si tu reviens mercredi, viens me trouver et dis-moi : ARIANE. Je saurai que c'est vrai. Je l'ai choisi pour ça : pour sortir du labyrinthe.{/i}"
    narrator "{i}Pardon de t'avoir choisi{g=/e}. Tu étais la seule personne qui ne faisait partie de rien. — I. »{/i}"

    pensee "Le [_rang] mot de notre devise."
    if M("cache_usb") == "gazette":
        $ noter("usb_chez_amelie")
        pensee "La clé est chez Amélie. Il faudra passer à la cantine, ou à la Gazette."
        $ varier(energie=-1)
        $ ambiance(None)
        return
    jump biblio_mot_de_passe

label biblio_mot_de_passe:
    narrator "J'allume l'ordinateur public de la salle de lecture et j'y branche la clé. Une fenêtre s'ouvre : {i}« Mot de passe : »{/i}"
    $ essais = 0
    while essais < 3:
        $ mdp = saisie("Mot de passe de la clé USB d'Iris :", indice="« Le %s mot de notre devise. »" % M("rang_mdp", "premier"), mode="ecrit")
        if normaliser(mdp) == M("mdp", "veritas") or (deja_vu("livre") and normaliser(mdp) == "veritas justitia libertas" and M("mdp") == "veritas"):
            $ essais = 99
        else:
            $ essais += 1
            narrator "{i}Mot de passe incorrect.{/i}"
    if essais == 99:
        $ son("clic")
        narrator "Le dossier s'ouvre. Un tableur, intitulé {i}Registre Azur{/i}."
        narrator "Des dates, chaque jeudi. Des quantités. Un lieu, toujours le même : {b}Quai 7{/b}. Deux colonnes d'initiales : {b}E.L.{/b} pour les paiements, {b}N.R.{/b} pour la « production »."
        $ obtenir("usb")
        $ examiner("usb")
        $ noter("soupcon_eleonore")
        pensee "E.L. Il y a dans cette école quelqu'un qui a « les clés de tout »."
    else:
        narrator "Trois essais. L'écran se verrouille. Je retire la clé : je pourrai réessayer, mais pas aujourd'hui."
    $ varier(energie=-1)
    $ ambiance(None)
    return

################################################################################
## Cantine — Lucas et Amélie
################################################################################

label lieu_cantine:
    scene bg cantine with fondu
    $ ambiance("salle")
    $ musique_jouer("quotidien")
    $ n = visite("cantine")
    if argent >= 2:
        menu:
            "Prendre un café à la machine (2 €) ?"
            "Oui.":
                $ acheter("cafe", 2)
            "Non.":
                pass

    menu:
        "Parler à Lucas." if not a("azur"):
            call cantine_lucas
        "Parler à Amélie." if not a("photo_bal"):
            call cantine_amelie
        "Écouter les conversations.":
            narrator "On parle d'Iris à toutes les tables. De Clara aussi. « La timide, là, avec ses crayons. On l'aurait jamais cru. »"
            pensee "Personne ne l'aurait cru parce que ce n'est pas vrai."
            $ varier(moral=-1)
    $ ambiance(None)
    return

label cantine_lucas:
    show lucas normal at centre with fondu
    lu "Hugo va mieux. Il sort de l'hôpital lundi. Il ne se souvient de rien, juste qu'il a « pris son truc » avant le bal."
    $ q = 0
    while q < 3:
        $ reponse = saisie("Que demandez-vous à Lucas ?", sujets=pistes_connues() + ["Hugo"])
        $ sujet = comprendre(reponse, [
            ("azur", ["azur", "truc", "pastille", "drogue", "pilule", "bleu", "sachet", "produit"]),
            ("vendeur", ["qui", "vendeur", "vend", "dealer", "fournisseur", "nathan", "acheter"]),
            ("hugo", ["hugo", "sante", "hopital", "malaise"]),
            ("fin", ["merci", "au revoir", "rien", "salut", "a plus"]),
        ])
        if sujet == "azur":
            lu "Son truc ? Des petites pastilles bleues. J'en ai trouvé un sachet dans son tiroir. Je ne savais pas quoi en faire, je ne voulais pas le dénoncer."
            lu "Tiens. Prends-le. Si ça peut servir à quelque chose…"
            $ obtenir("azur")
            $ noter("piste_azur")
            $ q += 1
        elif sujet == "vendeur":
            lu "Il ne m'a jamais dit qui. Juste que c'était « quelqu'un de la chimie, un type sérieux, qui ne parle à personne »."
            $ noter("vendeur_chimie")
            $ q += 1
        elif sujet == "hugo":
            lu "Il a eu de la chance. Le médecin a dit que dix minutes de plus, et…"
            lu "Il dormait trois heures par nuit. Ses parents l'appelaient tous les soirs pour lui rappeler combien coûtait l'Académie."
            $ q += 1
        elif sujet == "fin":
            $ q = 99
        else:
            lu "Euh… je ne vois pas trop de quoi tu parles."
            $ q += 1
    lu "Fais gaffe à toi, d'accord ?"
    $ varier(energie=-1)
    hide lucas with fondu
    return

label cantine_amelie:
    show amelie normal at centre with fondu
    am "Mon chou. Tu as une tête à faire peur."
    am "La Gazette va publier un hommage à Iris. Elle était notre meilleure plume. Elle disait qu'elle préparait « l'article de sa vie »."
    $ q = 0
    while q < 3:
        $ reponse = saisie("Que demandez-vous à Amélie ?", sujets=pistes_connues() + ["photos du bal"])
        $ sujet = comprendre(reponse, [
            ("photo", ["photo", "photos", "bal", "appareil", "image", "cliche", "enveloppe", "escalier"]),
            ("article", ["article", "enquete", "publier", "iris", "plume", "gazette"]),
            ("nathan", ["nathan", "roussel", "chimie"]),
            ("fin", ["merci", "au revoir", "rien", "salut"]),
        ])
        if sujet == "photo":
            am "J'ai mitraillé toute la soirée ! Attends, je regarde…"
            narrator "Elle fait défiler des centaines d'images. Des costumes, des rires, des verres levés. Puis elle s'arrête."
            am "Tiens. Celle-là, au fond, près de l'escalier. C'est bizarre, non ?"
            if filiere == "lettres" or niveau("amelie") >= 4:
                am "Je te la transfère. Entre gens de plume, on se fait confiance."
                $ obtenir("photo_bal")
                $ examiner("photo_bal")
            else:
                am "Je ne peux pas te la donner comme ça, c'est un document de la Gazette. Mais je peux t'en imprimer un tirage. Trois euros, le prix du papier."
                if argent >= 3:
                    menu:
                        "Payer le tirage (3 €).":
                            $ varier(argent=-3)
                            $ donner("photo_imprimee", silencieux=True)
                            $ obtenir("photo_bal")
                        "Refuser.":
                            am "Comme tu veux."
                else:
                    pensee "Je n'ai même pas trois euros."
            $ q += 1
        elif sujet == "article" and fait("usb_chez_amelie") and not a("usb"):
            am "Iris ? Attends… Elle m'a laissé un truc, lundi. « Si je ne viens pas le chercher, donne-le à {g=celui/celle} qui prononcera le nom de la Gazette avec mon prénom. »"
            am "C'est toi, j'imagine. Tiens."
            narrator "Elle me tend une petite clé USB, entourée d'un ruban bleu. Je file à l'ordinateur de la Gazette."
            $ q = 99
            call biblio_mot_de_passe
        elif sujet == "article":
            am "Elle ne m'a jamais montré une ligne. Elle disait : « Si je te le montre, tu es en danger. » Je trouvais ça dramatique. Maintenant…"
            $ lien("amelie", 1)
            $ q += 1
        elif sujet == "nathan":
            am "Nathan Roussel ? Brillant, mutique, endetté jusqu'au cou. Ses parents ont perdu leur commerce l'an dernier. Il paye tout seul ses études."
            $ noter("nathan_dettes")
            $ q += 1
        elif sujet == "fin":
            $ q = 99
        else:
            am "Hm ? Pose-moi une vraie question, je suis journaliste, pas voyante."
            $ q += 1
    $ varier(energie=-1)
    hide amelie with fondu
    return

################################################################################
## Administration — Éléonore Lambert
################################################################################

label lieu_administration:
    scene bg couloir with fondu
    $ musique_jouer("mystere")
    $ n = visite("administration")
    if M("epingle") == "escalier" and not a("epingle"):
        narrator "Au bout du couloir, la porte de l'escalier de service. Celui qui descend vers l'aile des sciences."
        if fatigue() and temperament != "logique":
            narrator "Je descends quelques marches, mais la lumière est mauvaise et mes yeux se ferment tout seuls."
        else:
            narrator "Sur la troisième marche, coincée dans une fente du bois, une petite chose dorée."
            $ obtenir("epingle")
            pensee "Quelqu'un est passé par ici cette nuit-là. Quelqu'un avec un chignon."
    if jour == 5:
        narrator "Le bureau d'Éléonore Lambert est vide. Un mot sur la porte : {i}« Absente ce matin — rendez-vous à la préfecture. »{/i}"
        narrator "La porte n'est pas fermée à clé. Sur le bureau, un agenda en cuir, ouvert."
        if a("agenda"):
            narrator "Je l'ai déjà photographié. Je ne m'attarde pas."
        elif fatigue() and temperament != "logique":
            narrator "Les lignes dansent devant mes yeux. Des rendez-vous, des noms, des heures. Des pas dans le couloir : je dois partir avant d'avoir compris quoi que ce soit."
        else:
            narrator "Mercredi 15 octobre. Une ligne soignée : {i}« Réception des donateurs — 19 h / 22 h. »{/i}"
            $ obtenir("agenda")
            pensee "Vingt-deux heures. Pas vingt-trois."
        $ varier(energie=-1)
        return

    show eleonore normal at centre with fondu
    $ rencontrer("eleonore")
    el "Vous êtes {g=l'assistant/l'assistante} de Monsieur Varga. Il m'a prévenue. Je vous accorde cinq minutes."
    el "Je ne sais pas grand-chose, vous savez. Je ne suis qu'une secrétaire."
    narrator "Sur son bureau trône une vieille machine à écrire mécanique, noire et dorée. « Madame Varga la trouve charmante », dit-elle en suivant mon regard."
    if a("lettre_anonyme"):
        narrator "Une feuille est encore engagée dans le rouleau. Les lettres bavent un peu. Et le « e » saute au-dessus de la ligne."
        pensee "Comme sur la lettre glissée sous ma porte."
        $ examiner("lettre_anonyme")
        $ noter("lettre_machine", "soupcon_eleonore")
        $ souvenir("Sur le bureau d'Éléonore, la machine à écrire de la lettre anonyme.", "eleonore normal")
    $ q = 0
    while q < 4:
        $ reponse = saisie("Que demandez-vous à Éléonore Lambert ?", sujets=pistes_connues() + ["clés", "réception"])
        $ sujet = comprendre(reponse, [
            ("reception", ["reception", "soiree", "mercredi", "ou etiez", "alibi", "22", "23", "heure", "donateurs"]),
            ("cles", ["cle", "cles", "badge", "passe", "porte", "acces"]),
            ("enveloppe", ["enveloppe", "bal", "escalier", "argent"]),
            ("nathan", ["nathan", "roussel", "etudiant", "chimie"]),
            ("azur", ["azur", "drogue", "bleu", "trafic", "registre", "quai"]),
            ("iris", ["iris", "delaunay", "victime", "article"]),
            ("violette", ["violette", "parfum", "odeur"]),
            ("fin", ["merci", "au revoir", "rien"]),
        ])
        if sujet == "reception":
            el "J'étais à la réception de Madame Varga, toute la soirée. Jusqu'à vingt-trois heures, au moins. Des dizaines de personnes peuvent en témoigner."
            $ noter("mensonge_eleonore_23h")
            if fait("reception_finie_22h"):
                pensee "Vingt-trois heures ? J'y étais. La directrice a clos la soirée à vingt-deux heures. Et je l'ai vue partir par l'escalier de service à vingt-deux heures cinq."
                $ noter("soupcon_eleonore")
        elif sujet == "cles":
            el "Je gère les clés de la direction, oui. Le passe général reste dans mon tiroir, fermé à clé. Je suis la seule à avoir la clé du tiroir."
            el "Enfin. Madame Varga aussi, bien sûr."
            $ noter("eleonore_passe")
        elif sujet == "enveloppe":
            if fait("vu_eleonore") or a("photo_bal"):
                show eleonore surprise
                el "Une enveloppe ? Des invitations. Pour les donateurs."
                el normal "Vous avez de bons yeux. On vous l'a déjà dit ?"
                $ noter("soupcon_eleonore")
            else:
                el "Je ne vois pas de quoi vous parlez."
        elif sujet == "nathan":
            el "Nathan Roussel ? Je ne connais pas tous les étudiants par leur nom, vous savez."
            $ noter("mensonge_eleonore_nathan")
        elif sujet == "azur":
            show eleonore souci
            el "Ces rumeurs de drogue… Madame Varga ne veut pas en entendre parler. Moi non plus."
        elif sujet == "iris":
            el souci "Une jeune femme brillante. Trop curieuse, peut-être. C'est terrible, ce qui est arrivé."
            el normal "Mais votre amie avait des raisons de lui en vouloir, non ? Toute la cantine les a entendues."
        elif sujet == "violette":
            el surprise "Pardon ?"
            narrator "Elle porte la main à son cou, un geste instinctif. Une odeur légère flotte autour d'elle. Sucrée. Poudrée."
            pensee "De la violette."
            $ noter("eleonore_violette", "soupcon_eleonore")
            el normal "Je crois que nos cinq minutes sont écoulées."
            $ q = 99
        elif sujet == "fin":
            $ q = 99
        else:
            el "Je ne comprends pas votre question."
        $ q += 1
    el "Bonne journée. Et… prenez soin de vous. Cette école n'est pas tendre avec les gens trop curieux."
    $ varier(energie=-1)
    hide eleonore with fondu
    return

################################################################################
## Bureau de la directrice
################################################################################

label lieu_bureau:
    $ n = visite("bureau")
    if moment in ("soir", "nuit"):
        scene bg bureau directrice nuit with fondu
        $ musique_jouer("tension")
        narrator "Le bureau est plongé dans le noir. Je referme la porte derrière moi sans un bruit. Mon cœur fait assez de bruit pour deux."
        if not a("badges"):
            narrator "Sur l'ordinateur resté allumé, le logiciel de gestion des portes. Je fais défiler le journal de mercredi soir."
            $ obtenir("badges")
            $ noter("soupcon_eleonore")
        if not a("agenda"):
            if fatigue():
                narrator "Un agenda sur une étagère. Je l'ouvre, mais une lumière s'allume dans le couloir. Je dois fuir avant d'avoir lu quoi que ce soit."
            else:
                narrator "Dans un tiroir, la copie de l'agenda de direction. Mercredi : « Réception — 19 h / 22 h »."
                $ obtenir("agenda")
        $ son("pas_course")
        narrator "Des pas. Je ressors par la porte de service, le souffle court."
        $ varier(energie=-1, moral=-1)
        return

    scene bg bureau directrice with fondu
    $ musique_jouer("mystere")
    show isabella normal at centre with fondu
    isa "Vous avez trois minutes. Je les donne par respect pour mon frère, pas pour vous."
    menu:
        "Demander le registre des badges." if not a("badges"):
            isa "Le registre appartient à l'Académie. Je ne le communique qu'à la police, sur réquisition."
            if niveau("isabella") >= 5:
                isa pensif "…Mais puisque cela pourrait innocenter l'institution, tenez."
                $ obtenir("badges")
            else:
                isa "Ce que mon frère obtiendra par la voie légale, vous ne l'obtiendrez pas par la porte de derrière."
        "Lui parler d'Iris.":
            isa "Iris Delaunay était la meilleure étudiante de sa promotion. Et la plus imprudente."
            isa pensif "Elle est venue me voir, la semaine dernière. Elle m'a dit : « Il y a quelque chose de pourri dans votre école. » Je l'ai renvoyée à ses cours."
            isa "Si j'avais écouté…"
            $ lien("isabella", 1)
        "Lui parler de Clara.":
            isa "Clara Morel aura un procès équitable. C'est tout ce que Valcourt doit à ses étudiants."
            if empathie_possible():
                moi "Valcourt lui doit aussi la vérité. C'est écrit au-dessus du portail."
                isa "…Vous avez du cran. Mon frère a bien choisi."
                $ lien("isabella", 1)
    $ varier(energie=-1)
    hide isabella with fondu
    return

################################################################################
## Commissariat — Malo
################################################################################

default montre_a_malo = set()

label lieu_commissariat:
    scene bg commissariat with fondu
    $ musique_jouer("enquete")
    $ n = visite("commissariat")
    show malo normal at centre with fondu
    if n == 1:
        m "Tiens. {g=L'étudiant/L'étudiante} qui voit des choses."
        m "Ton amie est dans de sales draps. Le carnet, la dispute, l'absence d'alibi. Pour un juge, c'est un dossier propre."
        m pensif "Moi, je n'aime pas les dossiers propres. Il y a toujours quelqu'un qui a fait le ménage."
    else:
        m "Encore toi. Café ? Il est froid. Il est toujours froid."

    $ continuer = True
    while continuer:
        menu:
            "Lui montrer une preuve.":
                $ code = renpy.call_screen("dossier", presenter=True, question="Quelle preuve montrer à Malo ?")
                if code is None:
                    pass
                elif code in montre_a_malo:
                    m "Tu me l'as déjà montrée. Je ne suis pas sénile."
                elif code in ("epingle", "badges", "usb", "azur", "photo_bal", "agenda", "message") or (code == "carnet" and "carnet" in preuves_examinees):
                    $ montre_a_malo.add(code)
                    $ lien("malo", 1)
                    if code == "carnet":
                        m "Vingt et une heures trente sur l'horloge du dessin, et une silhouette au chignon. Elle dessinait de dehors… Intéressant."
                    elif code == "epingle":
                        m determine "Sous la paillasse. Mes gars ont fouillé autour, pas dessous. Je vais leur passer un savon."
                    elif code == "badges":
                        m "Le passe de direction à vingt-deux heures trente et une. Et on ne me l'a pas transmis. Évidemment."
                    elif code == "usb":
                        m surprise "Le Registre Azur. Quai 7, chaque jeudi. E.L., N.R."
                        m determine "Ça fait six mois que je cherche ce quai."
                        $ noter("malo_sait_quai")
                    elif code == "azur":
                        m "Encore un sachet. Si on pouvait remonter au labo qui les fabrique…"
                        if "azur" in preuves_examinees:
                            m surprise "Lot VAL-23 ? Le stock de l'Académie ? Tu es en train de me dire que ça sort de l'école ?"
                    elif code == "photo_bal":
                        m "Lambert et Roussel. L'assistante de la directrice et un étudiant de chimie. Une enveloppe épaisse."
                    elif code == "agenda":
                        m "Réception terminée à vingt-deux heures. Quelqu'un ment sur son emploi du temps."
                    elif code == "message":
                        m "« Elle a les clés de tout. » Iris savait. Et elle n'a pas voulu de la police. Ça, ça me fait mal."
                else:
                    m "Et ? Ça ne prouve rien. Reviens avec du concret."
            "Lui demander la vidéo du couloir." if niveau("malo") >= 5 and not a("video"):
                m "La vidéo a été effacée jeudi matin, par l'administration. Une « maintenance »."
                m pensif "Mais le prestataire garde une sauvegarde de vingt-quatre heures. J'ai fait jouer un ami."
                m "Couloir des sciences, vingt-deux heures trente-cinq. Regarde."
                $ obtenir("video")
                $ examiner("video")
            "Lui demander de venir au quai 7 vendredi soir." if (a("usb") or fait("quai7_tot")) and not fait("malo_port") and (not fait("malo_refus_port") or niveau("malo") >= 4):
                if niveau("malo") >= 4:
                    m "Vendredi soir, quai 7. Je préviens deux collègues. Toi, tu ne fais rien sans moi. C'est clair ?"
                    $ noter("malo_port")
                else:
                    m "Une étudiante morte, un registre trouvé dans un livre magique, un quai… Tu me demandes de mobiliser une équipe sur ta parole ?"
                    m "Donne-moi plus que ça."
                    $ noter("malo_refus_port")
            "Partir.":
                $ continuer = False
    m "File. Et dors un peu. Tu as une tête de suspect."
    $ varier(energie=-1)
    hide malo with fondu
    return

################################################################################
## Port — Quai 7 (vendredi soir)
################################################################################

label lieu_port:
    scene bg rue with fondu
    $ ambiance("ville")
    narrator "Le port est à quarante minutes à pied, vingt en bus, dix en taxi."
    $ en_retard = False
    if argent >= 15:
        menu:
            "Prendre un taxi (15 €).":
                $ varier(argent=-15)
            "Prendre le bus (gratuit avec la carte d'étudiant).":
                $ en_retard = True
    else:
        narrator "Quinze euros pour un taxi. Je ne les ai plus."
        $ en_retard = True

    scene bg port nuit
    show pluie_fine
    with fondu
    $ ambiance("port")
    $ musique_jouer("tension")
    $ poser_heure("VENDREDI · 21 H 40" if not en_retard else "VENDREDI · 22 H 05")
    narrator "Le quai 7. Le hangar au grand chiffre blanc. Une camionnette, portes ouvertes. Un bateau bleu à quai."

    if fait("malo_port"):
        show malo determine at gauche with fondu
        m "Tu es en retard. Ou pile à l'heure. Reste derrière moi."
        show nathan normal at droite with fondu
        $ rencontrer("nathan")
        narrator "Un grand étudiant mince charge des caisses dans la camionnette. Nathan Roussel."
        m "Police. Nathan Roussel, on va parler."
        narrator "Il ne court pas. Il pose sa caisse, très doucement, et s'assoit sur le quai comme si ses jambes avaient lâché."
        na "Enfin."
        na "Je voulais arrêter. Depuis des semaines. Elle m'a dit qu'Iris allait tout gâcher, qu'on irait tous en prison, moi le premier."
        na "Elle avait les clés du labo, les horaires des gardiens, tout. Elle payait mes dettes. Et après, elle me tenait."
        m "Qui, « elle » ?"
        na "Lambert. Éléonore Lambert."
        $ obtenir("temoignage")
        $ noter("aveu_nathan", "reseau_demantele")
        $ lien("malo", 2)
    elif temperament == "audacieux" and not en_retard:
        show nathan normal at centre with fondu
        $ rencontrer("nathan")
        narrator "Nathan Roussel charge des caisses, seul. Je m'avance dans la lumière."
        moi "Nathan. Je sais pour le quai 7. Je sais pour E.L."
        narrator "Il lâche sa caisse. Puis tout va très vite : un homme sort du hangar, quelqu'un me pousse, ma tête heurte un poteau."
        with tremblement_ecran
        $ son("choc")
        narrator "Quand je rouvre les yeux, Nathan est agenouillé près de moi. L'homme est parti avec la camionnette."
        na "Pourquoi tu es venu{g=/e} seul{g=/e}, espèce d'idiot{g=/e} ? Ils auraient pu…"
        na "C'est Lambert. Éléonore Lambert. C'est elle qui tient tout. Je le dirai. Je le dirai au juge. J'en ai assez."
        $ obtenir("temoignage")
        $ noter("aveu_nathan")
        $ varier(energie=-3, moral=-1)
    elif temperament == "empathique" and not en_retard:
        show nathan normal at centre with fondu
        $ rencontrer("nathan")
        narrator "Nathan est assis au bord du quai, une caisse à ses pieds. Il ne charge rien. Il regarde l'eau."
        moi "Tu n'es pas obligé de continuer, Nathan."
        na "Tu ne sais rien de moi."
        moi "Je sais que tu ne dors plus. Que tu as des dettes. Que quelqu'un s'en sert."
        narrator "Il pleure. Sans bruit. Puis il me raconte tout."
        $ obtenir("temoignage")
        $ noter("aveu_nathan")
    else:
        narrator "J'arrive trop tard. La camionnette démarre, phares éteints. Le bateau bleu s'éloigne déjà du quai."
        narrator "Sur le béton mouillé, il ne reste que des traces de pneus et une odeur de gasoil."
        pensee "Ils seront ailleurs demain. Et je n'ai rien."
        $ varier(moral=-1)
    $ varier(energie=-1)
    $ ambiance(None)
    return

################################################################################
## Chambre
################################################################################

label lieu_chambre:
    if moment == "nuit":
        scene bg chambre nuit with fondu
    else:
        scene bg chambre with fondu
    $ musique_jouer("quotidien")
    menu:
        "Dormir." if moment == "nuit":
            narrator "Je m'endors tout habillé{g=/e}, le Dossier ouvert sur la poitrine."
            $ dormi_cette_nuit = True
        "Faire une sieste." if moment != "nuit":
            narrator "Deux heures de sommeil lourd, sans rêves."
            $ varier(energie=3)
        "Appeler Maëlle.":
            ma "Tiens, un miracle. Tu as encore un téléphone ?"
            if fait("appel_rejete"):
                ma "Maman va mieux. Elle est rentrée. Elle demandait de tes nouvelles, je lui ai dit que tu étais très {g=occupé/occupée}."
            else:
                ma "Maman va mieux. Elle fait semblant de se reposer. En vrai, elle repasse tout l'immeuble."
            ma "Et toi ? Tu ne dis rien, mais je t'entends. Tu portes un truc trop lourd."
            moi "Une amie est accusée de quelque chose qu'elle n'a pas fait. Et je suis peut-être la seule personne qui peut le prouver."
            ma "Alors prouve-le. Et après, tu dors. Dans cet ordre."
            $ cocher("appeler_maelle")
            $ varier(moral=2)
            if moment == "nuit":
                $ dormi_cette_nuit = True
        "Préparer la plaidoirie de samedi.":
            narrator "J'étale toutes les pièces sur le lit et je cherche ce qui cloche. L'heure du dessin. L'heure du décès. L'heure du badge."
            narrator "Je relis chaque preuve, une par une."
            python:
                for _c in preuves:
                    examiner(_c)
            $ noter("plaidoirie_prete")
            $ varier(energie=-1)
    return
