## Jour 6 — Samedi : l'audience.

init python:

    ## Chaque déclaration : texte, lignes dites quand on « presse », preuves qui
    ## la contredisent, et éventuellement une condition qui la fait tomber dès
    ## qu'on la presse (un témoin que l'on peut appeler, un souvenir).
    TEMOIGNAGES = {
        "malo": dict(
            temoin="Malo Deschamps",
            succes="ci_malo_brise",
            declarations=[
                dict(texte="Le décès d'Iris Delaunay est survenu vers vingt-deux heures quarante, d'après le légiste.",
                     presser=[("m", "Le légiste est formel, à dix minutes près. Chute contre l'angle de la paillasse, après une lutte.")]),
                dict(texte="Le carnet de l'accusée a été retrouvé au sol, à côté du corps.",
                     presser=[("m", "À cinquante centimètres de sa main. Sec, d'ailleurs. Alors qu'il pleuvait des cordes dehors."),
                              ("pensee", "Sec. Il était sous l'auvent, sur le banc. Quelqu'un l'a porté à l'intérieur.")]),
                dict(texte="L'accusée a reconnu avoir dessiné le laboratoire ce soir-là.",
                     presser=[("m", "Elle ne l'a jamais nié. Elle dit qu'elle dessinait « depuis la cour ». Rien ne le prouve.")]),
                dict(texte="Elle se trouvait donc au laboratoire au moment du drame.",
                     presser=[("m", "Le carnet est à côté du corps, elle a dessiné l'endroit. Pour moi, ça suffit à la placer sur les lieux.")],
                     preuves=("carnet",), contradiction=True),
            ]),
        "eleonore_a": dict(
            temoin="Éléonore Lambert",
            succes="ci_eleonore_a_brise",
            declarations=[
                dict(texte="Mercredi soir, je me trouvais à la réception de Madame Varga, dans les salons de la direction.",
                     presser=[("el", "J'y suis toujours. C'est mon travail. Je tiens le registre des invités, les cartons, les manteaux.")]),
                dict(texte="La réception s'est prolongée jusqu'à vingt-trois heures. Je n'ai pas quitté les salons.",
                     presser=[("el", "Vingt-trois heures, peut-être un peu plus. Les donateurs aiment s'attarder.")],
                     preuves=("agenda",), contradiction=True,
                     presser_succes="peut_contredire_reception"),
                dict(texte="Vers vingt-deux heures quarante-cinq, depuis la fenêtre des salons, j'ai vu l'accusée sortir en courant de l'aile des sciences.",
                     presser=[("el", "La cour est éclairée. Je l'ai reconnue à ses cheveux, longs et lâchés. Elle courait sous la pluie.")]),
                dict(texte="Elle serrait quelque chose contre elle. Son carnet, sans doute : elle ne s'en sépare jamais.",
                     presser=[("el", "Un objet rectangulaire, brun. Je suis formelle.")],
                     preuves=("carnet", "rapport"), contradiction=True),
            ]),
        "eleonore_b": dict(
            temoin="Éléonore Lambert",
            succes="ci_eleonore_b_brise",
            declarations=[
                dict(texte="Je n'ai jamais mis les pieds dans ce laboratoire. Ce n'est pas mon service.",
                     presser=[("el", "Je travaille à la direction. Les éprouvettes, très peu pour moi.")],
                     preuves=("epingle",), contradiction=True),
                dict(texte="Je n'ai d'ailleurs aucun moyen d'y entrer : seuls les chimistes en ont le badge.",
                     presser=[("el", "Les portes de l'aile des sciences sont électroniques. Sans badge de chimiste, elles restent fermées.")],
                     preuves=("badges",), contradiction=True),
                dict(texte="Et ce n'est pas mon genre de me promener dans les couloirs la nuit.",
                     presser=[("el", "Je rentre chez moi à pied, tous les soirs, par la grande porte. Le gardien peut en témoigner.")],
                     preuves=("video",), contradiction=True),
            ]),
        "eleonore_c": dict(
            temoin="Éléonore Lambert",
            succes="ci_eleonore_c_brise",
            declarations=[
                dict(texte="Je ne connais pas cet étudiant dont parle la défense. Nathan Roussel.",
                     presser=[("el", "Il y a mille deux cents étudiants à Valcourt. Je ne peux pas tous les connaître.")],
                     preuves=("photo_bal", "temoignage"), contradiction=True),
                dict(texte="Et je n'ai jamais entendu parler de cette prétendue drogue, « l'Azur ».",
                     presser=[("el", "Des rumeurs d'étudiants. Il y en a chaque année.")],
                     preuves=("usb", "temoignage"), contradiction=True),
                dict(texte="Je n'ai jamais menacé personne dans cette école. Ce n'est pas mon genre.",
                     presser=[("el", "Menacer ? Moi ? Je suis la personne la plus discrète de Valcourt.")],
                     preuves=("lettre_anonyme",), contradiction=True),
                dict(texte="Mon travail, c'est l'agenda de Madame Varga. Rien d'autre.",
                     presser=[("el", "Je suis une assistante. Je n'ai ni pouvoir, ni ambition.")]),
            ]),
    }

    def peut_contredire_reception():
        return fait("isabella_temoin") or fait("reception_finie_22h")

    def dire_lignes(lignes):
        for qui, texte in lignes:
            renpy.say(getattr(store, qui), texte)

label samedi_matin:
    $ chapitre = "audience"
    $ jour = 6
    $ moment = "matin"
    call titre(6, "Samedi", "18 octobre", "L'audience")

    scene bg chambre with fondu
    $ poser_heure("SAMEDI · 07 H 00")
    $ marteaux = marteaux_max()
    if fait("plaidoirie_prete"):
        narrator "J'ai relu chaque pièce du dossier jusqu'à les connaître par cœur. Je sais où elles se répondent, et où elles se contredisent."
    if energie <= 2:
        narrator "Je n'ai presque pas dormi de la semaine. Mes pensées glissent les unes sur les autres comme des feuilles mouillées."
        $ marteaux -= 1
    if moral <= 2:
        narrator "Une petite voix me répète que je vais échouer. Que Clara paiera pour mes erreurs. Que je n'aurais jamais dû venir à Valcourt."
        $ marteaux -= 1
    $ marteaux = max(1, marteaux)
    if marteaux < marteaux_max():
        pensee "Je ne suis pas en état. Il faudra que chaque mot compte."

    $ video("audience")
    jump audience


label audience:
    scene bg tribunal
    show grain
    with fondu_long
    $ ambiance("salle")
    $ musique_jouer("tribunal")
    $ poser_heure("SAMEDI · 10 H 00")
    $ contradictions = set()
    $ preuve_decisive = None
    $ mobile_prouve = False
    $ derniere_preuve = None

    narrator "La salle est comble. Des étudiants, des journalistes, des donateurs aux manteaux chers."
    narrator "Au premier rang, Isabella Varga, droite comme une statue. Derrière elle, Éléonore Lambert, un dossier sur les genoux."
    show clara peur at centre with fondu
    narrator "On fait entrer Clara. Elle cherche quelqu'un des yeux. Elle me trouve. Elle respire."
    hide clara with fondu

    scene bg tribunal juge with fondu
    $ rencontrer("leclerc", "saunier")
    $ son("marteau")
    ju "L'audience est ouverte. Nous sommes réunis pour statuer sur le renvoi de Mademoiselle Clara Morel devant la cour d'assises, pour homicide."
    ju "Madame la procureure."

    scene bg tribunal procureur with fondu
    show saunier normal at centre with fondu
    pr "Monsieur le Président, l'affaire est simple, et je le regrette."
    pr "Mardi, à la cantine, l'accusée et la victime se disputent violemment devant cinquante témoins."
    pr "Mercredi soir, l'accusée se rend au laboratoire, qu'elle dessine. À vingt-deux heures quarante, Iris Delaunay meurt. Le carnet de l'accusée est retrouvé à côté de son corps."
    pr "Je demande le renvoi devant la cour d'assises. J'appelle l'inspecteur Deschamps."
    hide saunier with fondu

    scene bg tribunal defense with fondu
    show dorian normal at centre with fondu
    d "C'est à vous, [joueur_nom]. Écoutez chaque mot. Quand une déclaration ment, montrez la preuve qui la contredit."
    d "Et si vous vous trompez, le juge le notera. Il ne vous le pardonnera pas indéfiniment."
    if temperament == "logique":
        pensee "Je sens les mensonges comme on sent un courant d'air. Il faudra me fier à cette intuition."
    hide dorian with fondu

    ## ---------------------------------------------------------------------
    ## Témoin 1 : Malo
    ## ---------------------------------------------------------------------
    scene bg tribunal temoin with fondu
    show malo normal at centre with fondu
    $ musique_jouer("objection")
    m "Malo Deschamps, inspecteur, brigade des stupéfiants. J'étais sur les lieux mercredi soir."
    call contre_interrogatoire("malo")
    call rebond_voisin_audience

    ## ---------------------------------------------------------------------
    ## Témoin 2 : Éléonore Lambert
    ## ---------------------------------------------------------------------
    scene bg tribunal procureur with fondu
    show saunier normal at centre with fondu
    $ musique_jouer("tribunal")
    pr "Soit. La défense a semé un doute sur l'heure. J'ai mieux qu'un doute : une témoin."
    pr "J'appelle Mademoiselle Éléonore Lambert, assistante de direction, qui a vu l'accusée fuir les lieux du crime."
    hide saunier with fondu

    scene bg tribunal temoin with fondu
    show eleonore normal at centre with fondu
    el "Éléonore Lambert. Vingt-huit ans. Assistante de Madame Isabella Varga depuis six ans."
    el souci "Je suis désolée d'être là. Clara est une jeune fille… fragile. Mais je ne peux pas taire ce que j'ai vu."
    $ musique_jouer("objection")
    call contre_interrogatoire("eleonore_a")

    el normal "Soit. Je me suis peut-être trompée sur l'heure. Mais je n'ai rien à voir avec ce laboratoire."
    call contre_interrogatoire("eleonore_b")

    el "Tout ceci est ridicule. On me reproche d'avoir des clés. Je suis une assistante, pas une criminelle."
    call contre_interrogatoire("eleonore_c")

    jump audience_accusation


## ---------------------------------------------------------------------------
## Moteur du contre-interrogatoire
## ---------------------------------------------------------------------------

label contre_interrogatoire(cle):
    $ ci = TEMOIGNAGES[cle]
    $ ci_idx = 0
    $ ci_fini = False
    $ ci_reussi = False
    while not ci_fini:
        window hide
        $ act = renpy.call_screen("contre_interro", temoin_nom=ci["temoin"], declarations=ci["declarations"], idx=ci_idx, indice_logique=(temperament == "logique"))
        $ dcl = ci["declarations"][ci_idx]
        if act == "suivante":
            $ ci_idx = (ci_idx + 1) % len(ci["declarations"])
        elif act == "precedente":
            $ ci_idx = max(0, ci_idx - 1)
        elif act == "presser":
            moi "Attendez. Précisez ce point."
            $ dire_lignes(dcl["presser"])
            if dcl.get("presser_succes") and getattr(store, dcl["presser_succes"])():
                $ ci_reussi = True
                $ ci_fini = True
        elif act == "presenter":
            $ code = renpy.call_screen("dossier", presenter=True, question="« " + dcl["texte"] + " »")
            if code is not None:
                if code in dcl.get("preuves", ()):
                    $ examiner(code)
                    $ son("objection")
                    show objection_bulle
                    with tremblement_ecran
                    moi "Objection !"
                    hide objection_bulle
                    $ derniere_preuve = code
                    $ ci_reussi = True
                    $ ci_fini = True
                else:
                    call penalite
        elif act == "renoncer":
            menu:
                "Laisser passer ce témoignage sans le contester ?"
                "Oui, je n'ai rien à opposer.":
                    $ ci_fini = True
                "Non, je continue.":
                    pass
    if ci_reussi:
        $ contradictions.add(cle)
        $ musique_jouer("tribunal")
        call expression ci["succes"]
    else:
        $ musique_jouer("tension")
        if ci_mode == "gala":
            narrator "Ferrière sourit. La salle hoche la tête avec lui. Ce mensonge-là restera debout."
        else:
            ju "Le témoignage est versé au dossier. Il pèse lourd."
    return

default ci_mode = "audience"

label penalite:
    if ci_mode == "gala":
        jump penalite_gala
    $ son("marteau")
    with tremblement_ecran
    $ marteaux -= 1
    ju "La défense a-t-elle l'intention de nous faire perdre notre temps ?"
    if marteaux <= 0:
        jump audience_perdue
    elif marteaux == 1:
        ju "Dernier avertissement, Maître. La prochaine fois, je clos les débats."
    return

image objection_bulle:
    "gui/objection.png"
    xalign 0.5 yalign 0.35
    zoom 0.6 alpha 0.0
    easein .12 zoom 1.0 alpha 1.0
    pause .6
    linear .2 alpha 0.0


## ---------------------------------------------------------------------------
## Contradictions brisées
## ---------------------------------------------------------------------------

label ci_malo_brise:
    moi "Le carnet de Clara contient une date et une heure. Sa dernière page représente le laboratoire, avec son horloge."
    moi "L'horloge du dessin indique vingt et une heures trente. Pas vingt-deux heures quarante."
    moi "Et le dessin est fait de l'extérieur : on voit le reflet de la cour dans les vitres. Clara dessinait depuis le banc, dehors."
    show malo surprise
    m "…Le carnet était sec. Il pleuvait depuis vingt et une heures quarante-cinq."
    m pensif "S'il était resté dehors, il serait trempé. Quelqu'un l'a apporté à l'intérieur après la pluie. Pas elle : elle n'avait aucune raison de le laisser là."
    if fait("temoin_cour"):
        moi "J'étais avec elle, Monsieur le Président. À vingt et une heures quarante-cinq, elle était dans sa chambre. Je l'ai entendue fermer sa porte à clé."
        scene bg tribunal procureur
        show saunier colere at centre
        pr "Un ami de l'accusée. Témoin partial !"
        scene bg tribunal juge
        ju "Noté. Mais l'horloge du dessin, elle, n'a pas d'amis."
    else:
        scene bg tribunal juge
        ju "L'horloge du dessin, elle, n'a pas d'amis. La cour en prend note."
    $ foule("{i}(murmures){/i}")
    return

label ci_eleonore_a_brise:
    if derniere_preuve == "agenda":
        moi "Voici l'agenda de la direction, tenu de la main de Mademoiselle Lambert : « Réception des donateurs, 19 h – 22 h »."
        moi "La réception s'est terminée à vingt-deux heures. Pas vingt-trois."
        el surprise "Je… J'ai pu confondre."
    elif derniere_preuve in ("carnet", "rapport"):
        moi "Mademoiselle Lambert affirme que Clara s'est enfuie à vingt-deux heures quarante-cinq en serrant son carnet contre elle."
        moi "Mais le carnet a été retrouvé {b}à côté du corps{/b}. Il ne peut pas être à la fois dans le laboratoire et dans les bras de quelqu'un qui s'enfuit."
        el surprise "Ce n'était peut-être pas le carnet. Un livre. Un sac…"
        moi "Vous étiez « formelle », il y a une minute."
    elif fait("isabella_temoin"):
        moi "Monsieur le Président, la défense demande que Madame Isabella Varga précise l'heure de fin de sa propre réception."
        scene bg tribunal public with fondu
        show isabella normal at centre with fondu
        isa "J'ai clos la soirée à vingt-deux heures précises. J'ai fait un discours. Cent personnes l'ont entendu."
        isa pensif "Et à vingt-deux heures cinq, mon assistante n'était plus dans les salons. Je l'ai cherchée pour mes clés."
        hide isabella with fondu
        scene bg tribunal temoin with fondu
        show eleonore surprise at centre
    else:
        moi "J'étais à cette réception, Monsieur le Président. Je servais. Madame Varga a clos la soirée à vingt-deux heures."
        moi "Et à vingt-deux heures cinq, j'ai vu Mademoiselle Lambert quitter les salons par l'escalier de service. Celui qui descend vers l'aile des sciences."
        el surprise "C'est… vous étiez serveur{g=/se}. Vous avez dû confondre."
    scene bg tribunal juge
    ju "Mademoiselle Lambert, je vous rappelle que vous témoignez sous serment."
    scene bg tribunal temoin
    show eleonore normal at centre
    return

label ci_eleonore_b_brise:
    if derniere_preuve == "epingle":
        moi "Cette épingle à cheveux dorée a été retrouvée sous la paillasse, là où la police n'a pas cherché."
        moi "Clara porte les cheveux lâchés. Toujours."
        moi "Mademoiselle Lambert, vous portez ce matin un chignon tenu par… des épingles dorées. Pouvez-vous nous dire combien ?"
        show eleonore surprise
        narrator "Sa main monte vers sa nuque. Une seule épingle, de ce côté-là, quand il y en a deux de l'autre."
        m "{i}(depuis le banc des témoins){/i} Même modèle. Je le note."
    elif derniere_preuve == "badges":
        moi "Le registre électronique des portes. Mercredi, vingt-deux heures trente et une : ouverture du laboratoire avec le {b}passe de la direction{/b}."
        moi "Un passe gardé dans un tiroir dont vous êtes, je vous cite, « la seule à avoir la clé »."
        show eleonore surprise
        el "N'importe qui aurait pu le prendre !"
        moi "Dans un tiroir fermé à clé, dont vous seule avez la clé ?"
    else:
        moi "La vidéo du couloir des sciences, effacée jeudi matin par l'administration, et récupérée par l'inspecteur Deschamps."
        moi "Vingt-deux heures trente-cinq. Une silhouette au chignon, en veste sombre, un dossier frappé d'un V doré contre la poitrine."
        show eleonore surprise
        el "Ce n'est pas… Ça pourrait être n'importe qui !"
        if fait("dossier_v"):
            moi "Clara a vu le même dossier, avec le même V, à vingt et une heures trente. Elle l'a dessiné."
    $ noter("soupcon_eleonore")
    scene bg tribunal juge
    ju "Silence dans la salle !"
    $ son("marteau")
    scene bg tribunal temoin
    show eleonore normal at centre
    return

label ci_eleonore_c_brise:
    if derniere_preuve == "lettre_anonyme":
        moi "Cette lettre a été glissée sous ma porte mardi soir. Papier à en-tête de la direction : « Une bourse, ça se perd vite. »"
        moi "Elle a été tapée sur une machine mécanique. Le « e » saute au-dessus de la ligne. Exactement comme sur la machine qui trône sur votre bureau, Mademoiselle Lambert."
    elif derniere_preuve == "photo_bal":
        moi "Cette photographie a été prise mardi soir, au bal d'automne, par la Gazette de Valcourt."
        moi "On y voit Mademoiselle Lambert remettre une enveloppe épaisse à… Nathan Roussel. L'étudiant qu'elle « ne connaît pas »."
    elif derniere_preuve == "usb":
        moi "Le Registre Azur, retrouvé sur la clé USB d'Iris Delaunay. Quai 7, chaque jeudi."
        moi "Une colonne « paiements », toujours signée des mêmes initiales : E.L."
    else:
        moi "Hier soir, au quai 7, Nathan Roussel a fait des aveux. Il fabriquait l'Azur la nuit, au laboratoire de Valcourt."
        moi "Sur ordre d'une femme qui avait « les clés de tout ». Il a donné son nom."
    show eleonore colere
    el "Vous ne comprenez rien. Rien du tout."
    $ noter("soupcon_eleonore")
    return


## ---------------------------------------------------------------------------
## L'accusation
## ---------------------------------------------------------------------------

label audience_accusation:
    scene bg tribunal juge with fondu
    $ musique_jouer("tension")
    ju "Maître, la défense a contesté. La défense a-t-elle une autre explication à proposer à cette cour ?"
    scene bg tribunal defense with fondu
    show dorian pensif at centre with fondu
    d "C'est le moment, [joueur_nom]. Si vous avez un nom, dites-le. Si vous n'en avez pas, taisez-vous : un mauvais nom serait pire que le silence."
    hide dorian with fondu

    $ essais_accusation = 0
    while True:
        $ nom = saisie("Qui a tué Iris Delaunay ?", indice="Tapez le nom de la personne que vous accusez.")
        $ accuse = comprendre(nom, [
            ("eleonore", ["eleonore", "lambert", "assistante", "secretaire"]),
            ("dorian", ["dorian", "professeur", "prof"]),
            ("isabella", ["isabella", "directrice", "isabelle"]),
            ("nathan", ["nathan", "roussel"]),
            ("clara", ["clara", "morel", "accusee"]),
            ("malo", ["malo", "deschamps", "inspecteur"]),
        ])
        if accuse == "eleonore":
            jump accusation_eleonore
        elif accuse == "dorian":
            jump accusation_dorian
        elif accuse == "clara":
            scene bg tribunal juge
            ju "La défense accuse sa propre cliente ? Je n'ai jamais vu ça en trente ans."
            call penalite
        elif accuse == "isabella":
            scene bg tribunal public
            show isabella colere at centre
            isa "J'étais devant cent personnes à vingt-deux heures. Choisissez mieux vos ennemis."
            hide isabella
            call penalite
        elif accuse == "nathan":
            scene bg tribunal juge
            ju "Monsieur Roussel n'a jamais été placé sur les lieux. Avez-vous un élément ?"
            call penalite
        elif accuse == "malo":
            scene bg tribunal temoin
            show malo colere at centre
            m "Tu plaisantes ?"
            hide malo
            call penalite
        else:
            scene bg tribunal juge
            ju "Qui ? Je n'ai pas compris."
            call penalite

label accusation_eleonore:
    scene bg tribunal temoin with fondu
    show eleonore normal at centre with fondu
    $ musique_jouer("objection")
    moi "La défense accuse Mademoiselle Éléonore Lambert."
    $ foule("{i}(la salle explose){/i}")
    $ son("marteau")
    scene bg tribunal procureur
    show saunier colere at centre
    pr "Une accusation pareille exige une preuve qui la place sur les lieux, au moment du drame. Laquelle ?"
    hide saunier
    $ preuve_decisive = None
    while preuve_decisive is None:
        $ code = renpy.call_screen("dossier", presenter=True, question="Quelle preuve place Éléonore Lambert au laboratoire, mercredi soir ?")
        if code in ("epingle", "badges", "video", "temoignage"):
            $ preuve_decisive = code
        elif code is None:
            scene bg tribunal juge
            ju "Sans preuve, cette accusation n'est qu'une rumeur."
            jump audience_verdict
        else:
            call penalite
    $ son("objection")
    show objection_bulle
    with tremblement_ecran
    hide objection_bulle
    scene bg tribunal temoin
    show eleonore souci at centre
    $ examiner(preuve_decisive)
    $ pd_nom = PREUVES[preuve_decisive]["nom"]
    $ pd_detail = PREUVES[preuve_decisive]["detail"]
    moi "[pd_nom]. {i}[pd_detail]{/i}"

    $ mobile = saisie("Pourquoi a-t-elle tué Iris ? Quel était son mobile ?", indice="Un mot suffit, s'il est juste.")
    $ mobile_juste = mentionne(mobile, ["azur", "drogue", "trafic", "registre", "cle", "usb", "quai", "argent", "dette", "dettes", "article", "publier", "reseau"])
    $ mobile_prouve = mobile_juste and (a("usb") or a("temoignage") or a("azur") or a("photo_bal"))
    if mobile_juste:
        moi "Iris allait publier la vérité sur l'Azur : une drogue fabriquée la nuit dans le laboratoire de Valcourt, et vendue aux étudiants."
        moi "Mademoiselle Lambert avait les clés, les horaires, et une dette envers des gens du port. Iris avait la preuve. Il fallait la récupérer."
    else:
        moi "Elle… elle avait ses raisons."
        scene bg tribunal procureur
        show saunier normal at centre
        pr "Des raisons ? La défense n'a même pas de mobile à proposer."
        hide saunier
        scene bg tribunal temoin
        show eleonore souci at centre
    call rebond_accuse_isabella
    jump audience_verdict

label accusation_dorian:
    scene bg tribunal defense with fondu
    show dorian surprise at centre with fondu
    moi "La défense… accuse Monsieur Dorian Varga."
    d "Vous…"
    $ foule("{i}(un silence de mort){/i}")
    if fait("vu_dorian_part"):
        moi "Mercredi soir, il a quitté la réception à vingt et une heures trente, sans saluer personne. Il n'a pas d'alibi pour vingt-deux heures quarante."
    else:
        moi "Il est le frère de la directrice. Il avait tout intérêt à étouffer un scandale à Valcourt."
    d pensif "…J'étais sur le campus. C'est vrai. Iris m'avait appelé, elle aussi. Je la cherchais."
    d "Je ne dirai pas pourquoi. Pas ici. Pas devant ma sœur."
    scene bg tribunal juge with fondu
    ju "Monsieur Varga, votre silence vous accuse. La cour ordonne votre placement en garde à vue."
    ju "Mademoiselle Morel, les charges contre vous sont abandonnées."
    $ son("marteau")
    jump fin_mauvais_coupable

label audience_verdict:
    $ score = len(contradictions)
    scene bg tribunal juge with fondu
    $ musique_jouer("tension")
    ju "La cour a entendu les parties."
    if preuve_decisive and score >= 3 and (mobile_prouve or score == 4):
        jump fin_veritas_tribunal
    jump audience_perdue

label audience_perdue:
    scene bg tribunal juge with fondu
    $ musique_jouer("tristesse")
    $ son("marteau")
    ju "La cour estime les charges suffisantes. Mademoiselle Clara Morel est renvoyée devant la cour d'assises pour homicide."
    show clara triste at centre with fondu
    narrator "Clara ne pleure pas. Elle me regarde, et elle hoche la tête, comme pour me dire que ce n'est pas ma faute."
    narrator "C'est pire que si elle pleurait."
    hide clara with fondu
    if possede("marque_page"):
        $ fin_en_attente = "erreur"
        jump le_livre
    jump fin_erreur
