## Le Livre des Sept Jours, et le mercredi revécu.

default pages = 3
default fin_en_attente = None

label le_livre:
    $ poser_heure("")
    $ musique_stop(1.0)
    $ ambiance(None)
    scene bg tribunal
    with fondu
    show halo_or
    $ musique_jouer("boucle", 3.0)
    narrator "Le marteau du juge est encore en l'air quand le monde ralentit."
    narrator "Les voix s'étirent. La poussière cesse de tomber dans les rayons de lumière. Plus personne ne bouge."
    narrator "Sur la table de la défense, il y a un livre qui n'y était pas. Reliure dorée. Ouvert."
    narrator "Dans ma poche, le marque-page brûle."
    show livre_ferme at Transform(xalign=0.5, yalign=0.45, zoom=0.7) with fondu
    narrator "Une page blanche. En haut, d'une écriture qui ressemble à la mienne : {i}« Écrivez votre nom. »{/i}"
    if pages <= 1:
        narrator "C'est la dernière page."
    hide livre_ferme

    menu:
        "Écrire mon nom.":
            pass
        "Refermer le Livre.":
            narrator "Je referme la couverture. Le temps reprend sa course, le marteau retombe, et le Livre n'est plus là."
            narrator "Ce qui est fait est fait."
            jump expression "fin_" + fin_en_attente

    window hide
    $ ecrit = renpy.input("Écrivez votre nom.", screen="livre_ecrire", length=24).strip()
    if not ecrit:
        $ ecrit = joueur_nom

    if normaliser(ecrit) != normaliser(joueur_nom):
        $ nom_ecrit = ecrit
        jump fin_page_blanche

    $ pages -= 1
    $ boucle += 1
    $ video("boucle")
    jump mercredi_boucle


################################################################################
## Le mercredi, encore
################################################################################

label mercredi_boucle:
    $ chapitre = "boucle"
    $ jour = 3
    $ moment = "matin"
    $ cafes_du_jour = 0
    ## On garde ce qu'on sait (faits, preuves connues). Le monde, lui, est remis à zéro.
    $ oublier("drame", "marche", "marche_refuse", "bourse_suspendue", "isabella_temoin", "aveu_nathan", "reseau_demantele")
    $ oublier("iris_alliee", "malo_prevenu", "video_sauvee", "clara_protegee", "eleonore_alertee")
    $ energie = 7
    $ moral = borner(moral + 2)
    $ etudes = max(etudes, 5)
    $ argent = max(argent, 20)
    $ noter("souvenirs")
    call titre(3, "Mercredi", "15 octobre", "Encore")

    scene bg chambre with fondu
    show halo_or
    $ poser_heure("MERCREDI · 07 H 30")
    $ musique_jouer("boucle")
    narrator "J'ouvre les yeux. Le plafond de ma chambre. Le bruit lointain du port. Un café tiède sur le bureau."
    narrator "Mon téléphone affiche : {b}mercredi 15 octobre, 7 h 30{/b}."
    pensee "Iris est vivante. Clara dort dans la chambre d'à côté. Rien n'est encore arrivé."
    pensee "Et je me souviens de tout."
    hide halo_or with fondu
    narrator "J'ai jusqu'à vingt-deux heures quarante. Quatre moments dans la journée. Je ne pourrai pas être partout."
    $ noter_journal("sauver_iris", "Sauver Iris avant 22 h 40.", "Mercredi")

    $ creneaux_boucle = [("matin", "MERCREDI · 08 H 00", "Le devoir est à dix heures."),
                         ("midi", "MERCREDI · 12 H 30", "La cantine, les couloirs, le monde qui ignore tout."),
                         ("après-midi", "MERCREDI · 15 H 00", "Il reste sept heures."),
                         ("soir", "MERCREDI · 19 H 00", "La réception commence. Clara prépare ses crayons.")]
    $ cb = 0
    while cb < len(creneaux_boucle):
        $ moment, _h, _sous = creneaux_boucle[cb]
        $ poser_heure(_h)
        call boucle_rappel
        $ choix = choisir_creneau("Mercredi — " + moment, options_boucle(), _sous)
        call expression "boucle_" + choix
        $ cb += 1

    jump boucle_laboratoire

init python:
    def options_boucle():
        o = []
        if store.moment == "matin":
            o.append(("ds", "Passer le devoir", "Je connais déjà le sujet. Une heure de plus, et la bourse est sauvée.", {"etudes": 2, "energie": -1}, True, ""))
        o.append(("iris", "Trouver Iris", "La convaincre. Lui dire ce qu'elle seule peut reconnaître.", {"energie": -1}, not fait("iris_alliee"), "Elle vous croit déjà."))
        o.append(("malo", "Prévenir Malo", "Il faut qu'il soit au laboratoire ce soir. Avec du renfort.", {"energie": -1}, not fait("malo_prevenu"), "Il est prévenu."))
        o.append(("video", "Sauver la vidéo", "La sécurité garde les enregistrements vingt-quatre heures. Après jeudi matin, il sera trop tard.", {"energie": -1}, not fait("video_sauvee"), "C'est fait."))
        o.append(("clara", "Retenir Clara", "Qu'elle ne s'approche pas du laboratoire. Qu'elle ne laisse pas son carnet.", {"moral": 1}, not fait("clara_protegee"), "Elle restera chez elle."))
        o.append(("eleonore", "Affronter Éléonore", "Lui dire que je sais. La forcer à reculer.", {"energie": -1}, not fait("eleonore_alertee"), "Elle sait que vous savez."))
        return o

label boucle_rappel:
    ## Ce que je sais, et ce qu'il reste à faire avant 22 h 40.
    if not fait("iris_alliee"):
        if fait("lettre_iris"):
            pensee "Iris ne me croira pas sans le mot de sa lettre. Elle est à la bibliothèque."
        else:
            pensee "Iris ne me connaît pas encore, cette fois. Il faudra trouver les mots pour qu'elle me croie."
    if not fait("malo_prevenu"):
        pensee "Sans la police, Éléonore repartira libre. Malo doit être au laboratoire à 22 h 20."
    if not fait("video_sauvee"):
        pensee "La vidéo du couloir sera effacée demain matin. Ce soir, elle existe encore."
    if not fait("clara_protegee"):
        pensee "Clara partira dessiner à 21 h, et oubliera son carnet sur le banc."
    if moment == "matin":
        pensee "Et le devoir de 10 h… La dernière fois, il m'a coûté une matinée. Cette fois, je connais le sujet."
    return

label boucle_ds:
    scene bg classe with fondu
    $ musique_jouer("tension")
    narrator "« La charge de la preuve en matière pénale. » Je souris. Cette fois, j'ai eu trois jours pour y penser."
    narrator "Et trois jours pour comprendre ce qu'elle veut vraiment dire."
    $ note_ds = 16
    $ varier(etudes=2, energie=-1)
    narrator "{b}Devoir surveillé : 16/20.{/b}"
    return

label boucle_iris:
    scene bg bibliotheque with fondu
    $ musique_jouer("boucle")
    show iris normal at centre with fondu
    ir "[joueur_nom] ? Tu as une drôle de tête. On dirait que tu as vu un fantôme."
    moi "Iris. Écoute-moi. Ce soir, au laboratoire, tu vas mourir."
    ir "…"
    ir "Qu'est-ce que tu viens de dire ?"
    $ dit = saisie("Comment la convaincre ?", indice="Elle a laissé un mot pour ce moment-là. Si vous l'avez lu.")
    if mentionne(dit, ["ariane"]):
        show iris normal at centre, tremble
        ir "…Ariane."
        ir "Tu as trouvé ma lettre. Tu as écrit ton nom. Tu es revenu{g=/e}."
        narrator "Elle s'assoit, lentement, comme si ses jambes ne la portaient plus. Puis elle rit, et elle pleure en même temps."
        ir "Quatre fois, [joueur_nom]. Quatre mercredis. Je ne me suis jamais dit qu'il suffisait de ne pas être seule."
        $ noter("iris_alliee")
        $ lien("iris", 3)
    elif fait("legende_livre") and mentionne(dit, ["livre", "sept jours", "page", "pages", "boucle", "nom", "quatrieme", "quatre fois"]):
        ir "Le Livre… Personne ne connaît le Livre. Sauf ceux qui…"
        ir "Tu y as écrit ton nom."
        narrator "Elle me fixe longtemps, puis elle hoche la tête."
        ir "D'accord. Je te crois. Je ne sais pas pourquoi, mais je te crois."
        $ noter("iris_alliee")
        $ lien("iris", 2)
    else:
        ir "Je ne sais pas qui t'a raconté quoi. Mais ne te mêle pas de ça. C'est trop dangereux."
        narrator "Elle s'en va. Je n'ai pas trouvé les bons mots."
        pensee "Il me fallait quelque chose qu'elle seule pouvait reconnaître."
    $ varier(energie=-1)
    hide iris with fondu
    return

label boucle_malo:
    scene bg commissariat with fondu
    $ musique_jouer("enquete")
    show malo normal at centre with fondu
    m "On se connaît ?"
    narrator "Pour lui, c'est vrai : on s'est vus une seule fois, mardi soir, au bal."
    if niveau("malo") >= 4 or a("usb") or fait("quai7_tot") or a("temoignage"):
        moi "Quai 7, chaque jeudi. Des initiales : E.L. et N.R. Un réactif du lot VAL-23. Et ce soir, à vingt-deux heures trente, quelqu'un va ouvrir le laboratoire de Valcourt avec le passe de la direction."
        m surprise "…Comment tu sais tout ça ?"
        moi "Je vous le dirai quand ce sera fini. Si vous êtes là à vingt-deux heures vingt."
        m determine "Je serai là. Avec deux collègues. Et si tu m'as menti, tu passeras la nuit au poste."
        $ noter("malo_prevenu")
        $ lien("malo", 1)
    else:
        m "Une étudiante en danger, ce soir, dans un labo ? Tu as des preuves ? Un nom ?"
        moi "Pas encore."
        m "Alors reviens quand tu en auras."
        pensee "La première fois, je ne savais rien. Il me faudrait plus que mes souvenirs pour le convaincre."
    $ varier(energie=-1)
    hide malo with fondu
    return

label boucle_video:
    scene bg couloir with fondu
    $ musique_jouer("mystere")
    if filiere == "droit" or temperament == "audacieux" or niveau("malo") >= 4:
        narrator "Le poste de sécurité est au sous-sol. Le gardien somnole devant douze écrans."
        if filiere == "droit":
            narrator "Je lui parle de « conservation des preuves » et de « réquisition à venir ». Il me laisse copier les enregistrements de la soirée sur une clé, à partir de vingt-deux heures."
        elif temperament == "audacieux":
            narrator "J'attends qu'il aille chercher un café. Il me faut quatre-vingt-dix secondes pour lancer la copie automatique."
        else:
            narrator "J'appelle Malo. Il appelle le gardien. Le gardien appelle son chef. À la fin, j'ai une clé USB avec les enregistrements de la nuit."
        $ noter("video_sauvee")
    else:
        narrator "Le gardien me renvoie poliment : « Les enregistrements, c'est pour la police. »"
    $ varier(energie=-1)
    return

label boucle_clara:
    scene bg chambre clara with fondu
    $ musique_jouer("clara")
    show clara sourire at centre with fondu
    c "Tu tombes bien ! Ce soir, je vais dessiner le laboratoire, la lumière bleue est…"
    moi "Clara. N'y va pas. Pas ce soir."
    if niveau("clara") >= 5:
        show clara pensif
        c "Tu as la même tête qu'Iris quand elle m'a dit la même chose."
        c "…D'accord. Je reste. On regarde un film ? Je déteste les films, mais j'aime bien les gens qui les regardent."
        $ noter("clara_protegee")
        $ lien("clara", 1)
        $ varier(moral=1)
    else:
        show clara colere
        c "Toi aussi ? Tout le monde veut décider à ma place. Mon père, Iris, et maintenant toi."
        narrator "Elle me ferme la porte au nez. Je l'entends, de l'autre côté, ramasser ses crayons."
    hide clara with fondu
    return

label boucle_eleonore:
    scene bg couloir with fondu
    $ musique_jouer("tension")
    show eleonore normal at centre with fondu
    moi "Je sais pour l'Azur. Je sais pour le quai 7. Je sais ce que vous allez faire ce soir."
    show eleonore surprise
    el "…Je ne vois pas de quoi vous parlez."
    narrator "Elle sourit. Un sourire parfait. Mais ses mains, sur son dossier, ont blanchi."
    $ noter("eleonore_alertee")
    pensee "Je viens de faire une erreur. Je le sens."
    hide eleonore with fondu
    return


################################################################################
## 22 h 20 — le laboratoire
################################################################################

label boucle_laboratoire:
    scene bg labo nuit
    show neon_gresille
    with fondu_long
    $ moment = "nuit"
    $ poser_heure("MERCREDI · 22 H 20")
    $ ambiance("pluie")
    $ musique_jouer("nuit")

    $ allies = (1 if fait("iris_alliee") else 0) + (1 if fait("malo_prevenu") else 0)

    if fait("iris_alliee"):
        show iris normal at gauche with fondu
        ir "Tu es là. Pour une fois, je ne suis pas seule ici."
        ir "Elle va venir chercher la clé. Je lui ai écrit que je publiais à minuit. Elle ne peut pas résister."
        narrator "Iris pose son téléphone sur une étagère, objectif tourné vers la porte. Il enregistre."
    else:
        narrator "Je me cache derrière une armoire vitrée. Iris entre à vingt-deux heures vingt-cinq, seule, une clé USB à la main."
        show iris normal at gauche with fondu

    $ son("porte")
    $ poser_heure("MERCREDI · 22 H 31")
    narrator "À vingt-deux heures trente et une, le lecteur de badge émet un bip. La porte s'ouvre."
    show eleonore normal at droite with fondu
    if fait("eleonore_alertee"):
        el "Je me doutais que vous seriez là aussi, [joueur_nom]. Vous parlez trop."
    el "Iris. Donnez-moi la clé. Personne n'a besoin d'être blessé ce soir."
    ir "Vous avez déjà blessé Hugo. Et combien d'autres ?"
    el colere "Je n'ai blessé personne ! Je paie des dettes que je n'ai pas choisies. Ces gens du port ne plaisantent pas. Si je m'arrête, c'est moi qu'on retrouvera dans l'eau."
    el "Donnez-moi cette clé !"

    if allies == 2:
        narrator "Elle se jette sur Iris. Je m'interpose. Le monde se réduit à un bruit de verre et à l'angle noir de la paillasse."
        with tremblement_ecran
        $ son("choc")
        narrator "Iris trébuche. Je la rattrape. L'angle de la paillasse passe à un centimètre de sa tempe."
        $ son("porte")
        show malo determine at centre with fondu
        m "Police ! Éléonore Lambert, vous ne bougez plus."
        narrator "Deux agents entrent derrière lui. Éléonore lâche son dossier. Il s'ouvre en tombant : des enveloppes, des feuilles de comptes, un trousseau de clés."
        el triste "…Vous ne savez pas ce qu'ils vont me faire."
        m "On le saura ensemble. Au poste."
        hide eleonore with fondu
        hide malo with fondu
        show iris normal at centre
        ir "Je suis vivante."
        ir "Je suis vivante, [joueur_nom]. C'est jeudi qui va arriver. Un vrai jeudi."
        jump fin_sept_jours

    elif allies == 1:
        narrator "Elle se jette sur Iris. Je surgis de ma cachette et je la tire en arrière. Iris tombe, se cogne l'épaule, mais pas la tête."
        with tremblement_ecran
        $ son("choc")
        if fait("malo_prevenu"):
            narrator "Les agents de Malo arrivent par la porte principale. Éléonore s'enfuit par l'escalier de service avant qu'ils ne l'atteignent."
        else:
            narrator "Éléonore s'enfuit par l'escalier de service. Le temps que j'aide Iris à se relever, elle a disparu."
        $ son("sirene")
        jump fin_veritas_aube

    else:
        narrator "Tout va trop vite. Je sors de ma cachette au moment où Iris recule. Elle trébuche."
        with flash_rouge
        $ son("coeur")
        narrator "Le bruit. Ce bruit-là, je l'entendrai toute ma vie."
        narrator "Éléonore s'enfuit. Je reste à genoux sur le carrelage, et je comprends que je n'ai rien changé."
        if pages > 0 and possede("marque_page"):
            $ fin_en_attente = "page_blanche"
            jump le_livre
        jump fin_page_blanche
