## Acte II — chapitre 2 : le week-end (vendredi après-midi → dimanche soir).
##
## Neuf créneaux sur la carte. Rentrer à la maison pour l'anniversaire de Maman
## coûte tout le samedi et le dimanche matin : on y apprend la vérité sur Papa,
## mais on enquête moins. Rester, c'est manquer l'anniversaire.

label acte2_carte:
    if creneau2_idx >= len(CRENEAUX2):
        call resume_jour("Dimanche")
        jump acte2_lundi

    $ jour, moment, _h = CRENEAUX2[creneau2_idx]
    $ actions_restantes = len(CRENEAUX2) - creneau2_idx

    ## Événements imposés au début de certains créneaux.
    if creneau2_idx == 1:
        call acte2_appel_anniversaire
    if creneau2_idx == 2:
        $ jour = 12
        call resume_jour("Vendredi")
        $ jour = 13
        call acte2_samedi_reveil
    if creneau2_idx == 6:
        $ jour = 13
        call resume_jour("Samedi")
        $ jour = 14
        call acte2_dimanche_reveil
    if creneau2_idx == RETOUR_MAISON and not fait("rentre_maison"):
        call acte2_anniversaire_manque
    if creneau2_idx == 8:
        call acte2_jetee

    $ poser_heure(_h)
    $ musique_jouer("enquete")
    if creneau2_idx == 0:
        pensee "Par où commencer ? Le port, l'hôpital, Halvard… Et les partiels lundi, qui ne m'attendront pas."
    elif moment == "nuit":
        pensee "Valcourt dort. Je pourrais dormir aussi… ou profiter de ce que personne ne regarde."
    window hide
    $ lieu = renpy.call_screen("carte_enquete", lieux=lieux_acte2())

    if jour == 12 and moment == "après-midi" and lieu != "cours":
        $ varier(etudes=-1)
    if moment == "nuit" and lieu != "chambre2":
        $ dormi_cette_nuit = False

    call expression "a2_" + lieu

    if moment == "nuit":
        if dormi_cette_nuit:
            $ energie = borner(energie + 5)
        else:
            $ nuits_blanches += 1
            $ varier(energie=-2, moral=-1)
        $ dormi_cette_nuit = False
        $ cafes_du_jour = 0

    $ creneau2_idx += 1
    jump acte2_carte


################################################################################
## Événements imposés
################################################################################

label acte2_appel_anniversaire:
    scene bg rue with fondu
    $ poser_heure("VENDREDI · 19 H 10")
    $ son("vibreur")
    $ musique_jouer("quotidien")
    narrator "Maëlle. Je décroche avant la deuxième sonnerie, pour une fois."
    ma "Tiens, tu décroches. Il faut que j'appelle plus souvent un vendredi soir."
    ma "Dimanche, c'est les cinquante-deux ans de Maman. Elle ne te le demandera pas. Elle ne demande jamais rien."
    ma "Alors je te le demande, moi. Il y a un train samedi matin, et un autre en début d'après-midi. Dix-huit euros aller-retour, tarif étudiant."
    menu:
        "« Je serai là dimanche. »":
            ma "C'est vrai ? Je ne lui dis rien, alors. Ce sera la surprise."
            $ noter("promis_anniversaire")
            $ varier(moral=1)
        "« Je vais essayer. »":
            ma "« Essayer », c'est ce que disait Papa. Bon. Essaie fort."
        "« Pas ce week-end, Maëlle. Il se passe trop de choses ici. »":
            ma "…D'accord. Je lui dirai que tu l'appelleras. Tu l'appelleras, hein ?"
            $ noter("refus_anniversaire")
            $ varier(moral=-1)
    $ noter_journal("anniversaire_maman", "Anniversaire de Maman, à Saint-Aubin (train samedi, 18 €).", "Dimanche midi")
    return

label acte2_samedi_reveil:
    call titre(6, "Samedi", "18 octobre", "Le port")
    scene bg chambre with fondu
    $ poser_heure("SAMEDI · 08 H 10")
    $ cafes_du_jour = 0
    $ energie = borner(energie + 4)
    narrator "Samedi. Pas de cours, pas de réveil. Mon corps l'ignore : il me réveille à sept heures, comme un mercredi."
    if fait("ferriere_sait_copie"):
        call sms("Iris", [("iris", "Quelqu'un est entré dans ma chambre cette nuit."), ("iris", "Ils ont pris mon ordinateur et mes carnets. Pas la clé : je dors avec."), ("iris", "Rien n'a été forcé. Ils avaient un double.")], "Samedi, 07:52")
        $ recevoir("Iris", "Quelqu'un est entré dans ma chambre cette nuit. Ils ont pris mon ordinateur. Pas la clé.", "Sam. 07:52")
        pensee "Une copie. Je n'ai parlé de cette copie qu'à une seule personne."
        pensee "Un commissaire divisionnaire, avec une voix de grand-père qui lit des histoires."
        $ noter("cambriolage_iris")
        $ souvenir("On a fouillé la chambre d'Iris. Je n'avais parlé de sa copie qu'au commissaire Ferrière.", "ferriere normal")
    else:
        call sms("Iris", [("iris", "Rien à signaler. J'ai dormi six heures. Record de la décennie."), ("iris", "Fais attention au port. Ils regardent.")], "Samedi, 07:52")
        $ recevoir("Iris", "J'ai dormi six heures. Fais attention au port. Ils regardent.", "Sam. 07:52")
    return

label acte2_dimanche_reveil:
    call titre(7, "Dimanche", "19 octobre", "L'anniversaire")
    scene bg chambre with fondu
    $ poser_heure("DIMANCHE · 09 H 00")
    $ cafes_du_jour = 0
    narrator "Dimanche. Les cloches de Valcourt sonnent pour personne. Quelque part à deux heures de train, Maman met la table pour trois."
    if fait("promis_anniversaire"):
        pensee "J'avais promis. Le dernier train utile est parti hier."
    return

label acte2_anniversaire_manque:
    scene bg chambre with fondu
    $ poser_heure("DIMANCHE · 13 H 20")
    $ musique_jouer("tristesse")
    $ son("vibreur")
    narrator "Un appel vidéo. Maëlle tient le téléphone à bout de bras ; derrière elle, un gâteau à moitié mangé, deux assiettes, une chaise vide."
    show maman normal at centre with fondu
    $ rencontrer("maman")
    mam "Ah, te voilà ! Maëlle m'a dit que tu travaillais beaucoup. C'est bien. C'est très bien."
    mam "On a mangé ton gâteau préféré sans toi. C'est ta punition."
    narrator "Elle rit. Elle a les yeux fatigués d'une nuit à la blanchisserie, et une robe que je ne lui connais pas."
    if fait("appel_anniv_tot"):
        mam "Et merci pour ton message d'hier. Je l'ai lu trois fois."
        $ varier(moral=-1)
    elif fait("promis_anniversaire"):
        narrator "Derrière elle, Maëlle ne dit rien. Elle n'a pas besoin. {i}Tu avais promis.{/i}"
        $ varier(moral=-3)
        $ appels_manques += 1
    else:
        $ varier(moral=-2)
    mam "Ne t'inquiète pas pour nous. Fais ce que tu as à faire. Mais reviens à Noël, d'accord ?"
    moi "Bon anniversaire, Maman."
    mam "Cinquante-deux ans. Ton père disait que j'en paraissais quarante. Il mentait très bien, ton père."
    hide maman with fondu
    $ noter("anniversaire_manque")
    $ cocher("anniversaire_maman", "rate")
    $ souvenir("Maman a eu cinquante-deux ans. J'étais à Valcourt.", "maman normal")
    return


################################################################################
## Les lieux
################################################################################

label a2_cours:
    scene bg classe eleves with fondu
    $ musique_jouer("quotidien")
    show dorian pensif at centre with fondu
    narrator "Dorian assure le dernier cours avant les partiels. Il a les traits tirés d'un homme qui n'a pas dormi."
    d "Révision générale. La preuve, la présomption d'innocence, le doute qui profite à l'accusé. Vous connaissez la chanson."
    d "J'ajoute un point qui ne sera pas au programme : une institution qui se protège elle-même finit toujours par protéger les mauvaises personnes."
    narrator "Personne ne rit. Tout le monde sait de quelle institution il parle, et de quelle directrice."
    $ revisions_partiels += 1
    $ varier(etudes=1, energie=-1)
    $ lien("dorian", 1, silencieux=True)
    hide dorian with fondu
    return

label a2_gare:
    scene bg gare with fondu
    $ ambiance("ville")
    narrator "La gare de Valcourt sent le fer chaud et les croissants rassis. Le panneau annonce Saint-Aubin, voie 2."
    if argent < 18:
        narrator "Dix-huit euros. Je ne les ai plus. Je suis sur le point de faire demi-tour quand le téléphone vibre."
        call sms("Maëlle", [("maelle", "Je viens de te faire un virement. Ne discute pas."), ("maelle", "C'est le cadeau de Maman : toi.")], "Samedi")
        $ varier(argent=18)
    $ varier(argent=-18)
    $ donner("billet")
    $ noter("rentre_maison")
    $ cocher("anniversaire_maman")
    $ ambiance(None)
    call maison_weekend
    $ creneau2_idx = RETOUR_MAISON - 1
    return

label maison_weekend:
    scene bg train with fondu
    $ musique_jouer("quotidien")
    $ poser_heure("SAMEDI · EN TRAIN")
    narrator "Deux heures de train. Le port s'éloigne, puis les grues, puis la mer. Après, il n'y a plus que des champs et des vaches qui ne savent rien."
    pensee "Je dors une heure, la tête contre la vitre. Je rêve d'un mercredi qui ne finit pas."
    call sms("Iris", [("iris", "Tu as bien fait. Embrasse ta mère de la part d'une inconnue."), ("iris", "On tient le fort.")], "Samedi")

    scene bg maison with fondu
    $ poser_heure("SAMEDI · SAINT-AUBIN")
    $ musique_jouer("clara")
    show maelle normal at centre with fondu
    ma "Non. Non ! Tu es venu{g=/e} ? Elle va pleurer. Je te préviens, elle va pleurer, et après elle va dire qu'elle ne pleure pas."
    ma "Tu as maigri. Tu as des cernes. Tu as l'air de quelqu'un qui a vécu trois semaines en une."
    pensee "Si tu savais."
    hide maelle with fondu

    scene bg cuisine with fondu
    show maman normal at centre with fondu
    $ rencontrer("maman")
    narrator "Maman est dans la cuisine, en train d'éplucher des pommes. Elle me voit. Le couteau s'arrête."
    mam "…"
    mam "Je ne pleure pas. C'est les pommes."
    narrator "Elle me serre si fort que j'entends mon dos craquer. Elle sent la lessive et le café, comme toujours."
    mam "Assieds-toi. Mange. Tu mangeras d'abord, tu parleras après."
    narrator "Je mange. Elle me regarde manger comme on regarde un feu de cheminée."
    mam "Maintenant, raconte. Pas ce que tu dis au téléphone. Le vrai."
    menu:
        "Lui raconter la vérité sur la semaine.":
            narrator "Je lui raconte. Pas tout : pas le Livre, pas les mercredis. Mais Iris, le laboratoire, l'Azur, le quai 7, l'arrestation."
            narrator "Au mot « quai 7 », elle pose son épluche-légumes. Très doucement, comme on pose quelque chose de fragile."
            $ noter("verite_maman")
            $ varier(moral=1)
        "Lui dire que tout va bien.":
            moi "Tout va bien, Maman. Les cours, les amis. Rien de spécial."
            mam "Tu mens comme ton père. Avec les sourcils."
            mam "J'ai vu les informations. Valcourt, une drogue, le port. Et toi qui m'appelles moins que d'habitude."
            mam "Le port. Le quai 7, c'est ça ?"
    mam "Attends-moi là."
    hide maman with fondu
    narrator "Elle revient avec une boîte à chaussures que je n'ai jamais vue. Le carton est mou à force d'avoir été ouvert."
    show maman normal at centre with fondu
    mam "Ton père n'est pas mort à l'usine de Saint-Aubin. Je t'ai menti. Ta sœur le sait, toi tu étais trop petit{g=/e}."
    mam "Il était docker. À Valcourt. Au quai 7."
    mam "En 2018, un conteneur est tombé. « Accident », a dit la police. Enquête classée en trois jours."
    mam "La semaine d'avant, il m'avait dit qu'il avait vu des choses. Qu'il allait parler. Et puis le conteneur."
    narrator "Elle ouvre la boîte. Une photo. Un carnet à spirale, couverture tachée d'huile."
    mam "Quand ta bourse est arrivée, une bourse de Valcourt, j'ai pleuré deux jours. De joie, et de peur. Je ne voulais pas que tu t'approches de ce port."
    mam "Et tu t'en es approché{g=/e} en une semaine. Tu es bien son enfant."
    $ obtenir("carnet_pere")
    $ donner("photo_pere")
    $ noter("verite_papa")
    narrator "Sur la dernière page écrite, au crayon, de l'écriture penchée de Papa :"
    narrator "{i}« Le Capitaine n'est pas un marin. Il ne monte jamais à bord. Il a les clés du port comme d'autres celles d'une école. »{/i}"
    pensee "Le Capitaine. En 2018, déjà."
    mam "Promets-moi une chose. Ne finis pas comme lui."
    menu:
        "« Je serai prudent{g=/e}. »":
            mam "Prudent{g=/e}. Il disait ça aussi. Mais je te crois. Il faut bien que je croie quelqu'un."
        "« Je ne peux pas te promettre ça. »":
            mam "…Non. Évidemment. Il ne pouvait pas non plus."
            mam "Alors promets-moi au moins de m'appeler. Tous les dimanches. Même pour ne rien dire."
            $ noter("promesse_dimanches")
    $ souvenir("Maman m'a dit la vérité sur Papa : docker au quai 7, mort en 2018.", "maman normal", "bg cuisine")
    hide maman with fondu

    scene bg cuisine nuit with noir
    $ poser_heure("SAMEDI · 23 H 30")
    $ musique_jouer("tristesse")
    show maelle normal at centre with fondu
    narrator "Tard dans la nuit, Maëlle et moi buvons une tisane dans la cuisine, la photo de Papa posée entre nous."
    ma "Tu as ses yeux, tu sais. Quand tu fronces les sourcils, c'est lui. Exactement lui."
    ma "Je ne m'en souviens presque plus, de son visage. Alors je te regarde, et ça revient."
    narrator "Je regarde la photo longtemps. Un homme au soleil, sur un quai, qui rit de quelque chose hors du cadre."
    narrator "Je m'applique à retenir chaque trait. Je ne sais pas pourquoi. J'ai l'impression qu'il le faut."
    $ souvenir("Maëlle m'a dit que j'avais les yeux de Papa.", "maelle normal", "bg cuisine nuit")
    hide maelle with fondu
    $ energie = borner(energie + 5)
    $ jour = 13
    call resume_jour("Samedi")
    $ jour = 14
    call titre(7, "Dimanche", "19 octobre", "L'anniversaire")

    scene bg cuisine with fondu
    $ poser_heure("DIMANCHE · 12 H 30")
    $ musique_jouer("espoir")
    show maman joie at gauche_c with fondu
    show maelle normal at droite_c with fondu
    narrator "Un poulet rôti, une nappe à carreaux, cinquante-deux bougies qu'on n'a pas eu le courage de compter. Maëlle en a planté douze."
    if possede("chocolats"):
        narrator "Je sors la boîte de chocolats achetée pour Clara, qui n'a jamais servi. Maman la serre contre elle comme un trésor."
        $ retirer("chocolats")
    else:
        ma "Le cadeau est de nous deux. Il ne le sait pas encore, mais il est de nous deux."
    mam "Mon vœu, c'est que tu reviennes à Noël avec la même tête qu'aujourd'hui."
    mam "Pas plus maigre, pas plus triste. La même tête."
    narrator "Elle souffle. Les douze bougies s'éteignent d'un coup."
    $ souvenir("Maman a soufflé ses bougies. Son vœu : que je revienne à Noël avec la même tête.", "maman normal", "bg cuisine")
    hide maman
    hide maelle
    with fondu

    scene bg gare with fondu
    $ poser_heure("DIMANCHE · 14 H 10")
    show maelle normal at centre with fondu
    ma "Ne disparais pas, d'accord ? Pas comme lui. Pas du tout."
    moi "Je ne disparaîtrai pas."
    narrator "Je le dis avec beaucoup d'assurance. Je ne sais pas encore à quel point c'est une promesse difficile."
    hide maelle with fondu
    scene bg train with fondu
    narrator "Le train me ramène à Valcourt. Les champs, puis la mer, puis les grues."
    $ varier(moral=3, energie=1)
    $ musique_jouer("enquete")
    return

label a2_hopital:
    $ n = visite("hopital2")
    $ musique_jouer("mystere")
    if n == 1:
        scene bg hopital chambre with fondu
        show hugo fatigue at gauche with fondu
        show clara sourire at droite with fondu
        narrator "Hugo est assis dans son lit, pâle, une perfusion au bras. Clara est déjà là, assise en tailleur sur la chaise des visiteurs."
        hu "Paraît que je dois une fière chandelle à des gens que je ne connais même pas."
        c "Il dit ça à tout le monde. Même à l'infirmière."
        moi "Hugo, les pastilles… Qui te les vendait ?"
        hu "Au début, Nathan. Discret, gentil, presque gêné. Puis depuis la rentrée, un type du port. Casquette, blouson, pas de nom."
        hu "Il disait toujours la même blague : « C'est le Capitaine qui régale. » Je croyais que c'était une blague."
        $ noter("hugo_capitaine")
        hide hugo
        hide clara
        with fondu
        scene bg hopital with fondu
        narrator "Au bout du couloir, une porte gardée par un policier en uniforme. Derrière, Éléonore Lambert."
        narrator "Au bureau des infirmières, une femme d'une cinquantaine d'années remplit des feuilles de soins."
        if filiere == "sciences":
            moi "Excusez-moi. Pour la patiente de la chambre 12, le protocole de décontamination, c'est un antagoniste des benzodiazépines ?"
            infirmiere "…Vous êtes en médecine ?"
            moi "En chimie. Et je connais le labo d'où sort le poison qui a envoyé mon ami dans la chambre d'à côté."
            narrator "Elle hésite, puis tourne le dossier vers moi, juste assez longtemps pour que je lise."
            $ obtenir("toxico")
        elif niveau("malo") >= 4:
            narrator "J'appelle Malo. Dix minutes plus tard, le fax de l'étage crache une feuille."
            m "Tu ne l'as pas eue par moi. Officiellement, je ne suis plus sur l'affaire."
            $ obtenir("toxico")
        elif temperament == "empathique":
            narrator "L'infirmière a les yeux rouges. Je lui demande si elle va bien. Elle me raconte sa garde, ses enfants, la patiente de la 12."
            infirmiere "Un sédatif d'hôpital. Une dose de cheval. Vous savez ce qui me rend malade ? Ça ne se trouve pas dans une cellule. Quelqu'un l'a apporté."
            $ obtenir("toxico")
        else:
            infirmiere "Secret médical. Revenez avec un policier, ou ne revenez pas."
            $ noter("toxico_refuse")
        $ noter("hopital_visite")
        $ souvenir("Hugo m'a parlé d'un type du port : « C'est le Capitaine qui régale. »", "hugo fatigue", "bg hopital chambre")
    elif n == 2:
        scene bg hopital chambre with fondu
        narrator "Le policier de garde est parti fumer. La porte de la chambre 12 est entrouverte."
        show eleonore normal at centre with fondu
        narrator "Éléonore Lambert dort, si c'est dormir. Des tuyaux, des écrans, un bip régulier. Elle paraît plus jeune sans son chignon."
        pensee "Mercredi, cette femme voulait arracher une clé des mains d'Iris. Aujourd'hui, quelqu'un a voulu la faire taire pour toujours."
        narrator "Ses lèvres bougent. Je me penche."
        el "…l'ancre…"
        narrator "Puis plus rien. Le bip, régulier."
        $ noter("eleonore_ancre")
        if fait("chevaliere_vue"):
            pensee "Une ancre. La chevalière de Ferrière. Non. Ce n'est qu'un mot, dans la bouche d'une femme dans le coma."
            pensee "…C'est un mot de trop."
        hide eleonore with fondu
        scene bg hopital with fondu
        narrator "Le policier revient en écrasant sa cigarette. Il me regarde sans colère, avec l'air d'un homme qui s'ennuie."
        agent "Vous n'avez rien à faire là. Allez, ouste. Déjà que le patron est passé hier soir, si en plus les étudiants s'y mettent…"
        moi "Le patron ?"
        agent "Le commissaire. Il vient tous les soirs, un quart d'heure. Il s'occupe de ses gens, lui. Même de ceux qui ont mal tourné."
        $ noter("ferriere_visite_hopital")
        if fait("toxico_refuse") and not a("toxico") and niveau("malo") >= 4:
            narrator "En repartant, j'appelle Malo. Le fax de l'étage crache une feuille. L'infirmière me la tend sans un mot."
            $ obtenir("toxico")
        $ souvenir("Dans le coma, Éléonore a murmuré un seul mot : « l'ancre ».", "eleonore normal", "bg hopital chambre")
    else:
        scene bg hopital chambre with fondu
        show hugo sourire at centre with fondu
        narrator "Hugo me bat trois fois aux cartes. Il triche. Je le laisse faire. C'est bon de voir quelqu'un tricher pour rire."
        $ varier(moral=1)
        hide hugo with fondu
    $ varier(energie=-1)
    return

label a2_capitainerie:
    scene bg capitainerie with fondu
    $ ambiance("port")
    $ musique_jouer("enquete")
    $ n = visite("capitainerie")
    if n > 1:
        narrator "L'agent de la capitainerie me reconnaît de loin et secoue la tête. « Revenez avec un mandat. »"
        $ varier(energie=-1)
        $ ambiance(None)
        return
    narrator "La capitainerie est un bâtiment de brique au bout de la jetée. À l'intérieur, des registres, une radio qui grésille et un agent qui mange un sandwich."
    $ acces = False
    if filiere == "droit":
        moi "Les registres de mouvements des navires sont des documents publics. Article 12 du code des ports, si je ne me trompe pas."
        employe_port "…Vous ne vous trompez pas. Vous êtes pénible, mais vous ne vous trompez pas."
        $ acces = True
    elif possede("carte_presse"):
        moi "Presse. Un article sur le trafic du port, pour l'Académie."
        employe_port "La Gazette ? On m'a dit qu'elle était fermée."
        moi "Elle l'est. C'est pour ça que l'article sera bon."
        narrator "Il rit, et pousse le registre vers moi."
        $ acces = True
    elif temperament == "audacieux":
        narrator "Je prends l'air pressé d'un stagiaire envoyé par un patron colérique."
        moi "Halvard Maritime. On me demande les mouvements de l'Ondine depuis septembre. Avant midi. Sinon c'est ma tête."
        employe_port "Encore ? Ils ont perdu leur copie ? Tenez, et ne me mettez pas de miettes dessus."
        $ acces = True
    if not acces:
        employe_port "Les registres ne sont pas ouverts au public, {g=jeune_homme/mademoiselle}."
        pensee "Il me faudrait une raison officielle. Une carte, un titre… Amélie a sûrement une idée."
        $ noter("capitainerie_refus")
        $ varier(energie=-1)
        $ ambiance(None)
        return
    $ obtenir("capitainerie")
    employe_port "L'Ondine. Compagnie Halvard Maritime. Elle part tous les jeudis vers vingt-trois heures, pour les îles. Retour le samedi."
    employe_port "Jamais inspectée. Réquisition du central, affaire en cours. On ne pose pas de questions quand c'est la police qui demande."
    employe_port "Le chef de port appelle ça « les jeudis du Capitaine ». C'est une blague. Je crois."
    employe_port "Ce jeudi, elle n'est pas partie. Première fois en deux ans. Elle est toujours à quai, là-bas, toute bleue."
    $ noter("ondine_halvard", "jeudis_capitaine")
    $ souvenir("À la capitainerie, l'Ondine n'était jamais inspectée : « réquisition du central ».", None, "bg capitainerie")
    pensee "Le bateau est à Halvard. Mais le tampon, lui, est celui de la police."
    $ varier(energie=-1)
    $ ambiance(None)
    return

label a2_villa:
    $ musique_jouer("mystere")
    if moment in ("soir", "nuit"):
        scene bg villa nuit with fondu
        $ ambiance("pluie")
        narrator "Le mur du parc fait deux mètres. Il y a un chêne contre le mur. Il y a toujours un chêne contre le mur."
        narrator "Je me laisse tomber dans une haie de buis. Au fond du jardin, près de la serre, une lueur orange."
        show halvard normal at centre with fondu
        narrator "Henri Halvard, en robe de chambre, brûle des lettres dans un brasero. Une par une. Il les relit avant de les jeter."
        narrator "À la dernière, il se met à pleurer. Un homme de cette taille qui pleure, ça ne fait pas de bruit, ça fait trembler les épaules."
        hide halvard with fondu
        narrator "Quand il est rentré, je m'approche du brasero. Un coin de papier n'a pas brûlé, coincé sous la grille."
        $ obtenir("lettre_brulee")
        $ noter("halvard_brule", "halvard_peur", "halvard_vu")
        pensee "« Sinon la Fondation apprendra d'où vient son argent. — C. »"
        pensee "Halvard ne commande pas. Quelqu'un le fait chanter."
        $ souvenir("Dans son jardin, Henri Halvard brûlait des lettres de chantage en pleurant.", "halvard normal", "bg villa nuit")
        $ varier(energie=-2)
        $ ambiance(None)
        return

    scene bg villa with fondu
    $ n = visite("villa")
    if n > 1:
        narrator "Le portail est fermé. Un majordome m'annonce, à travers l'interphone, que « Monsieur ne reçoit plus »."
        narrator "Derrière une fenêtre du premier étage, un rideau bouge."
        $ varier(energie=-1)
        return
    narrator "La villa Halvard domine la baie. Une allée de gravier, une fontaine, des fenêtres partout. Une maison qui veut qu'on la voie."
    if possede("carte_presse") or filiere == "lettres":
        narrator "J'annonce une interview pour la Gazette. Le majordome me fait attendre vingt minutes, puis me fait entrer."
    elif filiere == "droit":
        narrator "Je me présente comme assistant{g=/e} de Maître Varga. Le nom ouvre le portail en trente secondes."
    else:
        narrator "Le majordome me renvoie. Je suis presque à la grille quand une voix grave me rappelle depuis le perron."
        hal "C'est vous, l'étudiant{g=/e} qui a fait tomber Lambert ? Entrez. Cinq minutes."
    show halvard normal at centre with fondu
    hal "Je n'ai pas l'habitude qu'on m'interroge chez moi. Alors soyez bref{g=/e}."
    $ parle = True
    while parle:
        menu:
            "Lui parler de l'Ondine.":
                hal "L'Ondine est louée. Contrat à l'année, à une société de transport. Mon conseil s'en occupe. Je ne lis pas les contrats de location."
                moi "Vous ne savez pas ce qu'elle transporte ?"
                hal "Des caisses. Les bateaux transportent des caisses. C'est même leur seule qualité."
            "Lui demander pourquoi il a fermé la Gazette.":
                hal "Pour vous protéger. Tous. Vous ne savez pas à qui vous avez affaire."
                moi "Et vous, vous le savez ?"
                narrator "Il ne répond pas tout de suite. Il regarde la baie."
                hal "…Non. Moi non plus. C'est bien ça le problème."
                $ noter("halvard_ne_sait_pas")
            "Lui montrer le registre de la capitainerie." if a("capitainerie"):
                narrator "Je pose la feuille sur son bureau. Il lit. Il blêmit."
                hal "« Sur réquisition du central. » Évidemment."
                narrator "Il rit. Un rire sans joie, qui ressemble à une toux."
                hal "Vous croyez que c'est moi qui ai le bras assez long pour lever les douanes ? Je vends des bateaux, mon petit. Je ne commande pas la police."
                $ noter("halvard_peur")
            "Lui parler du Capitaine." if fait("capitaine_nomme") or fait("hugo_capitaine") or fait("jeudis_capitaine"):
                narrator "À ce mot, son verre d'eau lui échappe. Il roule sur le tapis sans se briser."
                hal "Ne prononcez jamais ce mot chez moi. Jamais. Vous m'entendez ?"
                if temperament == "empathique":
                    pensee "Ce n'est pas de la colère. C'est de la peur. Une vieille peur, usée jusqu'à la corde."
                $ noter("halvard_peur")
            "Prendre congé.":
                $ parle = False
    hal "Rentrez à l'Académie. Révisez vos partiels. Et oubliez le port. Moi, je n'ai jamais pu."
    $ noter("halvard_vu")
    $ souvenir("Henri Halvard m'a dit : « Oubliez le port. Moi, je n'ai jamais pu. »", "halvard normal", "bg villa")
    hide halvard with fondu
    $ varier(energie=-1)
    return

label a2_redaction:
    scene bg redaction with fondu
    $ musique_jouer("enquete")
    $ n = visite("redaction")
    if n == 1:
        show amelie normal at centre with fondu
        narrator "Amélie a rapporté de sa cave trois cartons de vieilles Gazettes, et deux araignées vexées."
        am "Vingt ans de Halvard. Inaugurations, dons, galas. Il sourit sur toutes les photos, sauf une."
        am "Gala de la Fondation, l'an dernier. Halvard, Isabella, et un type de dos. Pas de légende. Le photographe a pris sa retraite au soleil."
        $ obtenir("photo_gala")
        if fait("chevaliere_vue") or filiere == "lettres":
            narrator "Je prends la loupe d'Amélie. L'homme de dos porte une chevalière. Sur la chevalière, une ancre."
            $ examiner("photo_gala")
            if fait("chevaliere_vue"):
                pensee "Je l'ai déjà vue, cette bague. Jeudi. Au commissariat."
        am "Regarde comment Halvard lui serre la main. Les yeux baissés. Comme un employé devant son patron."
        $ souvenir("Dans les archives de la Gazette, un homme de dos serrait la main d'Henri Halvard.", "amelie normal")
        hide amelie with fondu
    elif n == 2:
        show iris normal at gauche with fondu
        show clara pensif at droite with fondu
        narrator "Le premier numéro de « [gazette_nom] » doit sortir cette nuit, glissé sous toutes les portes de la résidence."
        ir "Il nous faut une une. Une seule phrase, en gros. C'est toi qui décides : c'est toi qui as pris les risques."
        menu:
            "« QUI EST LE CAPITAINE ? » — poser la question à tout Valcourt.":
                ir "Ils vont avoir peur. Les gens qui ont peur font des erreurs."
                c "Ou des bêtises."
                $ noter("une_capitaine")
                $ lien("iris", 1)
            "« L'AZUR N'EST PAS MORT » — avertir les étudiants.":
                ir "Moins spectaculaire. Plus utile. D'accord."
                c "Je dessine une fiole qui pleure. Non, c'est nul. Une fiole qui ment."
                $ noter("une_azur")
                $ lien("clara", 1)
            "Attendre d'avoir des preuves avant de publier.":
                ir "Tu es sûr{g=/e} ? On perd une semaine."
                moi "On perd une semaine, ou on perd la seule chance qu'on a."
                ir "…Tu parles comme moi à la cinquième boucle. C'est inquiétant."
                $ noter("une_attente")
                $ lien("malo", 1, silencieux=True)
        if not fait("une_attente"):
            narrator "Clara dessine la couverture : un phare, et dans la lumière du phare, un bateau sans nom."
            narrator "À trois heures du matin, trois cents exemplaires dorment sous trois cents portes."
            $ souvenir("Le premier numéro de la Gazette clandestine a été glissé sous trois cents portes.", "clara pensif")
        hide iris
        hide clara
        with fondu
        $ varier(energie=-1)
    else:
        narrator "La rédaction sent la colle et le café. Clara dessine, Iris écrit, Amélie téléphone à trois personnes en même temps."
        menu:
            "Aider Clara à mettre en couleurs.":
                show clara sourire at centre with fondu
                c "Tu dépasses. C'est bien. Les gens qui ne dépassent jamais m'inquiètent."
                $ lien("clara", 1)
                hide clara with fondu
            "Relire les articles d'Iris.":
                show iris normal at centre with fondu
                ir "Trois fautes. Tu en trouves toujours trois. C'est presque un pouvoir surnaturel."
                $ lien("iris", 1)
                hide iris with fondu
            "Écouter Amélie raconter ses vingt ans de Gazette.":
                show amelie normal at centre with fondu
                am "…et c'est comme ça que le maire a fini dans la fontaine. Bon, il n'y est pas tombé, il y a été poussé. Par moi. Mais il le méritait."
                $ lien("amelie", 1)
                hide amelie with fondu
        $ varier(moral=1)
    return

label a2_commissariat2:
    scene bg commissariat with fondu
    $ musique_jouer("enquete")
    $ n = visite("commissariat2")
    show malo fatigue at centre with fondu
    if n == 1:
        narrator "Malo range des dossiers dans un carton. Le carton dit « ARCHIVES ». Malo dit autre chose, entre ses dents."
        m "Retiré de l'affaire. Ce matin. Ferrière dit que je suis « trop proche des étudiants »."
        m pensif "Il n'a peut-être pas tort. Hier, je t'ai demandé de ne parler à personne. Ce matin, c'est moi qu'on prie de ne parler à personne."
        $ noter("malo_ecarte")
    else:
        m "Encore toi. Assieds-toi. Je n'ai plus d'affaire, mais j'ai encore une chaise."
    $ continuer = True
    while continuer:
        menu:
            "Lui montrer ce que j'ai trouvé.":
                $ code = renpy.call_screen("dossier", presenter=True, question="Quelle pièce montrer à Malo ?")
                if code is None:
                    pass
                elif code in montre_a_malo2:
                    m "Tu me l'as déjà montrée. J'y pense encore, si tu veux savoir."
                elif code == "capitainerie":
                    $ montre_a_malo2.add(code)
                    m surprise "« Sur réquisition du central. » C'est notre maison qui a levé les inspections de l'Ondine."
                    m "Non. Il y a vingt bureaux qui peuvent tamponner au nom du central. Vingt."
                    m pensif "…Mais il n'y en a qu'un qui signe les réquisitions d'affaires en cours."
                    $ noter("malo_doute")
                    $ lien("malo", 1)
                elif code == "toxico":
                    $ montre_a_malo2.add(code)
                    m "Sédatif hospitalier, entre vingt et une heures et vingt-deux heures. À cette heure-là, au sous-sol, il n'y avait que des policiers."
                    m colere "Des miens. Des gens avec qui je bois des cafés froids."
                    $ noter("malo_doute")
                    $ lien("malo", 1)
                elif code == "photo_gala":
                    $ montre_a_malo2.add(code)
                    if "photo_gala" in preuves_examinees:
                        m "Halvard, Isabella Varga, et…"
                        narrator "Il s'arrête. Il prend la loupe sur son bureau. Il regarde longtemps la main de l'homme de dos."
                        m peur "Cette bague. Je l'ai vue cent fois. Sur la main qui me tendait mon premier café froid, il y a huit ans."
                        m "Non. Il y a des milliers de chevalières dans cette ville. Des milliers."
                        m determine "Laisse-moi vérifier. Ne fais rien. Ne dis rien à personne. Promets-le-moi."
                        moi "Je te le promets."
                        $ noter("malo_reconnait")
                        $ lien("malo", 2)
                        $ souvenir("Malo a reconnu la chevalière sur la photo du gala. Il n'a pas voulu dire à qui elle appartenait.", "malo peur")
                    else:
                        m "Halvard et Isabella dans un gala. Et un type de dos. Et alors ? Les riches font des galas, c'est leur sport."
                        pensee "Il faudrait que je regarde cette photo de plus près, dans le Dossier."
                elif code == "carnet_pere":
                    $ montre_a_malo2.add(code)
                    m "Ton père était docker au 7 ? En 2018 ?"
                    m pensif "L'accident du conteneur. J'étais en école de police. On en parlait, parce que l'enquête avait été classée en trois jours. Par le central."
                    m "Je suis désolé. Je ne savais pas que c'était ton père. Personne ne savait grand-chose, à l'époque. On ne voulait pas savoir."
                    $ noter("malo_doute")
                    $ lien("malo", 1)
                elif code == "lettre_brulee":
                    $ montre_a_malo2.add(code)
                    m "« C. » Halvard est fait chanter. Depuis combien de temps, et par qui ?"
                    m "Un armateur qui a peur d'un seul homme. Je ne vois pas beaucoup de gens, à Valcourt, capables de faire peur à Halvard."
                    $ lien("malo", 1)
                else:
                    m "Ça, c'est l'affaire Lambert. Elle est tombée. C'est au-dessus d'elle qu'il faut chercher, maintenant."
            "Lui demander des nouvelles de Nathan." if not fait("nathan_peur_police"):
                m "Transféré à la maison d'arrêt. Il ne parle plus. Il a demandé une seule chose à son avocat."
                m "Que personne du commissariat central ne l'approche. Personne. Tu trouves ça normal, toi ?"
                $ noter("nathan_peur_police")
            "Partir.":
                $ continuer = False
    m "File. Et ne viens plus trop ici. Il y a des oreilles dans les murs, ces temps-ci."
    hide malo with fondu
    $ varier(energie=-1)
    return

label a2_bibliotheque2:
    if moment == "nuit":
        scene bg reserve with fondu
        show halo_or
        $ musique_jouer("boucle")
        narrator "La réserve, la nuit. Le marque-page m'ouvre la porte comme une clé. Le Livre est là, sur son pupitre, ouvert."
        narrator "Je tourne les premières pages. Un nom revient, encore et encore, d'une écriture de plus en plus pâle : {i}Iris Delaunay. Iris Delaunay. Iris…{/i}"
        narrator "Huit fois. La dernière est presque effacée."
        pensee "Elle a donné tout ça. Les saveurs, les voix. Pour une semaine qui ne finissait pas."
        $ noter("noms_iris_vus")
        $ varier(moral=-1, energie=-1)
        hide halo_or
        return
    scene bg bibliotheque with fondu
    $ musique_jouer("quotidien")
    if possede("marque_page") and not fait("livre_page_vue"):
        show bernier normal at centre with fondu
        ob "Ah. Vous. J'attendais votre visite. Le marque-page vous a ramené{g=/e}, n'est-ce pas ? Il ramène toujours."
        narrator "Elle m'emmène dans la réserve. Le Livre est ouvert à la page où j'ai écrit mon nom."
        scene bg reserve with fondu
        show bernier normal at centre with fondu
        narrator "Mon nom est là. Mais l'encre a pâli sur les bords, comme une photo laissée au soleil."
        ob "Le Livre prend toujours quelque chose. À celle qui l'a ouvert avant vous, il a pris des saveurs, des voix. Il ne prévient jamais."
        moi "Qu'est-ce qu'il m'a pris, à moi ?"
        ob "Vous le saurez quand vous le chercherez et que ce ne sera plus là. C'est comme ça qu'on le sait, toujours."
        $ _pages_txt = "une page blanche" if pages <= 1 else "%d pages blanches" % pages
        ob "Il reste [_pages_txt]. Celui qui a écrit ce Livre disait qu'il fallait le payer en souvenirs. Je vous raconterai son histoire. Un jour. Pas aujourd'hui."
        $ noter("livre_page_vue")
        $ souvenir("Dans le Livre, l'encre de mon nom avait pâli sur les bords.", "bernier normal", "bg reserve")
        hide bernier with fondu
        $ varier(energie=-1)
        return
    menu:
        "Réviser les partiels (deux heures, au calme).":
            narrator "Je m'installe à la table du fond. Celle qu'Iris dit que je choisis toujours."
            narrator "Droit des obligations, méthodologie, histoire des institutions. Les mots entrent mal, puis mieux."
            $ revisions_partiels += 1
            $ varier(energie=-1)
        "Demander à Mme Bernier les archives sur le port.":
            show bernier normal at centre with fondu
            ob "Le port ? Les journaux régionaux sont sur microfilm. Qu'est-ce que vous cherchez ?"
            moi "Des accidents. Au quai 7."
            narrator "Une demi-heure plus tard, un article de 2018 s'affiche, jauni, sur l'écran de la visionneuse."
            narrator "{i}« Accident mortel au quai 7. Un docker de quarante-deux ans meurt écrasé par un conteneur. Le commissariat central conclut à l'accident. »{/i}"
            if fait("verite_papa"):
                pensee "Papa. Trois lignes. Une vie entière, et trois lignes."
                $ varier(moral=-1)
            else:
                pensee "Un docker, un conteneur, une enquête close. Encore le central."
            $ noter("article_2018")
            hide bernier with fondu
    return

label a2_chambre2:
    if moment == "nuit":
        scene bg chambre nuit with fondu
    else:
        scene bg chambre with fondu
    $ musique_jouer("quotidien")
    menu:
        "Dormir." if moment == "nuit":
            narrator "Je m'endors en pensant à un bateau bleu qui ne part plus le jeudi."
            $ dormi_cette_nuit = True
        "Faire une sieste." if moment != "nuit":
            narrator "Deux heures de sommeil, lourd comme une ancre."
            $ varier(energie=3)
        "Réviser les partiels.":
            narrator "Fiches, surligneur, café. La méthode qui marche quand plus rien ne marche."
            $ revisions_partiels += 1
            $ varier(energie=-1)
            if moment == "nuit":
                $ dormi_cette_nuit = True
                narrator "Je m'endors sur mes fiches vers une heure du matin. C'est presque dormir."
                $ varier(energie=-1)
        "Appeler Maman pour son anniversaire, en avance." if jour == 13 and not fait("rentre_maison") and not fait("appel_anniv_tot"):
            mam "Allô ? C'est toi ? Il est arrivé quelque chose ?"
            moi "Non, rien. Je voulais te souhaiter ton anniversaire. Je ne pourrai pas venir demain."
            mam "Oh. Ce n'est pas grave. Tu m'as appelée un samedi, c'est déjà un cadeau. Ta sœur n'a appelé qu'une fois cette année, et c'était pour une recette."
            $ rencontrer("maman")
            $ noter("appel_anniv_tot")
            $ varier(moral=1)
        "Appeler Maëlle.":
            ma "Tu sais quelle heure il est ? Non, ne réponds pas, je sais que tu ne sais pas."
            ma "Ça va, toi ? Vraiment ?"
            moi "Vraiment, je ne sais pas. Mais je suis entouré{g=/e}."
            ma "C'est déjà ça. C'est même beaucoup."
            $ varier(moral=1)
            if moment == "nuit":
                $ dormi_cette_nuit = True
    return


################################################################################
## Lundi — à suivre
################################################################################

label acte2_lundi:
    $ jour = 15
    $ moment = "matin"
    call titre(8, "Lundi", "20 octobre", "Les partiels")
    scene bg classe with fondu
    $ poser_heure("LUNDI · 07 H 45")
    $ musique_jouer("tension")
    narrator "Lundi matin. Trois cents étudiants dans le hall des examens, des fiches plein les mains."
    if fait("une_capitaine") or fait("une_azur"):
        narrator "Dans presque toutes les poches, un journal plié en quatre. En première page, un phare, et le nom « [gazette_nom] »."
    if revisions_partiels >= 3:
        pensee "J'ai révisé. Pas assez, jamais assez, mais j'ai révisé."
    elif revisions_partiels >= 1:
        pensee "J'ai un peu révisé. Il faudra que ça suffise."
    else:
        pensee "Je n'ai pas révisé. Pas une minute. J'ai poursuivi un Capitaine pendant que les autres apprenaient leurs fiches."
    narrator "Quelque part en ville, un commissaire tourne une chevalière à son doigt. Un armateur brûle des lettres. Une femme dort, et murmure un seul mot."
    narrator "Et sur une page du Livre, dans la réserve, mon nom pâlit encore un peu."
    jump acte2_partiels


################################################################################
## Départ de chapitre (Extras)
################################################################################

label depart_acte2:
    $ quick_menu = True
    $ noter("marque_page", "lettre_iris", "legende_livre", "livre_trouve", "quai7_tot", "souvenirs", "iris_alliee", "malo_prevenu", "clara_protegee")
    $ donner("marque_page", silencieux=True)
    $ donner("lettre_iris", silencieux=True)
    $ rencontrer("clara", "iris", "dorian", "isabella", "eleonore", "malo", "maelle", "amelie", "lucas", "hugo", "nathan", "bernier")
    $ rel.update({"clara": 6, "malo": 5, "iris": 7, "amelie": 4, "isabella": 3, "dorian": 4})
    $ pages = 2
    $ boucle = 2
    $ argent = 42
    jump acte2
