## Jour 2 — Mardi : le bal d'automne.

label mardi:
    $ chapitre = "mardi"
    $ jour = 2
    $ moment = "matin"
    $ cafes_du_jour = 0
    call titre(2, "Mardi", "14 octobre", "Le bal d'automne")
    $ debut_jour_etat = instantane()

    scene bg chambre with fondu
    $ poser_heure("MARDI · 06 H 50")
    $ musique_jouer("quotidien")

    narrator "Je me réveille avant le réveil. Par la fenêtre, le port est encore bleu de nuit."
    scene bg academie nuit with fondu
    narrator "En bas, dans la cour, une silhouette traverse vers les grilles. Capuche relevée, un sac en bandoulière, un pas pressé."
    show iris normal at centre with fondu
    narrator "Elle se retourne une seconde vers la résidence, comme si elle sentait qu'on la regarde. C'est Iris."
    pensee "À cette heure-ci ? Elle ne va pas en cours : elle part vers le port."
    hide iris with fondu
    scene bg chambre with fondu
    narrator "Sur mon téléphone, l'emploi du temps : {i}8 h, droit des contrats — appel obligatoire. 10 h, chimie générale.{/i}"
    narrator "Le règlement est clair : le conseil des bourses lit les listes d'absences chaque vendredi."
    if energie <= 5:
        pensee "Et je suis {g=épuisé/épuisée}. Mon lit n'a jamais été aussi tentant."
    pensee "Suivre Iris, c'est peut-être comprendre ce qu'elle cache. C'est aussi un cours manqué dès le deuxième jour."

    $ choix = choisir_creneau("Mardi matin — 6 h 50", [
        ("cours", "Aller en cours", "Être là, prendre des notes, exister aux yeux des professeurs. L'appel est obligatoire.", {"etudes": 1, "energie": -1}, True, "", "gui/icone_etudes.png"),
        ("suivre", "Suivre Iris", "Elle file vers les docks avant l'aube, seule. Que va-t-elle y faire ?", {"etudes": -1, "energie": -1}, True, "", "medaillons/iris/normal.png"),
        ("dormir", "Se rendormir", "Une heure de plus. Mais l'appel de 8 h se fera sans moi.", {"energie": 2, "etudes": -1}, True, "", "gui/icone_energie.png"),
    ], "Iris disparaît vers le port. Le cours commence dans une heure.")

    if choix == "cours":
        scene bg classe eleves with fondu
        $ poser_heure("MARDI · 08 H 00")
        narrator "Deux heures de contrats, une heure de chimie. Je remplis douze pages de notes."
        narrator "Le professeur de chimie annonce que le laboratoire sera « fermé le soir jusqu'à nouvel ordre, à la demande de la direction »."
        pensee "Fermé le soir. Pourquoi un laboratoire aurait-il besoin d'être fermé le soir ?"
        $ noter("labo_ferme_soir")
        $ cocher("cours_mardi")
        $ varier(etudes=1, energie=-1)
    elif choix == "suivre":
        scene bg rue with fondu
        $ ambiance("ville")
        $ poser_heure("MARDI · 07 H 05")
        narrator "Je garde trente mètres de distance. Iris marche vite, sans se retourner, jusqu'aux docks."
        scene bg port with fondu
        $ ambiance("port")
        $ musique_jouer("tension")
        narrator "Le port, à l'aube, sent le gasoil et le sel. Iris s'arrête devant un hangar marqué d'un grand 7 peint en blanc."
        narrator "Elle prend une photo. Deux. Trois. Puis elle repart, aussi vite qu'elle est venue."
        pensee "Quai 7. Un hangar. Et une étudiante en chimie qui le photographie à sept heures du matin."
        $ noter("quai7_tot")
        $ souvenir("À l'aube, j'ai suivi Iris jusqu'au hangar du quai 7.")
        $ lien("iris", 1, silencieux=True)
        $ varier(etudes=-1, energie=-1)
        $ ambiance(None)
    else:
        narrator "Je ferme les yeux « cinq minutes »."
        narrator "Quand je les rouvre, il est neuf heures quarante. Le cours de contrats est presque fini."
        pensee "Personne ne fait l'appel le mardi. Sauf ce mardi, apparemment. Mon nom résonne dans une salle vide."
        $ varier(energie=2, etudes=-1)

    ## ---------------------------------------------------------------------
    ## La cantine
    ## ---------------------------------------------------------------------
    scene bg cantine with fondu
    $ moment = "après-midi"
    $ poser_heure("MARDI · 12 H 30")
    $ ambiance("salle")
    $ musique_jouer("quotidien")

    narrator "À midi, la cantine est un champ de bataille. Je cherche une place, mon plateau à bout de bras."

    show amelie normal at gauche_c with fondu
    $ rencontrer("amelie")
    am "Hé ! {g=Le/La} {g=boursier/boursière} ! Viens là, il reste une place. Je suis Amélie, rédactrice en chef de la Gazette de Valcourt."
    am "Ce qui veut dire que je sais tout sur tout le monde, et que je n'écris presque rien. C'est ça, le vrai journalisme."
    show lucas normal at droite_c with fondu
    $ rencontrer("lucas", "hugo")
    if fait("piste_hugo_tot"):
        lu "Tiens, {g=le/la} collègue de la plonge ! Assieds-toi."
    else:
        lu "Salut. Lucas. Droit, deuxième année, et accessoirement le seul ici qui sait faire une passe."
    narrator "À côté de Lucas, un garçon pâle fixe son plateau sans y toucher. Des cernes violets, les mains qui tremblent légèrement."
    lu "Et lui, c'est Hugo. Il ne dort plus depuis la rentrée. Il dit que ça va."
    hu "Ça va. J'ai trouvé un truc pour réviser. Je tiens dix-huit heures d'affilée."
    am "Hugo, mon chou, personne ne tient dix-huit heures d'affilée. Sauf les machines à café."
    hu "Moi si."
    $ noter("hugo_truc")
    hide lucas
    hide amelie
    with fondu

    ## La dispute qu'on reprochera à Clara.
    show clara normal at gauche with fondu
    show iris normal at droite with fondu
    narrator "À la table d'à côté, Clara a ouvert son carnet. Iris passe derrière elle, s'arrête, regarde par-dessus son épaule."
    narrator "Sur la page, un croquis des fenêtres du laboratoire de chimie, de nuit, éclairées d'un bleu étrange."
    ir "Tu as dessiné ça quand ?"
    c surprise "Hier soir. Les fenêtres étaient bleues, c'était beau, alors je…"
    ir "N'y retourne pas."
    c "Pardon ?"
    ir "N'approche pas du labo le soir. Ni demain, ni après-demain. Tu m'entends ?"
    c colere "Tu n'as pas à me dire où je peux dessiner ! Je ne te connais même pas !"
    narrator "Clara se lève si brusquement que sa chaise racle le sol. Toute la cantine se retourne."
    c "Laisse-moi tranquille !"
    hide clara with fondu
    narrator "Elle sort. Iris reste plantée là, les poings serrés, et pendant une seconde, elle a l'air sur le point de pleurer."
    $ noter("dispute_cantine")
    $ souvenir("Iris et Clara se sont disputées devant toute la cantine.", "clara colere")

    show iris normal at centre with fondu
    ir "Je m'y suis mal prise. Encore."
    ir "[joueur_nom]… Je peux avoir ton numéro ? Au cas où."
    menu:
        "Lui donner mon numéro.":
            narrator "Elle l'enregistre sans un mot, puis m'envoie un message pour que j'aie le sien : un simple point."
            $ noter("numero_iris")
            $ recevoir("Iris", ".", "Mar. 12:41")
            $ lien("iris", 1)
            ir "Merci. Garde ton téléphone allumé mercredi soir. S'il te plaît."
        "« Au cas où quoi ? »":
            ir "Au cas où j'aurais besoin de quelqu'un qui ne fait pas partie de tout ça."
            menu:
                "« D'accord. Tiens. »":
                    $ noter("numero_iris")
                    $ recevoir("Iris", ".", "Mar. 12:43")
                    $ lien("iris", 1)
                    ir "Merci. Garde ton téléphone allumé mercredi soir."
                "« Explique-moi d'abord ce qui se passe. »":
                    ir "Je ne peux pas. Pas encore. Si je t'explique trop tôt, tout recommence."
                    narrator "Elle s'en va avant que je puisse demander ce que « tout recommence » veut dire."
        "Esquiver : « Je ne donne pas mon numéro aux inconnus. »":
            ir "Tu as raison. Tu as toujours raison sur ce point."
            narrator "Elle sourit tristement et s'éloigne."
    hide iris with fondu

    ## ---------------------------------------------------------------------
    ## Clara en larmes
    ## ---------------------------------------------------------------------
    scene bg bibliotheque with fondu
    $ ambiance(None)
    $ poser_heure("MARDI · 15 H 10")
    $ musique_jouer("tristesse")

    narrator "Je retrouve Clara au fond de la bibliothèque, entre deux rayonnages d'histoire du droit. Elle a son téléphone dans la main et les yeux rouges."
    show clara triste at centre with fondu
    c "Ce n'est rien. C'est… mes parents. Ils ont appelé."
    c "Ils ont vu mes notes de lycée sur le portail de l'Académie. Mon père a dit que si je « gaspillais » mon année à dessiner, il arrêterait de payer."
    c "Et puis il y a eu cette fille, à la cantine. Tout le monde m'a regardée comme si j'étais folle."
    c "Peut-être qu'ils ont raison. Peut-être que je ne suis pas à ma place ici."

    $ reponse = saisie("Que dites-vous à Clara ?", indice="Écrivez librement, comme vous le diriez vraiment.")
    $ ton = ton_reponse(reponse)
    $ noter("reponse_clara:" + normaliser(reponse)[:40])

    if ton == "soutien":
        show clara timide
        c "…"
        c "Tu dis ça pour être gentil{g=/le}."
        moi "Non. Je le dis parce que c'est vrai."
        show clara sourire
        c "Personne ne m'avait jamais dit quelque chose comme ça. Pas avec ce regard-là."
        narrator "Elle essuie ses lunettes avec sa manche, et pour la première fois, elle rit un peu."
        $ lien("clara", 2)
        $ varier(moral=1)
        $ noter("clara_soutenue")
        $ souvenir("J'ai trouvé les mots pour consoler Clara.", "clara sourire")
    elif ton == "dur":
        show clara colere
        c "Merci. C'est exactement ce que dit mon père."
        narrator "Elle ramasse ses affaires et s'en va. Je reste seul{g=/e} entre les rayonnages, avec mes mots dans la bouche comme un goût métallique."
        $ lien("clara", -1)
        $ varier(moral=-1)
        hide clara with fondu
    else:
        show clara pensif
        c "…Merci d'être là, en tout cas. Même si je ne sais pas trop quoi répondre à ça."
        $ lien("clara", 1)

    ## ---------------------------------------------------------------------
    ## Mardi après-midi : le créneau
    ## ---------------------------------------------------------------------
    scene bg couloir with fondu
    hide clara
    $ poser_heure("MARDI · 16 H 30")
    $ musique_jouer("quotidien")
    narrator "Le bal d'automne commence à vingt heures. Le devoir surveillé, demain à dix heures. Entre les deux, quelques heures, et beaucoup trop de choses à faire."
    if rel["clara"] >= 3:
        show clara souci at centre with fondu
        c "Dis… Tu es {g=occupé/occupée}, cet après-midi ?"
        c "Je dois rendre mon portfolio vendredi. Dix dessins. J'en ai quatre qui me plaisent, et ma prof a dit que si je rate, je change de filière. Mon père serait ravi."
        c "Tu pourrais m'aider à choisir ? Juste me dire ce que tu vois, toi. Moi, je ne vois plus rien."
        hide clara with fondu
    narrator "Sur la porte de la cafétéria, l'affiche a changé : {i}« Soir de bal : service payé double ! »{/i}"
    narrator "Et dans ma tête, le sujet de demain tourne en boucle. {i}La charge de la preuve en matière pénale.{/i}"
    if energie <= 4:
        pensee "Mes yeux piquent. Si je vais au bal ce soir et au devoir demain matin sans dormir, je ne tiendrai pas."
    pensee "Clara, le devoir, l'argent, le sommeil. Il faut choisir ce que je sacrifie."

    $ choix = choisir_creneau("Mardi après-midi — 16 h 30", [
        ("reviser", "Réviser le devoir", "Les fiches, les plans, les exemples. Le devoir est demain à 10 h.", {"etudes": 1, "energie": -1}, True, "", "gui/icone_etudes.png"),
        ("portfolio", "Aider Clara", "Choisir ses dessins avec elle. Elle joue son année vendredi.", {"moral": 1, "energie": -1}, rel["clara"] >= 3, "Clara ne veut voir personne.", "medaillons/clara/souci.png"),
        ("cafeteria", "Servir à la cafétéria", "Soir de bal : on paie double. Mais on finit épuisé.", {"argent": 20, "energie": -2}, True, "", "gui/icone_argent.png"),
        ("sieste", "Faire une sieste", "Le bal finira tard. Le devoir commence tôt.", {"energie": 3}, True, "", "gui/icone_energie.png"),
    ], "Le bal ce soir, le devoir demain matin.")

    if choix == "reviser":
        narrator "Je fais trois plans de dissertation, je les rate tous, et le quatrième tient debout."
        $ revisions += 1
        $ varier(etudes=1, energie=-1)
    elif choix == "portfolio":
        scene bg chambre clara with fondu
        $ musique_jouer("clara")
        show clara sourire at centre with fondu
        narrator "On étale ses dessins sur le lit. Des toits, le port, la bibliothèque, des mains, beaucoup de mains."
        c "Celui-là, tu le gardes ? Le laboratoire bleu ?"
        moi "C'est le plus beau. Et le plus étrange."
        c pensif "Je voulais retourner le dessiner demain soir. Pour la série « Lieux de nuit ». Malgré ce qu'a dit cette fille."
        $ noter("clara_veut_labo")
        $ lien("clara", 1)
        $ varier(moral=1, energie=-1)
        hide clara with fondu
    elif choix == "cafeteria":
        scene bg cantine with fondu
        $ ambiance("salle")
        narrator "Je sers des boissons pétillantes à deux cents étudiants surexcités. On me paie quarante euros pour la soirée, puis on me dit que c'était « une erreur, c'est vingt »."
        pensee "Bienvenue dans le monde du travail."
        $ varier(argent=20, energie=-2)
    else:
        narrator "Je dors d'un sommeil sans rêve. Presque sans rêve : un chêne, une page qui tourne, une voix qui compte."
        $ varier(energie=3)

    ## ---------------------------------------------------------------------
    ## Le bal
    ## ---------------------------------------------------------------------
    $ moment = "soir"
    $ video("bal")
    scene bg bal
    show confettis_or
    with fondu_long
    $ poser_heure("MARDI · 21 H 15")
    $ musique_jouer("bal")
    $ ambiance("foule")

    narrator "La grande salle des fêtes a été transformée : des guirlandes dorées, un quatuor à cordes, des costumes partout."
    narrator "Une sorcière au chapeau pointu me bouscule en riant. Quelqu'un en armure de carton danse avec une infante espagnole."

    show clara sourire at gauche with fondu
    if rel["clara"] >= 4:
        c "Tu es venu{g=/e} ! J'ai failli ne pas venir. Puis je me suis dit : si je reste dans ma chambre, mon père gagne."
    else:
        c "Ah. Bonsoir."
    show iris normal at droite with fondu
    narrator "Plus loin, Iris, seule près d'une colonne, ne danse pas. Elle observe l'escalier qui monte vers les bureaux de la direction."

    menu:
        "Inviter Clara à danser.":
            hide iris with fondu
            show clara timide at centre
            narrator "Elle hésite, puis prend ma main. On danse mal, on se marche sur les pieds, et elle rit tellement qu'elle en pleure."
            c joie "Je ne savais pas que j'avais le droit de m'amuser ici."
            $ lien("clara", 1)
            $ varier(moral=1)
        "Rejoindre Iris près de la colonne.":
            hide clara with fondu
            show iris normal at centre
            ir "Tu ne danses pas ?"
            moi "Toi non plus."
            ir "Je surveille. Il y a des couleurs, dans cette salle, qui ne devraient pas y être."
            ir "Tu as vu les étudiants trop gais ? Les pupilles trop larges ? Ils ont pris quelque chose de bleu."
            ir "On l'appelle l'Azur. On le vend comme une aide pour réviser. C'est une couleur qui tue, [joueur_nom]."
            $ noter("piste_azur_iris")
            $ lien("iris", 1)
        "Observer la salle, de l'escalier.":
            hide clara
            hide iris
            with fondu
            narrator "Je monte quelques marches pour avoir une vue d'ensemble. D'ici, on voit tout : les danseurs, le buffet, les portes."
            narrator "Et, sur le palier de la direction, à demi dans l'ombre, deux personnes."
            show eleonore normal at centre with fondu
            narrator "Éléonore Lambert, l'assistante de la directrice. Elle tend une enveloppe épaisse à un étudiant grand et mince, en chemise sombre."
            narrator "Il la glisse dans sa veste sans l'ouvrir. Elle repart. Lui reste un moment, la tête baissée, comme quelqu'un qu'on vient de gifler."
            $ noter("vu_eleonore")
            $ souvenir("Au bal, Éléonore Lambert a remis une enveloppe à un étudiant.", "eleonore normal")
            hide eleonore with fondu
            if fait("hugo_truc"):
                pensee "Hugo et son « truc pour réviser ». Ces étudiants trop gais. Et maintenant ça."

    ## Hugo s'effondre.
    $ musique_stop(0.3)
    $ ambiance(None)
    $ son("verre")
    with flash
    scene bg bal
    with vpunch
    narrator "Un verre se brise. Puis un cri."
    narrator "Au milieu de la piste, Hugo est par terre. Il tremble. Ses yeux sont ouverts mais ne voient rien."
    $ musique_jouer("tension", 0.5)
    show lucas normal at gauche with fondu
    lu "Hugo ! HUGO ! Appelez une ambulance, vite !"
    narrator "Tout se passe très vite. Les secours, les gyrophares derrière les vitraux, la musique qui ne revient pas."
    $ noter("malaise_hugo")
    $ souvenir("Au milieu du bal, Hugo s'est effondré.")
    hide lucas with fondu

    show malo normal at centre with fondu
    $ rencontrer("malo")
    narrator "Un homme en trench-coat beige entre derrière les ambulanciers. Il ne court pas. Il regarde."
    m_inconnu "Inspecteur Deschamps. Personne ne quitte la salle avant que j'aie vu vos têtes."
    narrator "Son regard se pose sur moi, sur mon gobelet, sur mes mains."
    m "Toi. Tu étais près de lui ?"

    menu:
        "Coopérer : raconter ce que j'ai vu.":
            moi "Il est tombé d'un coup. Il était pâle depuis ce midi, il ne mangeait pas. Ses mains tremblaient."
            m pensif "Hm. Tu as de bons yeux. C'est rare, ici. Les gens de Valcourt voient surtout ce qui les arrange."
            $ lien("malo", 1)
        "Se méfier : « Je n'ai rien vu, et je n'ai rien à vous dire. »":
            m "Évidemment. Personne n'a jamais rien vu, ici."
            m "Tu es {g=nouveau/nouvelle} et tu as déjà appris la règle. Bravo, Valcourt."
            $ lien("malo", -1)
        "Parler du « truc pour réviser » de Hugo." if fait("hugo_truc"):
            moi "À midi, il disait avoir « trouvé un truc pour réviser ». Il tenait dix-huit heures sans dormir."
            m surprise "…"
            m determine "Ça a un nom, ton truc. On l'appelle l'Azur. C'est le troisième malaise en un mois, et le premier dans cette école."
            m "Si tu entends ce mot quelque part, tu m'appelles. Tiens."
            narrator "Il me tend une carte : {i}Malo Deschamps, brigade des stupéfiants, Valcourt-Centre.{/i}"
            $ lien("malo", 2)
            $ noter("piste_azur", "carte_malo")
            $ recevoir("Malo Deschamps", "Numéro enregistré. Appelle si tu entends parler d'Azur. — M.D.", "Mar. 22:40")

    m normal "Ton nom ?"
    moi "[joueur_nom]."
    m "Je retiens. Rentre dormir, [joueur_nom]. Et ne bois rien que tu n'as pas vu servir."
    $ souvenir("L'inspecteur Malo Deschamps est entré dans ma vie.", "malo normal")
    hide malo with fondu

    ## ---------------------------------------------------------------------
    ## Nuit : les appels manqués
    ## ---------------------------------------------------------------------
    scene bg chambre nuit with noir
    $ moment = "nuit"
    $ poser_heure("MARDI · 23 H 55")
    $ musique_jouer("tristesse")

    narrator "Dans ma chambre, je sors enfin mon téléphone de ma poche."
    narrator "{b}3 appels manqués — Maëlle.{/b}"
    narrator "Un message : {i}« Rappelle-moi quand tu peux. Rien de grave. Enfin si. Un peu. »{/i}"
    $ recevoir("Maëlle", "Rappelle-moi quand tu peux. Rien de grave. Enfin si. Un peu.", "Mar. 21:02")
    pensee "Le devoir est dans dix heures. Si je la rappelle maintenant, on va parler une heure. Si je ne la rappelle pas…"

    $ choix = choisir_creneau("Mardi — 23 h 55", [
        ("rappeler", "Rappeler Maëlle", "Elle a dit « un peu ». Chez Maëlle, « un peu » veut souvent dire « beaucoup ».", {"moral": 1, "energie": -1}, True, "", "medaillons/maelle/normal.png"),
        ("dormir", "Dormir", "Le devoir compte triple. Je la rappellerai demain. Promis.", {"energie": 1}, True, "", "gui/icone_energie.png"),
    ], "Trois appels manqués de Maëlle. Le devoir est dans dix heures.")

    if choix == "rappeler":
        ma "Ah, enfin. Désolée, je sais qu'il est tard."
        ma "C'est Maman. Elle a eu un vertige au travail, cette nuit. Elle est tombée dans la réserve de linge."
        ma "Elle va bien, hein. Elle s'est relevée et elle a fini sa nuit. Elle ne voulait même pas que je te le dise."
        moi "Elle doit arrêter les nuits, Maëlle."
        ma "Je sais. Elle dit qu'elle arrêtera quand tu auras ton diplôme. Alors… réussis vite, d'accord ?"
        narrator "On rit. Ça sonne un peu faux, et ça fait du bien quand même."
        $ noter("sait_vertige_maman")
        $ cocher("appeler_maelle")
        $ varier(moral=1, energie=-1)
    else:
        narrator "J'écris : {i}« Je te rappelle demain, promis. Bisous à Maman. »{/i}"
        narrator "Elle répond un cœur. Juste un cœur. Je fixe le plafond longtemps avant de m'endormir."
        $ appels_manques += 1
        $ varier(moral=-1)

    call rebond_lettre_anonyme
    scene black with noir_long
    call resume_jour("Mardi")
    $ energie = borner(energie + 5)
    jump mercredi
