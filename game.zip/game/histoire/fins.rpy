## Les six fins, leurs épilogues, le générique, et les départs de chapitre.

################################################################################
## Écran de fin et générique
################################################################################

screen carte_fin(numero, titre, phrase):
    modal True
    add Solid("#0b0907")
    add "gui/vignette.png"
    vbox at titre_apparition:
        xalign 0.5 yalign 0.45
        spacing 14
        text ("Fin %d / %d" % (numero, len(FINS))) font F_MACHINE size 22 color DOUX xalign 0.5 kerning 4
        text titre.upper() font F_TITRE size 70 color (LAITON_CLAIR if numero == 5 else PAPIER) xalign 0.5 kerning 8 text_align 0.5
        add "gui/filet.png" xalign 0.5 at filet_trace
        text phrase font F_DISPLAY_IT size 30 color "#cbbfa8" xalign 0.5 text_align 0.5 xsize 900
        null height 18
        use notes_de_fin(code_fin_courant)
    key "dismiss" action Return()

screen generique():
    modal True
    add Solid("#0b0907")
    vbox at defilement:
        xalign 0.5
        spacing 12
        null height 720
        text "VALCOURT" font F_TITRE size 70 color PAPIER xalign 0.5 kerning 12
        text "Les Sept Jours" font F_DISPLAY_IT size 36 color LAITON xalign 0.5
        null height 80
        for titre, lignes in CREDITS:
            text titre.upper() font F_TITRE size 20 color LAITON xalign 0.5 kerning 3
            for l in lignes:
                text l font F_CORPS size 20 color "#d9cdb6" xalign 0.5 text_align 0.5 xsize 1000
            null height 36
        null height 60
        text "Merci d'avoir joué." font F_DISPLAY_IT size 34 color PAPIER xalign 0.5
        text "Veritas · Justitia · Libertas" font F_TITRE_REG size 18 color DOUX xalign 0.5 kerning 4
        null height 400
    key "dismiss" action Return()
    timer 52.0 action Return()

transform defilement:
    yanchor 0.0 ypos 0
    linear 50.0 yanchor 1.0 ypos 0

label terminer(code, numero, titre, phrase):
    $ poser_heure("")
    $ debloquer_fin(code)
    $ persistent.fini_une_fois = True
    $ persistent.parties += 1
    $ retenir_deja_vu()
    window hide
    call recit_final
    scene black with fondu_long
    call screen carte_fin(numero, titre, phrase)
    $ memoriser_film(code, numero, titre, phrase)
    call screen proposer_film(code)
    $ musique_jouer("theme", 2.0)
    call screen generique
    $ renpy.full_restart()
    return

################################################################################
## Morceaux d'épilogue partagés
################################################################################

label epilogue_famille:
    if fait("bourse_suspendue") and code_fin_courant not in ("sept_jours",):
        narrator "Ma bourse n'a pas été rétablie. J'ai trouvé un emploi de nuit, au port, pour finir le semestre."
        narrator "Maman travaille toujours à la blanchisserie. On se croise au petit matin : elle rentre quand je pars, et on boit un café ensemble, debout dans la cuisine."
    elif fait("bourse_suspendue"):
        narrator "La nouvelle direction a rétabli ma bourse, « pour services rendus à la vérité ». Je dois repasser deux examens en janvier. Je les repasserai."
    if appels_manques >= 2:
        narrator "Maëlle m'a dit un jour, sans colère : « Tu as été absent{g=/e} quand on avait besoin de toi. Je sais pourquoi. Mais c'est arrivé quand même. »"
        narrator "Je pense souvent à ces appels manqués."
    elif fait("aide_maman"):
        narrator "Maman a gardé le ticket de pharmacie des vingt euros. Elle l'a punaisé sur le frigo, à côté de ma lettre d'admission."
    return

################################################################################
## Fin 1 — Erreur judiciaire
################################################################################

label fin_erreur:
    $ code_fin_courant = "erreur"
    scene bg parloir with noir_long
    $ musique_jouer("tristesse")
    narrator "Clara a été renvoyée devant la cour d'assises. Le procès aura lieu au printemps."
    narrator "Dorian continue de la défendre. Il dit qu'il y a encore une chance. Il le dit trop souvent pour y croire."
    narrator "Éléonore Lambert a démissionné en novembre, « pour raisons personnelles ». Personne n'a fait le lien."
    if niveau("clara") >= 6:
        narrator "Chaque semaine, je vais au parloir. On ne parle pas du procès. On parle de couleurs, de la lumière sur le port, des films qu'on regardera après."
    else:
        narrator "Je vais au parloir, parfois. Elle m'accueille poliment, comme on accueille quelqu'un qui a essayé."
    call epilogue_famille
    narrator "En décembre, je reçois une lettre. Une seule phrase, d'une écriture ronde :"
    narrator "{i}« Je dessine encore. Les murs, surtout. »{/i}"
    call terminer("erreur", 1, "Erreur judiciaire", "Une vérité incomplète est un mensonge qui a bien réussi.")
    return

################################################################################
## Fin 2 — Le Silence de Valcourt
################################################################################

label fin_silence:
    $ code_fin_courant = "silence"
    scene bg bureau directrice with noir_long
    $ musique_jouer("mystere")
    narrator "Je pose la clé USB sur le bureau d'Isabella Varga. Elle la fait disparaître dans un tiroir sans la regarder."
    narrator "Samedi, à l'audience, Éléonore Lambert ne vient pas témoigner. Un « vice de procédure » est découvert. Clara est libérée."
    narrator "Iris Delaunay est morte d'une chute accidentelle, dit le rapport final. Le laboratoire rouvre lundi."
    scene bg academie with fondu
    show clara triste at centre with fondu
    c "Je suis libre. Dorian dit que c'est grâce à toi."
    c "Alors pourquoi tu ne me regardes pas ?"
    narrator "Je ne réponds pas. Elle comprend. Elle comprend toujours tout, Clara, c'est son malheur."
    c "Iris n'a pas glissé. Tu le sais. Et tu les as laissés le dire."
    hide clara with fondu
    narrator "Elle a changé d'étage au deuxième semestre. On se croise dans les couloirs. Elle ne fait plus tomber ses crayons."
    narrator "Maman a arrêté les nuits en janvier. « Une aide de l'Académie », lui a-t-on écrit. Elle m'a appelé{g=/e} en pleurant de joie."
    narrator "Je n'ai pas pleuré avec elle."
    scene bg port nuit with fondu
    $ ambiance("port")
    narrator "Le jeudi suivant, je suis allé{g=/e} au port, sans savoir pourquoi."
    narrator "Au quai 7, un bateau bleu appareillait."
    $ ambiance(None)
    call terminer("silence", 2, "Le Silence de Valcourt", "Vous avez sauvé Clara. Vous avez vendu Iris.")
    return

################################################################################
## Fin 3 — Le Mauvais Coupable
################################################################################

label fin_mauvais_coupable:
    $ code_fin_courant = "mauvais"
    if possede("marque_page") and pages > 0 and not fait("livre_propose_mauvais"):
        $ noter("livre_propose_mauvais")
        $ fin_en_attente = "mauvais_epilogue"
        jump le_livre
    jump fin_mauvais_epilogue

label fin_mauvais_epilogue:
    $ code_fin_courant = "mauvais"
    scene bg academie with noir_long
    $ musique_jouer("tristesse")
    narrator "Clara est sortie le jour même. Elle m'a serré{g=/e} dans ses bras si fort que mes côtes s'en souviennent encore."
    narrator "Dorian Varga a été mis en examen. Il n'a jamais dit pourquoi il cherchait Iris ce soir-là. Il a démissionné de l'Académie pour ne pas « salir sa sœur »."
    narrator "Isabella Varga n'a plus prononcé mon nom."
    call epilogue_famille
    scene bg cantine with fondu
    show lucas normal at centre with fondu
    narrator "Trois semaines plus tard, à la cantine, Lucas pose son plateau en face de moi. Il est livide."
    lu "Un gars de première année. Hier soir. Il est tombé dans l'escalier de la résidence, les yeux grands ouverts."
    lu "Ils ont trouvé des pastilles bleues dans sa poche."
    hide lucas with fondu
    pensee "L'Azur circule toujours. Et quelque part, quelqu'un qui « a les clés de tout » sourit."
    call terminer("mauvais", 3, "Le Mauvais Coupable", "Accuser n'est pas comprendre.")
    return

################################################################################
## Fin 4 — Veritas (au tribunal, ou l'aube incertaine)
################################################################################

label fin_veritas_tribunal:
    $ code_fin_courant = "veritas"
    $ musique_jouer("espoir")
    scene bg tribunal juge with fondu
    ju "La cour constate que les charges retenues contre Mademoiselle Clara Morel ne sont pas fondées. Elle est libre."
    ju "La cour ordonne que Mademoiselle Éléonore Lambert soit entendue sur-le-champ par les services de police."
    $ son("marteau")
    scene bg tribunal temoin with fondu
    show eleonore triste at centre with fondu
    el "Vous ne savez pas ce qu'ils m'auraient fait. Ces gens du port. Je n'avais pas le choix."
    el "Elle n'aurait pas dû tomber. Je voulais seulement la clé. Seulement la clé…"
    hide eleonore with fondu
    narrator "Malo lui passe les menottes, doucement, presque avec respect. La salle se tait."
    if possede("marque_page") and pages > 0 and not fait("livre_propose_veritas"):
        $ noter("livre_propose_veritas")
        $ fin_en_attente = "veritas_epilogue"
        jump le_livre
    jump fin_veritas_epilogue

label fin_veritas_epilogue:
    $ code_fin_courant = "veritas"
    scene bg academie with noir_long
    $ musique_jouer("espoir")
    show clara sourire at centre with fondu
    narrator "Clara sort du palais de justice sous un ciel lavé par la pluie. Elle cligne des yeux comme quelqu'un qui découvre la lumière."
    if niveau("clara") >= 7:
        c joie "Tu as tenu ta promesse. Même quand je t'ai dit de ne pas promettre."
        narrator "Elle me tend son carnet. Sur la première page, un portrait de moi à la table de la défense, les mains crispées sur le dossier."
        c "Je l'ai dessiné de mémoire, en cellule. Pour ne pas oublier qu'il y avait quelqu'un."
    elif niveau("clara") >= 4:
        c "Merci. Je ne sais pas comment on remercie quelqu'un pour ça."
        moi "Tu dessines. C'est déjà beaucoup."
    else:
        c "Dorian m'a dit ce que tu as fait. Merci."
        narrator "Elle me serre la main, gauchement. On ne se connaît pas assez pour plus. Pas encore."
    hide clara with fondu
    narrator "Le quai 7 a été fouillé la semaine suivante. Nathan Roussel a tout raconté."
    if fait("isabella_accusee"):
        narrator "Isabella Varga a été mise en examen sur la seule parole d'Éléonore. Il a fallu huit mois pour prouver qu'elle n'avait rien su du trafic. Elle n'est jamais revenue à Valcourt."
        pensee "J'ai laissé une coupable entraîner une innocente dans sa chute. Je ne l'oublierai pas."
    elif fait("doute_isabella"):
        narrator "Isabella Varga a démissionné en décembre. Le doute qu'Éléonore avait semé ne l'a jamais tout à fait quittée."
    else:
        narrator "Isabella Varga a démissionné en décembre. Avant de partir, elle m'a envoyé un mot : « Merci de m'avoir empêchée de protéger la mauvaise personne. »"
    call epilogue_famille
    scene bg reserve with fondu
    $ musique_jouer("tristesse")
    narrator "Sur l'étagère de la réserve, il y a désormais une place vide entre deux encyclopédies."
    narrator "Je pense à Iris chaque fois que je passe devant. Elle avait raison : la vérité a éclaté. Elle est juste arrivée trop tard pour elle."
    call terminer("veritas", 4, "Veritas", "La vérité éclate. Elle a coûté une vie.")
    return

label fin_veritas_aube:
    $ code_fin_courant = "veritas"
    scene bg academie nuit with noir_long
    show pluie_fine
    $ musique_jouer("espoir")
    narrator "Iris est vivante. Une épaule démise, un bleu sur la joue. Vivante."
    if fait("malo_prevenu"):
        narrator "Éléonore Lambert a été arrêtée deux jours plus tard à la gare, un billet pour l'étranger dans la poche. Mais au quai 7, le bateau bleu est parti avant la police."
    else:
        narrator "Éléonore Lambert a disparu cette nuit-là. On ne l'a jamais retrouvée. Au quai 7, le hangar était vide le lendemain."
    show iris normal at centre with fondu
    ir "On a gagné une manche. Pas la partie."
    ir "Mais je suis là. Et jeudi est arrivé. Tu sais depuis combien de temps je n'avais pas vu un jeudi ?"
    hide iris with fondu
    call epilogue_famille
    narrator "L'Azur circule moins. Il circule encore. Iris écrit son article. Clara dessine l'aube depuis la fenêtre de sa chambre."
    call terminer("veritas", 4, "Veritas — l'aube incertaine", "Iris est sauvée. Le réseau, lui, a survécu.")
    return

################################################################################
## Fin 5 — Les Sept Jours (vraie fin)
################################################################################

label fin_sept_jours:
    ## Depuis l'Acte II, sauver Iris n'est plus une fin : c'est le début.
    ## La Fin 5 se débloque quand même (galerie, chapitres), puis l'histoire continue.
    $ code_fin_courant = "sept_jours"
    $ debloquer_fin("sept_jours")
    $ persistent.fini_une_fois = True
    $ retenir_deja_vu()
    $ video("aube")
    scene bg academie with fondu_long
    show poussiere
    $ musique_jouer("espoir")
    $ poser_heure("JEUDI · 06 H 50")
    narrator "Jeudi. Un vrai jeudi."
    narrator "La pluie s'est arrêtée dans la nuit. L'Académie brille comme si on l'avait repeinte."
    narrator "Éléonore Lambert a passé la nuit en garde à vue. Nathan Roussel aussi. On dit qu'il a parlé jusqu'à l'aube."
    if possede("marque_page"):
        narrator "Le marque-page, dans ma poche, est tiède. Pas brûlant : tiède, comme une main qui vient de lâcher la mienne."
    $ souvenir("Jeudi est arrivé. Iris est vivante.", "iris normal")
    window hide
    $ poser_heure("")
    $ musique_jouer("theme", 2.0)
    call screen carte_acte(1, "Les Sept Jours", "Iris est vivante. Le temps reprend sa course.", "ACTE II", "Le Capitaine")
    jump acte2

################################################################################
## Fin 6 — La Page blanche
################################################################################

default nom_ecrit = ""
default code_fin_courant = ""

label fin_page_blanche:
    $ code_fin_courant = "page_blanche"
    $ musique_jouer("boucle")
    scene bg reserve with noir_long
    show grain
    show halo_or
    if nom_ecrit:
        narrator "J'écris : {i}« [nom_ecrit] »{/i}."
        narrator "Ce n'est pas mon nom. Les lettres frémissent, puis s'enfoncent dans le papier comme dans de l'eau."
    narrator "Mercredi. Sept heures trente. Le plafond, le port, le café tiède."
    narrator "Mercredi. Sept heures trente. Le plafond, le port, le café tiède."
    narrator "Mercredi. Sept heures trente…"
    narrator "Je ne sais plus combien de fois. Je ne sais plus qui j'ai essayé de sauver, ni pourquoi."
    narrator "Clara me croise dans le couloir sans me reconnaître. Iris aussi. Maëlle ne m'appelle plus : il n'y a plus personne à ce numéro."
    narrator "Dans la réserve de la bibliothèque, sur une page du Livre, un nom s'efface lentement."
    narrator "Le mien."
    call terminer("page_blanche", 6, "La Page blanche", "On ne revient pas indéfiniment. On finit par ne plus être là.")
    return

################################################################################
## Départs de chapitre (Extras, après une première fin)
################################################################################

label depart_lundi:
    $ quick_menu = True
    jump lundi

label depart_mercredi:
    $ quick_menu = True
    $ noter("marque_page", "numero_iris", "piste_azur", "devise_connue")
    $ donner("marque_page", silencieux=True)
    $ rencontrer("clara", "iris", "dorian", "isabella", "eleonore", "malo", "maelle", "amelie", "lucas", "hugo")
    $ revisions = 1
    jump mercredi

label depart_enquete:
    $ quick_menu = True
    $ noter("marque_page", "numero_iris", "piste_azur", "devise_connue", "message_recu", "drame", "couru_labo", "vu_ombre")
    $ donner("marque_page", silencieux=True)
    $ rencontrer("clara", "iris", "dorian", "isabella", "eleonore", "malo", "maelle", "amelie", "lucas", "hugo")
    $ note_ds = 11
    jump jeudi

label depart_audience:
    $ quick_menu = True
    $ noter("marque_page", "numero_iris", "piste_azur", "devise_connue", "message_recu", "drame", "plaidoirie_prete")
    $ donner("marque_page", silencieux=True)
    $ rencontrer("clara", "iris", "dorian", "isabella", "eleonore", "malo", "maelle", "amelie", "lucas", "hugo", "nathan", "bernier")
    python:
        for _p in ("carnet", "rapport", "message", "badges", "epingle", "agenda"):
            obtenir(_p, silencieux=True)
    jump samedi_matin

label depart_boucle:
    $ quick_menu = True
    $ noter("marque_page", "lettre_iris", "legende_livre", "livre_trouve", "quai7_tot")
    $ donner("marque_page", silencieux=True)
    $ donner("lettre_iris", silencieux=True)
    $ rencontrer("clara", "iris", "dorian", "isabella", "eleonore", "malo", "maelle", "amelie", "lucas", "hugo", "nathan", "bernier")
    $ rel["clara"] = 6
    $ rel["malo"] = 4
    $ pages = 2
    $ boucle = 2
    jump mercredi_boucle
