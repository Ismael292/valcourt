## Jour 3 — Mercredi : la nuit du laboratoire (première fois).

label mercredi:
    $ chapitre = "mercredi"
    $ jour = 3
    $ moment = "matin"
    $ cafes_du_jour = 0
    call titre(3, "Mercredi", "15 octobre", "La nuit du laboratoire")
    $ debut_jour_etat = instantane()

    scene bg chambre with fondu
    $ poser_heure("MERCREDI · 07 H 30")
    $ musique_jouer("quotidien")
    narrator "Le devoir est à dix heures. Il me reste deux heures et demie, un estomac noué et un café qui refroidit."
    narrator "Sur mes fiches, des flèches, des ratures, et trois mots soulignés deux fois : {i}présomption d'innocence{/i}."
    if fait("numero_iris"):
        call sms("Iris", [("iris", "Je suis à la bibliothèque, au fond. Si tu as cinq minutes avant ton devoir… il faut que je te parle de ce soir.")], "Mercredi, 07:31")
        $ recevoir("Iris", "Je suis à la bibliothèque, au fond. Il faut que je te parle de ce soir.", "Mer. 07:31")
    else:
        narrator "Par la fenêtre, je vois Iris traverser la cour vers la bibliothèque, un dossier serré contre elle. Elle a l'air de ne pas avoir dormi."
    if energie <= 4:
        pensee "Je suis {g=épuisé/épuisée}. Si je m'endors pendant le devoir, tout est fini."
    pensee "Réviser encore, écouter Iris, ou dormir. Le devoir compte triple, mais Iris avait peur."

    $ choix = choisir_creneau("Mercredi — 7 h 30", [
        ("reviser", "Dernière révision", "Relire les fiches une dernière fois. Chaque point peut sauver ma moyenne.", {"etudes": 1, "energie": -1}, True, "", "gui/icone_etudes.png"),
        ("iris", "Rejoindre Iris", "Elle veut me parler de « ce soir ». Elle n'a pas l'air de plaisanter.", {"energie": -1}, True, "", "medaillons/iris/normal.png"),
        ("dormir", "Dormir encore", "Arriver {g=reposé/reposée} vaut peut-être mieux qu'une fiche de plus.", {"energie": 2}, True, "", "gui/icone_energie.png"),
    ], "Le devoir commence à dix heures.")

    if choix == "reviser":
        narrator "Je relis les fiches jusqu'à pouvoir les réciter les yeux fermés."
        $ revisions += 1
        $ varier(etudes=1, energie=-1)
    elif choix == "iris":
        call mercredi_matin_iris
    else:
        narrator "Je m'accorde une heure de plus. Mon corps me remercie. Ma conscience, beaucoup moins."
        $ varier(energie=2)

    ## ---------------------------------------------------------------------
    ## Le devoir surveillé
    ## ---------------------------------------------------------------------
    scene bg classe with fondu
    $ poser_heure("MERCREDI · 10 H 00")
    $ musique_jouer("tension")
    narrator "Soixante étudiants, soixante copies, une horloge qui fait un bruit de pas."
    narrator "Le sujet tient en une ligne : {i}« La charge de la preuve en matière pénale. »{/i}"
    narrator "Avant la dissertation, une question préliminaire :"

    menu:
        "{i}En matière pénale, à qui revient-il de prouver la culpabilité ?{/i}"
        "À l'accusation, c'est-à-dire au ministère public.":
            $ bonne_reponse = True
        "À la personne poursuivie, qui doit prouver son innocence.":
            $ bonne_reponse = False
        "Au juge, qui cherche seul la vérité.":
            $ bonne_reponse = False

    narrator "J'écris pendant trois heures. Ma main me fait mal. Quand le surveillant ramasse les copies, je ne sais plus si j'ai écrit un chef-d'œuvre ou une catastrophe."

    python:
        note_ds = 6 + 3 * revisions
        if energie >= 5:
            note_ds += 2
        if energie <= 2:
            note_ds -= 2
        if filiere == "droit":
            note_ds += 2
        if bonne_reponse:
            note_ds += 2
        note_ds = max(3, min(19, note_ds))
    $ cocher("ds")
    narrator "Les notes tombent le soir même, sur le portail de l'Académie. Celle de Dorian Varga ne tremble jamais."
    narrator "{b}Devoir surveillé de méthodologie : [note_ds]/20.{/b}"
    $ souvenir("Devoir surveillé de méthodologie : %d/20." % note_ds)
    if note_ds >= 12:
        pensee "[note_ds]. Je relis trois fois. Je n'ose pas y croire."
        $ varier(etudes=1, moral=1)
    elif note_ds <= 8:
        pensee "[note_ds]. Coefficient trois. Ma moyenne s'effondre comme un château de cartes."
        $ varier(etudes=-2, moral=-1)
    else:
        pensee "[note_ds]. Ni bon, ni mauvais. Juste assez pour que l'angoisse ne parte pas."

    ## ---------------------------------------------------------------------
    ## Midi : Iris, puis Clara
    ## ---------------------------------------------------------------------
    scene bg academie with fondu
    $ moment = "après-midi"
    $ poser_heure("MERCREDI · 13 H 20")
    $ musique_jouer("mystere")

    if not fait("parle_iris_mercredi"):
        show iris normal at centre with fondu
        narrator "Dans la cour, Iris passe près de moi sans s'arrêter. Juste le temps de murmurer :"
        ir "Ce soir, je publie. Après, tout ira bien. Ou rien n'ira plus."
        if fait("marque_page"):
            ir "Tu l'as toujours ? Le marque-page ?"
            moi "Dans mon carnet."
            ir "Bien. Ne le laisse jamais dans ta chambre."
        hide iris with fondu

    show clara determine at centre with fondu
    c "Tu sais quoi ? J'y vais quand même. Ce soir, vers vingt et une heures."
    moi "Au laboratoire ? Iris t'a dit de ne pas y aller."
    c "Iris ne m'a rien dit, elle m'a donné un ordre. Ce n'est pas pareil."
    c sourire "Et puis je ne rentre pas, hein. Je dessine depuis la cour, par les grandes fenêtres. La lumière y est magnifique la nuit."
    c "C'est pour ma série « Lieux de nuit ». C'est la dernière qu'il me manque."
    if rel["clara"] >= 5 and empathie_possible():
        menu:
            "« Clara, s'il te plaît. Pas ce soir. »":
                show clara pensif
                c "…Tu as l'air vraiment inquiet{g=/e}."
                c "D'accord. Juste une demi-heure, alors. Et je rentre avant dix heures. Promis."
                $ noter("clara_promet_tot")
            "« D'accord. Fais attention à toi. »":
                c "Toujours."
    hide clara with fondu

    ## ---------------------------------------------------------------------
    ## Mercredi soir : le créneau qui change tout
    ## ---------------------------------------------------------------------
    scene bg couloir with fondu
    $ moment = "soir"
    $ poser_heure("MERCREDI · 18 H 00")
    narrator "Sur le panneau d'affichage : {i}« Réception des donateurs, 19 h – 22 h, salons de la direction. On recherche des étudiants pour le service : 25 € la soirée. »{/i}"
    narrator "Sous l'affiche, un courriel de Dorian Varga, punaisé par un étudiant moqueur : {i}« Oral de vendredi, 9 h. Aucune excuse ne sera acceptée. »{/i}"
    show clara determine at centre with fondu
    c "Ah, te voilà ! Je pars dessiner le laboratoire vers vingt et une heures. Depuis la cour, promis, je ne rentre pas."
    c sourire "Tu viens ? On pourrait faire semblant d'être deux artistes maudits sous la lune."
    hide clara with fondu
    if fait("parle_iris_mercredi") or fait("piste_azur_iris") or fait("dispute_cantine"):
        pensee "Iris a dit à Clara de ne pas approcher du laboratoire le soir. Et Iris a dit « ce soir »."
    if argent < 20:
        pensee "Il me reste [argent] euros pour toute la semaine. Vingt-cinq de plus, ce ne serait pas du luxe."
    pensee "Clara au laboratoire, l'oral de vendredi, la réception. Trois endroits où il faudrait être."

    $ choix = choisir_creneau("Mercredi soir — 18 h", [
        ("clara", "Accompagner Clara", "Dessiner avec elle dans la cour du laboratoire, vers 21 h. Iris ne voulait pas qu'elle y aille.", {"moral": 1, "energie": -1}, True, "", "medaillons/clara/determine.png"),
        ("oral", "Préparer l'oral", "Vendredi, 9 h. Dorian ne fait d'exception ni pour les malades, ni pour les héros.", {"etudes": 1, "energie": -1}, True, "", "medaillons/dorian/normal.png"),
        ("reception", "Servir à la réception", "La directrice, son assistante, les donateurs… et 25 € la soirée.", {"argent": 25, "energie": -2}, True, "", "medaillons/isabella/normal.png"),
    ], "Une soirée. Trois endroits où il faudrait être.")

    if choix == "clara":
        call mercredi_soir_clara
    elif choix == "oral":
        scene bg chambre with fondu
        $ musique_jouer("quotidien")
        narrator "Je prépare mon plan d'oral. Dorian nous a envoyé les sujets : le mien est {i}« Peut-on condamner sur un seul témoignage ? »{/i}"
        narrator "J'écris : {i}« Un témoin voit ce qu'il croit voir. Un juge doit voir ce qui est. »{/i} Je trouve ça bien. Je le raye. Je le réécris."
        $ noter("oral_prepare")
        $ varier(etudes=1, energie=-1)
    else:
        call mercredi_soir_reception

    ## ---------------------------------------------------------------------
    ## 22 h 12
    ## ---------------------------------------------------------------------
    scene bg chambre nuit with fondu
    $ moment = "nuit"
    $ poser_heure("MERCREDI · 22 H 12")
    $ ambiance("pluie")
    show pluie_fine
    $ musique_jouer("nuit")

    if fait("numero_iris"):
        $ son("vibreur")
        narrator "Mon téléphone vibre. Un message. Iris."
        call sms("Iris", [("iris", "Elle a les clés de tout."), ("iris", "Viens au labo. Pas la police."), ("iris", "S'il te plaît.")], "Mercredi, 22:12")
        $ recevoir("Iris", "Elle a les clés de tout. Viens au labo. Pas la police. S'il te plaît.", "Mer. 22:12")
        $ noter("message_recu")
        pensee "« Elle ». Qui, elle ? Et pourquoi « pas la police » ?"
        menu:
            "Courir au laboratoire, tout de suite.":
                $ noter("couru_labo")
            "Appeler Malo d'abord." if fait("carte_malo"):
                $ noter("appele_malo")
                narrator "Malo décroche à la deuxième sonnerie. Je lui lis le message."
                m "J'arrive. Tu ne bouges pas. Tu m'entends ? Tu ne bouges pas."
                $ lien("malo", 1)
            "Appeler la police (le 17)." if not fait("carte_malo"):
                $ noter("appele_police")
                narrator "Une voix fatiguée prend mon nom, me demande si c'est une plaisanterie d'étudiant, promet « d'envoyer une patrouille quand une voiture sera libre »."
    else:
        narrator "Je n'arrive pas à dormir. La pluie tape contre la vitre comme quelqu'un qui voudrait entrer."

    if fait("couru_labo"):
        call mercredi_course_labo
    else:
        scene bg chambre nuit
        $ poser_heure("MERCREDI · 23 H 02")
        narrator "À vingt-trois heures deux, l'alarme incendie de la résidence se déclenche."
        narrator "Dans le couloir, des étudiants en pyjama, des portes qui claquent. Quelqu'un crie : « C'est au labo ! Il y a la police au labo ! »"
        $ son("sirene")

    ## ---------------------------------------------------------------------
    ## Le drame
    ## ---------------------------------------------------------------------
    $ video("drame")
    scene bg labo nuit
    show gyrophares
    show pluie
    show grain
    with fondu
    $ ambiance("pluie")
    $ ambiance("sirenes", canal="ambiance2")
    $ poser_heure("MERCREDI · 23 H 20")
    $ musique_jouer("tristesse")
    $ noter("drame")

    narrator "Le ruban jaune barre la porte du laboratoire. Derrière, les lumières blanches de la police scientifique."
    narrator "Sur le carrelage, près de la paillasse du fond, quelqu'un a tracé un contour à la craie."
    narrator "Iris Delaunay est morte."
    $ souvenir("Mercredi, 22 h 40. Iris Delaunay est morte.")
    pensee "Hier, elle me demandait mon numéro. Ce matin, elle me disait : « Après, tout ira bien. »"

    show malo determine at centre with fondu
    m "Personne ne passe le ruban."
    if fait("couru_labo") or fait("appele_malo"):
        m "Toi. C'est toi qui as… Oui. Évidemment que c'est toi."
    m "Chute contre l'angle de la paillasse, aux alentours de vingt-deux heures quarante. Il y a eu une dispute. Peut-être plus."
    m "Et on a trouvé ça, à côté d'elle."
    narrator "Il lève un sachet plastique transparent. À l'intérieur, un carnet d'aquarelle à la couverture brune."
    narrator "Je le reconnais avant même de voir le nom écrit sur la tranche."
    pensee "Clara."
    hide malo with fondu

    show clara peur at centre with fondu
    $ musique_jouer("tristesse")
    narrator "Deux agents la font sortir de la résidence, sous la pluie, en pyjama, un manteau jeté sur les épaules."
    narrator "Elle me voit. Elle s'arrête une seconde, malgré la main de l'agent sur son bras."
    c triste "[joueur_nom]… Je n'ai rien fait. Je te jure que je n'ai rien fait."
    c "J'avais oublié mon carnet dans la cour, il pleuvait, je suis rentrée en courant, je…"
    agent "Avancez, mademoiselle."
    $ souvenir("Sous la pluie, on a emmené Clara. « Je n'ai rien fait. »", "clara peur")
    hide clara with fondu
    narrator "La portière de la voiture claque. Les gyrophares s'éloignent et emportent la couleur avec eux."

    if fait("temoin_cour"):
        pensee "Dans la cour. Pas dans le laboratoire. J'y étais. J'ai vu le carnet sur le banc quand on est {g=parti/partis}."

    scene black with noir_long
    $ ambiance(None)
    $ ambiance(None, canal="ambiance2")
    narrator "Je ne dors pas, cette nuit-là."
    $ varier(energie=-2, moral=-2)
    call resume_jour("Mercredi")
    jump jeudi


## ---------------------------------------------------------------------------
## Variantes du mercredi
## ---------------------------------------------------------------------------

label mercredi_matin_iris:
    scene bg bibliotheque with fondu
    $ musique_jouer("boucle")
    show iris normal at centre with fondu
    $ noter("parle_iris_mercredi")
    ir "Tu me cherchais. Ça aussi, c'est nouveau."
    moi "Iris, qu'est-ce qui se passe ce soir ?"
    ir "Ce soir, je publie un article. Sur l'Azur. Sur qui le fabrique, et où, et avec quelles clés."
    ir "J'ai tout. Les dates, les sommes, les initiales. Tout est rangé dans un endroit que personne ne pense à ouvrir."
    if fait("marque_page"):
        ir "Si jamais… si jamais ça tourne mal, ton marque-page t'indiquera où chercher. Il connaît le chemin."
        moi "Un marque-page qui connaît le chemin ?"
        ir "Je sais comment ça sonne. Garde-le sur toi. C'est tout ce que je te demande."
    ir "Et si tu revois Clara, dis-lui que je suis désolée pour hier. Je voulais seulement qu'elle ne soit pas là ce soir."
    $ lien("iris", 1)
    $ varier(energie=-1)
    hide iris with fondu
    return

label mercredi_soir_clara:
    scene bg academie nuit with fondu
    $ poser_heure("MERCREDI · 21 H 05")
    $ musique_jouer("clara")
    $ noter("temoin_cour")
    show clara sourire at gauche with fondu
    narrator "La cour des sciences est déserte. Derrière les grandes fenêtres, le laboratoire baigne dans une lumière bleutée."
    narrator "Clara s'installe sur un banc, ouvre son carnet, et dessine en silence. Elle note l'heure de l'horloge du labo, comme toujours : {i}21 h 30{/i}."
    c "Tu vois cette lumière ? Ce n'est pas l'éclairage normal. Quelqu'un a laissé une lampe allumée au fond."
    narrator "Une silhouette passe derrière les vitres. Floue, rapide. Clara la croque en trois traits sans même y penser."
    c pensif "Il y a quelqu'un. Tant pis, c'est joli, un personnage."
    $ son("tonnerre")
    show pluie
    with flash
    narrator "Le ciel se déchire d'un coup. Une pluie violente, glacée."
    c surprise "Mes dessins ! Viens, vite !"
    narrator "On court jusqu'à la résidence en riant, trempés. Ce n'est qu'en haut de l'escalier que Clara pousse un petit cri."
    c souci "Mon carnet… Je l'ai laissé sur le banc."
    moi "On y retourne ?"
    c "Non, il pleut trop. Je le récupérerai demain matin. Il est sous l'auvent, il ne risque rien."
    narrator "Il est vingt et une heures quarante-cinq. Elle rentre dans sa chambre. Je l'entends fermer sa porte à clé."
    pensee "Elle était dans sa chambre à vingt et une heures quarante-cinq. J'en suis témoin."
    $ lien("clara", 1)
    $ varier(moral=1, energie=-1)
    hide clara with fondu
    hide pluie
    return

label mercredi_soir_reception:
    scene bg bureau directrice with fondu
    $ poser_heure("MERCREDI · 19 H 10")
    $ musique_jouer("mystere")
    $ ambiance("foule")
    $ noter("reception_servie")
    narrator "Les salons de la direction brillent de lustres et de bijoux. Je circule avec un plateau de coupes, invisible."
    show isabella sourire at gauche with fondu
    narrator "Isabella Varga serre des mains, rit au bon moment, retient chaque prénom."
    show dorian normal at droite with fondu
    narrator "Dorian, lui, se tient près de la fenêtre, un verre intact à la main. Il regarde sa sœur comme on regarde un incendie."
    $ poser_heure("MERCREDI · 21 H 30")
    narrator "À vingt et une heures trente, il pose son verre et s'en va sans saluer personne. Isabella le suit des yeux, puis reprend son sourire."
    $ noter("vu_dorian_part")
    hide dorian with fondu
    show eleonore normal at droite with fondu
    narrator "Éléonore Lambert ne quitte pas sa patronne d'une semelle. Carnet, téléphone, clés : tout passe par elle."
    $ poser_heure("MERCREDI · 22 H 00")
    isa "Mes amis, merci. La soirée est terminée, mais Valcourt, elle, ne s'arrête jamais."
    narrator "Les invités s'en vont. À vingt-deux heures cinq, Éléonore regarde son téléphone, pâlit légèrement, et sort par l'escalier de service."
    narrator "Pas par l'escalier d'honneur. Celui qui descend vers l'aile des sciences."
    $ noter("vu_eleonore_part", "reception_finie_22h")
    hide eleonore
    hide isabella
    with fondu
    $ ambiance(None)
    $ varier(argent=25, energie=-2)
    return

label mercredi_course_labo:
    scene bg academie nuit
    show pluie
    with fondu
    $ poser_heure("MERCREDI · 22 H 31")
    $ musique_jouer("tension", 0.5)
    narrator "Je cours sous la pluie. La cour, les arcades, l'aile des sciences."
    if fait("reception_servie"):
        narrator "J'ai perdu dix minutes à rendre mon plateau et mon tablier. Dix minutes que je ne rattraperai jamais."
    narrator "La porte principale du laboratoire est verrouillée. Je fais le tour du bâtiment, je glisse, je me relève."
    $ poser_heure("MERCREDI · 22 H 48")
    scene bg couloir nuit with fondu
    show neon_gresille
    narrator "La porte latérale est entrouverte. Dans le couloir, un néon grésille."
    $ son("pas_course")
    show ombre_fuite
    narrator "Au bout du couloir, une silhouette s'enfuit par l'escalier de service. Petite. Un dossier serré contre la poitrine."
    $ noter("vu_ombre")
    moi "Hé ! Attendez !"
    narrator "La porte de l'escalier claque. Quand j'y arrive, il n'y a plus personne. Seulement une odeur légère, sucrée. De la violette."
    $ noter("odeur_violette")
    scene bg labo nuit with fondu
    narrator "Le laboratoire. La lumière bleue au fond. Et, par terre, près de la dernière paillasse…"
    $ son("coeur")
    with flash_rouge
    narrator "Iris."
    narrator "Elle ne bouge pas. Je m'agenouille, je l'appelle, je ne sais plus ce que je dis."
    narrator "Près de sa main, un carnet d'aquarelle à la couverture brune."
    $ son("sirene")
    narrator "Puis les sirènes. Les lampes torches. Quelqu'un me tire en arrière."
    return
