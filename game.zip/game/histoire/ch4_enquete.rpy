## Jours 4 et 5 — Jeudi et vendredi : l'enquête.
##
## Sept créneaux, de jeudi après-midi à vendredi nuit. Chaque créneau se joue
## sur la carte : un lieu = une action. Les créneaux de journée sont des heures
## de cours (un cours manqué fait baisser la moyenne) ; les créneaux de nuit
## sont des heures de sommeil (ne pas dormir coûte cher le lendemain).

define CRENEAUX = [
    (4, "après-midi", "JEUDI · 14 H 00"),
    (4, "soir", "JEUDI · 19 H 00"),
    (4, "nuit", "JEUDI · 23 H 00"),
    (5, "matin", "VENDREDI · 09 H 00"),
    (5, "après-midi", "VENDREDI · 14 H 00"),
    (5, "soir", "VENDREDI · 20 H 30"),
    (5, "nuit", "VENDREDI · 23 H 30"),
]

default creneau_idx = 0
default dormi_cette_nuit = False

init python:

    def lieux_disponibles():
        """Construit la carte du créneau courant : (code, nom, vignette, note, disponible)."""
        j, mo = store.jour, store.moment
        jour_ouvre = mo in ("matin", "après-midi")
        L = []

        if jour_ouvre:
            L.append(("cours", "Aller en cours", "images/bg/bg classe.jpg",
                      "La moyenne tient à ça. Et Dorian le saura.", True))
        if j == 5 and mo == "matin":
            L.append(("oral", "Oral de Dorian", "images/bg/bg amphi.jpg",
                      "Neuf heures. Pas d'exception.", True))

        parloir_ok = mo == "après-midi" and possede("badge_visiteur")
        L.append(("parloir", "Parloir — Clara", "images/bg/bg parloir.jpg",
                  "Visites de 14 h à 17 h." if parloir_ok else "Visites l'après-midi seulement.", parloir_ok))

        L.append(("labo", "Laboratoire", "images/bg/bg labo.jpg",
                  "Sous scellés. Mais les scellés, ça se négocie." if mo != "nuit" else "La nuit, personne ne surveille.", True))

        biblio_ok = mo != "nuit" or possede("marque_page")
        L.append(("bibliotheque", "Bibliothèque", "images/bg/bg bibliotheque.jpg",
                  "Mme Bernier et la réserve." if mo != "nuit" else ("Le marque-page est tiède…" if biblio_ok else "Fermée la nuit."), biblio_ok))

        L.append(("cantine", "Cantine", "images/bg/bg cantine.jpg",
                  "Amélie, Lucas, les rumeurs." if mo != "nuit" else "Fermée.", mo != "nuit"))

        L.append(("administration", "Administration", "images/bg/bg couloir.jpg",
                  "Le bureau d'Éléonore Lambert." if mo in ("matin", "après-midi") else "Fermée.", mo in ("matin", "après-midi")))

        bureau_note = "Isabella Varga reçoit sur rendez-vous."
        bureau_ok = mo in ("matin", "après-midi")
        if mo in ("soir", "nuit") and store.temperament == "audacieux":
            bureau_note, bureau_ok = "Vide. Fouiller ? (audace)", True
        L.append(("bureau", "Bureau de la directrice", "images/bg/bg bureau directrice.jpg", bureau_note, bureau_ok))

        L.append(("commissariat", "Commissariat", "images/bg/bg commissariat.jpg",
                  "Malo Deschamps, et son café froid.", True))

        connait_quai = a("usb") or fait("quai7_tot")
        port_ok = j == 5 and mo == "soir" and connait_quai
        port_note = "Quai 7, ce soir." if port_ok else ("Il faudrait savoir où chercher." if not connait_quai else "Vendredi soir seulement.")
        L.append(("port", "Port — Quai 7", "images/bg/bg port.jpg", port_note, port_ok))

        L.append(("chambre", "Chambre", "images/bg/bg chambre.jpg",
                  "Dormir, appeler la maison, préparer l'audience.", True))
        return L

init python:

    def pistes_enquete():
        """Ce qu'il reste à découvrir, et où chercher : (lieu, phrase)."""
        if store.acte >= 2:
            return pistes_acte2()
        P = []
        if not fait("silhouette_racontee"):
            P.append(("Parloir", "Clara a dessiné le laboratoire ce soir-là. Elle a peut-être vu quelqu'un. (visites l'après-midi)"))
        if not a("epingle") and not fait("rate_epingle"):
            P.append(("Laboratoire", "La police n'a fouillé qu'autour du corps. Et si quelque chose avait roulé plus loin ?"))
        if fait("usb_chez_amelie") and not a("usb"):
            P.append(("Cantine", "Iris a confié la clé à Amélie, à la Gazette. Il faut lui parler d'Iris, et de son article."))
        if fait("piste_escalier") and not a("epingle"):
            P.append(("Administration", "L'escalier de service relie le labo à l'administration. L'ombre est passée par là."))
        if possede("marque_page") and not a("usb") and not fait("usb_chez_amelie"):
            P.append(("Bibliothèque", "Iris y passait toutes ses soirées. Son marque-page chauffe quand je m'en approche."))
        elif not possede("marque_page") and not fait("legende_livre"):
            P.append(("Bibliothèque", "Mme Bernier connaissait bien Iris. Elle sait peut-être ce qu'elle lisait."))
        if not a("badges"):
            P.append(("Administration / Bureau", "La porte du labo n'a pas été forcée : quelqu'un avait un badge. Il existe un registre."))
        if not a("azur"):
            P.append(("Cantine", "Lucas, le colocataire de Hugo, sait peut-être d'où venait son « truc pour réviser »."))
        if not a("photo_bal") and (fait("vu_eleonore") or fait("piste_azur")):
            P.append(("Cantine", "Amélie photographiait tout, au bal. Ses photos ont peut-être vu ce que personne n'a vu."))
        if not a("agenda") and not fait("reception_finie_22h"):
            P.append(("Administration", "Qui était à la réception, et jusqu'à quelle heure ? L'assistante tient l'agenda."))
        if (a("usb") or fait("quai7_tot")) and not a("temoignage"):
            P.append(("Port — Quai 7", "Le registre parle du quai 7, chaque jeudi… J'irai vendredi soir. Seul{}, ou avec Malo ?".format(accord("", "e"))))
        if not fait("malo_port") and (a("usb") or fait("quai7_tot")):
            P.append(("Commissariat", "Malo pourrait m'accompagner au port, s'il me fait assez confiance. Il faut lui montrer des preuves."))
        if store.jour == 5 and store.moment == "matin" and not fait("oral_passe"):
            P.append(("Oral de Dorian", "Ce matin, 9 h. Le manquer coûte cher à ma moyenne."))
        if bourse_en_danger():
            P.append(("Cours", "Ma moyenne est sous 10/20. Le conseil des bourses se réunit vendredi soir."))
        if fatigue():
            P.append(("Chambre", "Je suis à bout. Fatigué{}, je risque de passer à côté de détails.".format(accord("", "e"))))
        return P[:5]

label jeudi:
    $ chapitre = "jeudi"
    $ jour = 4
    $ moment = "matin"
    $ cafes_du_jour = 0
    call titre(4, "Jeudi", "16 octobre", "Trois jours")
    $ debut_jour_etat = instantane()

    scene bg classe with fondu
    $ poser_heure("JEUDI · 08 H 15")
    $ musique_jouer("mystere")

    narrator "L'Académie a annulé les cours du matin « en hommage ». Personne ne sait quoi faire de ce silence."
    narrator "Un mot glissé sous ma porte : {i}« Mon bureau. 8 h 15. — D. Varga »{/i}"

    show dorian normal at centre with fondu
    d "Asseyez-vous."
    d "Clara Morel a été placée en détention cette nuit. L'audience préliminaire aura lieu samedi, à dix heures."
    d "Si le juge estime les charges suffisantes, elle sera renvoyée devant une cour d'assises pour homicide. Elle a dix-huit ans."
    d "Ses parents m'ont demandé de la défendre. J'ai accepté."
    d pensif "Mais je ne peux pas être objectif. Ma sœur dirige cette école. Si l'affaire touche Valcourt, on dira que je protège l'institution, ou que je la sabote."
    d "Il me faut quelqu'un qui voit cette école avec des yeux neufs. Quelqu'un que Clara connaît, et en qui elle a confiance."
    d "Vous."
    moi "Moi ? Je suis en première année. Je ne sais rien de…"
    d "Vous savez regarder. C'est la seule chose qui ne s'apprend pas."
    d "Vous serez mon assistant{g=/e}. Vous enquêtez, vous me rapportez tout, et samedi vous serez à mes côtés à la table de la défense."
    d normal "Une chose encore : je ne vous dispense de rien. Les cours continuent. Mon oral de vendredi aussi."
    d "Vous aurez à choisir. Comme tout le monde."

    $ rencontrer("dorian")
    $ obtenir("carnet")
    $ obtenir("rapport")
    if fait("message_recu"):
        $ obtenir("message")
    $ donner("badge_visiteur")
    $ noter_journal("audience", "Audience préliminaire de Clara Morel.", "Samedi, 10 h")
    $ noter_journal("cours_jeudi", "Cours obligatoires (absences signalées au conseil des bourses).", "Jeudi et vendredi")

    if filiere == "droit":
        d "Vous êtes en droit. Alors vous savez ce qu'est une réquisition. Tenez."
        narrator "Il me tend une feuille imprimée : le journal électronique des portes de l'aile des sciences."
        d "Je l'ai obtenu ce matin, au nom de la défense. Regardez la ligne de vingt-deux heures trente et une."
        $ obtenir("badges")
        $ noter("soupcon_eleonore")

    if fait("temoin_cour"):
        moi "Monsieur, j'étais avec Clara mercredi soir. Elle dessinait depuis la cour, pas dans le laboratoire. Elle a oublié son carnet sur un banc quand l'orage a éclaté."
        show dorian pensif
        d "…Alors quelqu'un l'a ramassé, et l'a posé à côté du corps."
        d "Vous comprenez ce que ça veut dire ? Ce n'est pas un accident. C'est une mise en scène."
        $ lien("dorian", 1)
        $ noter("mise_en_scene")
    if fait("vu_ombre"):
        moi "Et j'ai vu quelqu'un s'enfuir par l'escalier de service. Une petite silhouette, avec un dossier."
        d "Un dossier. Dans cette école, la moitié du personnel en porte un. Il nous faudra mieux que ça."

    d "Allez. Vous avez jusqu'à samedi."
    $ souvenir("Dorian Varga m'a choisi{} pour défendre Clara à ses côtés.".format(accord("", "e")), "dorian normal")
    hide dorian with fondu

    $ creneau_idx = 0
    jump enquete_boucle


## ---------------------------------------------------------------------------
## La boucle des créneaux
## ---------------------------------------------------------------------------

label enquete_boucle:
    if creneau_idx >= len(CRENEAUX):
        call resume_jour("Vendredi")
        jump samedi_matin

    $ jour, moment, _h = CRENEAUX[creneau_idx]
    $ actions_restantes = len(CRENEAUX) - creneau_idx

    ## Événements imposés au début de certains créneaux.
    if creneau_idx == 3:
        $ jour = 4
        call resume_jour("Jeudi")
        $ jour = 5
        call vendredi_reveil
    if jour == M("malaise", 4) and moment == "soir":
        call jeudi_appel_maelle
    if jour == 4 and moment == "soir":
        call rebond_dorian
    if jour == 5 and moment == "après-midi":
        call rebond_clara
    if jour == 5 and moment == "soir":
        call vendredi_conseil_et_marche
        if fait("marche_accepte"):
            jump fin_silence

    $ poser_heure(_h)
    $ musique_jouer("enquete")
    if moment == "nuit":
        pensee "La nuit tombe sur Valcourt. Je pourrais dormir… ou profiter de ce que personne ne surveille."
    elif jour == 5 and moment == "soir":
        pensee "Vendredi soir. Demain, dix heures, l'audience. C'est ma dernière soirée pour trouver ce qui manque."
    elif creneau_idx == 0:
        pensee "Par où commencer ? Je relis ce que je sais, et ce qu'il me manque."
    window hide
    $ lieu = renpy.call_screen("carte_enquete", lieux=lieux_disponibles())

    ## Coûts du temps : un cours manqué, de l'énergie.
    if moment in ("matin", "après-midi") and lieu not in ("cours", "oral"):
        $ varier(etudes=-1)
    if moment == "nuit" and lieu != "chambre":
        $ dormi_cette_nuit = False

    call expression "lieu_" + lieu

    if jour == 5 and moment == "matin" and lieu != "oral":
        call oral_manque

    if moment == "nuit":
        if dormi_cette_nuit:
            $ energie = borner(energie + 5)
        else:
            $ nuits_blanches += 1
            $ varier(energie=-2, moral=-1)
        $ dormi_cette_nuit = False
        $ cafes_du_jour = 0

    $ creneau_idx += 1
    jump enquete_boucle


## ---------------------------------------------------------------------------
## Événements imposés
## ---------------------------------------------------------------------------

label jeudi_appel_maelle:
    scene bg chambre with fondu
    $ poser_heure("%s · 18 H 40" % nom_jour().upper())
    $ son("vibreur")
    narrator "Mon téléphone vibre. Maëlle. Encore. C'est le quatrième appel de la journée."
    menu:
        "Décrocher.":
            $ musique_jouer("tristesse")
            ma "Enfin. Écoute, je ne voulais pas t'inquiéter avec tout ce qui se passe chez toi, j'ai vu les infos…"
            ma "Mais c'est Maman. Elle a fait un malaise cette nuit, au travail. Une vraie, cette fois. Ils l'ont gardée en observation."
            ma "Elle va bien. Épuisement, ils disent. Le médecin lui a prescrit des fortifiants, et un arrêt de travail qu'elle refuse de prendre."
            ma "Je… je déteste te demander ça. Il me manque vingt euros pour la pharmacie. La paie arrive mardi."
            if argent >= 20:
                menu:
                    "Lui envoyer 20 €.":
                        $ varier(argent=-20, moral=1)
                        ma "Merci. Vraiment. Je te les rends, promis."
                        moi "Ne promets pas. Achète-les, c'est tout."
                        $ noter("aide_maman")
                    "« Je ne peux pas, Maëlle. J'en ai besoin ici. »":
                        ma "…D'accord. Je comprends. Je vais me débrouiller."
                        narrator "Elle ne m'en veut pas. C'est pire."
                        $ varier(moral=-1)
            else:
                moi "Je n'ai même plus vingt euros, Maëlle."
                ma "Ce n'est pas grave. Je vais demander à la voisine."
                $ varier(moral=-1)
            ma "Prends soin de toi, d'accord ? Tu as une voix de fantôme."
            $ cocher("appeler_maelle")
        "Rejeter l'appel. Pas maintenant.":
            narrator "Je regarde l'écran s'éteindre. Un message arrive presque aussitôt :"
            narrator "{i}« Maman a fait un malaise au travail. Elle va bien. Rappelle quand tu peux. »{/i}"
            $ recevoir("Maëlle", "Maman a fait un malaise au travail. Elle va bien. Rappelle quand tu peux.", "Jeu. 18:41")
            $ appels_manques += 1
            $ varier(moral=-2)
            $ noter("appel_rejete")
    return

label vendredi_reveil:
    scene bg chambre with fondu
    $ poser_heure("VENDREDI · 07 H 30")
    $ cafes_du_jour = 0
    if nuits_blanches >= 1 and fatigue():
        narrator "Je me lève avec l'impression d'avoir du sable sous les paupières. Mes mains tremblent en tenant la tasse."
        pensee "Je pourrais dormir debout. Mais Clara, elle, ne dort sans doute pas du tout."
    else:
        narrator "Vendredi. Plus qu'un jour avant l'audience."
    if bourse_en_danger():
        narrator "Un courriel de l'administration : {i}« Le conseil des bourses examinera votre dossier ce soir à 19 h. Votre moyenne actuelle est de [moyenne()]/20. »{/i}"
        $ recevoir("Administration", "Conseil des bourses ce soir 19 h. Moyenne actuelle insuffisante.", "Ven. 07:02")
    return

label vendredi_conseil_et_marche:
    scene bg couloir with fondu
    $ poser_heure("VENDREDI · 19 H 00")
    $ musique_jouer("tension")
    narrator "Le conseil des bourses se réunit à dix-neuf heures. Le verdict arrive par courriel à dix-neuf heures quarante."
    if bourse_en_danger():
        narrator "{b}« Compte tenu d'une moyenne de [moyenne()]/20 et d'absences répétées, le versement de votre bourse est suspendu à compter de ce jour, sauf décision contraire de la directrice. »{/b}"
        $ noter("bourse_suspendue")
        $ varier(moral=-2)
        pensee "Sauf décision contraire de la directrice."
        pensee "Maman. Les nuits à la blanchisserie. « Ne gâche pas ça. »"
    else:
        narrator "{i}« Moyenne de [moyenne()]/20. Bourse maintenue. Le conseil invite toutefois l'étudiant{g=/e} à une plus grande assiduité. »{/i}"
        pensee "Maintenue. Je respire pour la première fois de la journée."

    if a("usb") or fait("piste_azur") or fait("quai7_tot") or a("azur"):
        call marche_isabella
    return

label marche_isabella:
    scene bg bureau directrice with fondu
    $ poser_heure("VENDREDI · 20 H 00")
    $ musique_jouer("mystere")
    $ noter("marche")
    narrator "Une convocation, signée de la directrice, m'attend dans mon casier. {i}« Ce soir, 20 h. Venez seul{g=/e}. »{/i}"
    show isabella normal at centre with fondu
    isa "Asseyez-vous, [joueur_nom]. Je vais être directe, c'est ce que je fais de mieux."
    isa "Vous posez des questions. Sur un laboratoire, sur une poudre bleue, sur mon école."
    if a("usb"):
        isa "Et vous détenez une clé qui appartenait à Iris Delaunay. Ne niez pas, je sais tout ce qui se passe ici."
    isa pensif "Si ce que contient cette clé sort de ces murs, Valcourt est finie. Les donateurs partiront. Les bourses comme la vôtre disparaîtront."
    isa "Trois cents étudiants paieront pour une poignée de tricheurs."
    isa normal "Alors voici ce que je vous propose."
    if fait("bourse_suspendue"):
        isa "Votre bourse est rétablie dès demain. Garantie jusqu'au diplôme, quelles que soient vos notes."
    else:
        isa "Votre bourse est garantie jusqu'au diplôme, quelles que soient vos notes."
    isa "Une aide pour votre famille, aussi. J'ai lu votre dossier. Votre mère n'aura plus à travailler la nuit."
    isa "Et Clara Morel sera libérée. J'en fais mon affaire : il suffit qu'un témoin se souvienne mieux, qu'une procédure s'égare. L'affaire sera classée comme un accident."
    isa "En échange, vous me remettez tout ce que vous avez trouvé, et vous oubliez ce mot : Azur."
    narrator "Le silence dure. Dans la cheminée, une bûche craque."
    pensee "Maman qui n'aurait plus à travailler la nuit. Clara libre. Il suffirait de dire oui."
    pensee "Et Iris passerait pour une fille qui a glissé dans un laboratoire."

    menu:
        "Accepter le marché.":
            $ noter("marche_accepte")
            $ souvenir("J'ai accepté le marché d'Isabella Varga.", "isabella sourire")
            isa sourire "Vous êtes plus raisonnable que vous n'en avez l'air."
            return
        "Refuser.":
            moi "Non."
            isa colere "Vous êtes {g=sûr/sûre} de comprendre ce que vous refusez ?"
            moi "Vous m'offrez la liberté de Clara contre la vérité sur Iris. Votre devise dit que l'une ne va pas sans l'autre."
            $ lien("isabella", -2)
            if a("epingle") or a("badges"):
                moi "Et vous devriez regarder ceci avant de protéger qui que ce soit."
                narrator "Je pose sur son bureau ce que j'ai trouvé."
                if a("badges"):
                    narrator "Le registre : le badge de la direction, au laboratoire, à vingt-deux heures trente et une."
                if a("epingle"):
                    narrator "L'épingle dorée, trouvée sous la paillasse."
                show isabella pensif
                isa "…Le passe de direction."
                isa "Je ne l'avais pas sur moi mercredi soir. Je ne l'ai jamais sur moi. C'est Éléonore qui le garde. Toujours."
                narrator "Pour la première fois, Isabella Varga a l'air de ne pas savoir quelque chose."
                isa "Douze ans. Elle m'a servie douze ans. Je lui confiais mes clés, mes rendez-vous, mes secrets."
                isa "Si c'est elle, alors je protégeais la mauvaise personne."
                isa normal "Samedi, je serai au tribunal. Et je dirai à quelle heure ma réception s'est terminée."
                $ noter("isabella_temoin")
                $ lien("isabella", 4)
            else:
                isa normal "Très bien. Alors bonne chance, [joueur_nom]. Vous allez en avoir besoin."
            $ noter("marche_refuse")
            $ souvenir("J'ai refusé le marché d'Isabella Varga.", "isabella colere")
    hide isabella with fondu
    return
