## Acte II — le cœur et les trahisons.
##
## Une romance possible avec Clara, Iris, Amélie ou Lucas, quel que soit le genre
## du joueur : une étincelle (jeudi), la jetée (dimanche soir), la déclaration
## sur le toit (mardi, la veille du gala). Le Livre la reprendra dans « le prix ».
## Et un traître dans la Gazette : Lucas, que Ferrière tient par Hugo.

default coeur = None
default cnom = ""

## La personne aimée, quelle qu'elle soit : son nom suit la variable cnom.
define amour = Character("[cnom]", who_color="#e8b4c4")

init 1 python:
    NOMS_RELATION["lucas"] = "Lucas"
    PHRASES_RELATION["lucas"] = ("Lucas s'en souviendra.", "Lucas s'en souviendra.")
    CANDIDATS_COEUR = ("clara", "iris", "amelie", "lucas")

    def candidat_coeur():
        """La personne vers qui le joueur penche : le dernier penchant noté, sinon la relation la plus forte."""
        if store.coeur:
            return store.coeur
        for c in CANDIDATS_COEUR:
            if fait("penchant_" + c):
                return c
        return max(CANDIDATS_COEUR, key=lambda c: store.rel.get(c, 0))

    def perso_coeur(c):
        return {"clara": store.c, "iris": store.ir, "amelie": store.am, "lucas": store.lu}[c]

    def prenom_coeur(c):
        return {"clara": "Clara", "iris": "Iris", "amelie": "Amélie", "lucas": "Lucas"}[c]


################################################################################
## Dimanche soir — la jetée
################################################################################

label acte2_jetee:
    $ cj = candidat_coeur()
    $ cnom = prenom_coeur(cj)
    scene bg port nuit with noir
    $ poser_heure("DIMANCHE · 19 H 00")
    $ ambiance("port")
    $ musique_jouer("clara")
    narrator "Un message de [cnom] : {i}« Jetée. Maintenant. Pas pour l'enquête. »{/i}"
    narrator "Au bout de la jetée, le phare tourne. Chaque passage de lumière découpe une silhouette assise sur le parapet, les jambes dans le vide."
    $ renpy.show(cj + " normal", at_list=[centre])
    with fondu
    if cj == "clara":
        c "Je t'ai dessiné tous les jours depuis jeudi. Regarde."
        narrator "Elle tourne les pages. Moi à la cantine, moi au café du port, moi endormi{g=/e} sur une table. Toujours le même angle : de trois quarts, un peu de loin."
        c "Je n'arrive pas à faire tes yeux. J'efface, je recommence. C'est la première fois que ça m'arrive avec quelqu'un."
        c "Je crois que c'est parce que je n'ose pas te regarder assez longtemps."
    elif cj == "iris":
        ir "Huit boucles. Tu sais ce que j'ai appris ? À ne m'attacher à rien. Le Livre reprend tout ce qu'on aime : le goût, les voix, les gens."
        ir "Alors je fais attention. Je regarde les choses de loin. Les gens aussi."
        ir "Et puis tu es arrivé{g=/e}, la table du fond, toujours la même, à chaque boucle. Et je n'ai pas réussi à regarder de loin."
    elif cj == "amelie":
        am "Tu sais pourquoi je parle tout le temps ? Parce que quand je me tais, j'entends ce que je pense. Et ce que je pense me fait peur."
        am "Là, par exemple. Je me tais depuis deux minutes. C'est un record."
        am "Et ce que j'entends, c'est ton prénom. En boucle. C'est très gênant pour une rédactrice en chef."
    else:
        lu "Je ne suis pas doué pour parler. Pour courir, oui. Pour porter des cartons, aussi. Pour parler…"
        lu "Depuis jeudi, je viens au café avec les croissants juste pour te voir lever la tête quand j'entre. C'est idiot."
        lu "Et si un jour je fais une bêtise, une vraie, tu… Non. Rien. Oublie."
        $ noter("lucas_hesite")
    narrator "Le phare passe. Pendant une seconde, tout est blanc. Puis il ne reste que le bruit de l'eau contre la pierre."
    menu:
        "Lui prendre la main.":
            $ coeur = cj
            $ rel[cj] = min(10, rel.get(cj, 3) + 2)
            narrator "Je prends sa main. Elle est froide. Elle serre la mienne, très fort, comme on s'accroche à une rambarde."
            if cj == "clara":
                c "…Tes yeux. Je crois que je vais réussir à les dessiner, maintenant."
            elif cj == "iris":
                ir "C'est la première chose depuis des mois dont je sens vraiment le… poids. La chaleur. Je ne sais pas comment dire."
            elif cj == "amelie":
                am "Ne dis rien. Si tu dis quelque chose, je vais répondre, et je vais tout gâcher. Restons comme ça."
            else:
                lu "…D'accord. D'accord. Je ne vais pas courir. Pour une fois."
            $ souvenir("Sur la jetée, sous le phare, j'ai pris la main de " + cnom + ".", cj + " normal", "bg port nuit")
            $ varier(moral=2)
        "« Tu comptes beaucoup pour moi. Mais comme quelqu'un sur qui je peux compter. »":
            narrator "[cnom] hoche la tête. Un sourire, un peu de travers."
            amour "C'est bien aussi. C'est même rare. On ne compte pas sur grand monde, dans cette ville."
            $ noter("coeur_ami_" + cj)
            $ lien(cj, 1, silencieux=True)
    $ renpy.hide(cj)
    with fondu
    $ ambiance(None)
    return


################################################################################
## Mardi matin — le traître
################################################################################

label acte2_trahison:
    $ son("vibreur")
    call sms("Amélie", [("amelie", "Le café a été fouillé cette nuit."), ("amelie", "Rien de volé. Sauf le carnet de la Gazette : nos noms, nos adresses, nos sources."),
                        ("amelie", "Seuls nous quatre savions où on se réunissait. Et Lucas, qui nous apporte les croissants.")], "Mardi, 08:52")
    $ recevoir("Amélie", "Le café a été fouillé cette nuit. Ils ont pris le carnet de la Gazette.", "Mar. 08:52")
    scene bg cantine with fondu
    $ poser_heure("MARDI · 09 H 10")
    $ musique_jouer("tension")
    show lucas normal at centre with fondu
    narrator "Lucas est seul à une table, devant un café qu'il ne boit pas. Il a des cernes de quelqu'un qui n'a pas dormi, ou qui a beaucoup pleuré."
    if coeur == "lucas":
        pensee "« Si un jour je fais une bêtise, une vraie… » Il l'a dit dimanche. Sur la jetée."
    moi "Lucas. Le café du port. C'est toi ?"
    narrator "Il ne nie pas. Il ne lève même pas les yeux."
    lu "Lundi soir, deux types sont venus à la résidence. Cartes de police, costume gris. Ils avaient des photos de la chambre de Hugo."
    lu "Les pastilles. Il en restait, dans un tiroir. Ils ont dit : détention, revente à des mineurs. Cinq ans, minimum. Hugo, en prison. Hugo, qui a failli mourir."
    lu "Sauf si je leur disais où se réunissait la Gazette. Et qui en faisait partie."
    if fait("hugo_donne"):
        lu "Ils savaient pour Hugo. Quelqu'un leur avait parlé de lui, je ne sais pas qui."
        pensee "Moi. Lundi midi. « Hugo, un étudiant hospitalisé. » J'ai donné son nom à Ferrière comme on donne l'heure."
        $ varier(moral=-1)
    lu "J'ai donné l'adresse. J'ai donné vos noms. Et je me déteste depuis dix heures."
    menu:
        "Lui pardonner, et lui demander de nous aider.":
            moi "Ils t'ont tenu par la seule chose qui compte pour toi. C'est exactement ce que fait le Capitaine. Avec Halvard, avec Éléonore, avec tout le monde."
            moi "Tu veux te racheter ? Ils attendent encore des informations de toi, non ?"
            lu "…Ils veulent savoir ce que vous préparez pour le gala."
            moi "Alors dis-leur. Dis-leur qu'on va accuser Halvard."
            narrator "Il me regarde enfin. Il comprend. Un drôle de sourire, mouillé, lui monte aux lèvres."
            lu "Un agent double. Comme dans les films. Hugo va me tuer de jalousie."
            $ noter("lucas_pardonne", "lucas_double")
            $ rel["lucas"] = min(10, rel.get("lucas", 3) + 2)
            if coeur == "lucas":
                lu "Pourquoi tu me pardonnes ? Après ce que je t'ai fait ?"
                moi "Parce que dimanche, sur la jetée, tu m'as prévenu{g=/e}. À ta manière."
            $ souvenir("Lucas nous avait trahis pour sauver Hugo. Je lui ai pardonné.", "lucas normal", "bg cantine")
        "Le chasser de la Gazette.":
            moi "Tu as donné nos noms. Iris a déjà été tuée une fois par ces gens. Une fois, Lucas."
            moi "Ne reviens pas au café. Ne reviens plus."
            narrator "Il se lève. Il renverse son café. Il ne le ramasse pas. Il part sans se retourner, à grandes enjambées de coureur."
            $ noter("lucas_chasse")
            $ rel["lucas"] = max(0, rel.get("lucas", 3) - 3)
            $ varier(moral=-1)
            if coeur == "lucas":
                pensee "Dimanche, sa main tremblait dans la mienne. Je comprends pourquoi, maintenant. Ça ne fait pas moins mal."
            $ souvenir("Lucas nous avait trahis pour sauver Hugo. Je l'ai chassé.", "lucas normal", "bg cantine")
    hide lucas with fondu
    return


################################################################################
## Mardi, 23 h — le toit, la veille du gala
################################################################################

label acte2_toit_declaration:
    scene bg toit with noir
    $ poser_heure("MARDI · 23 H 15")
    $ musique_jouer("clara")
    if not coeur:
        narrator "La veille du gala, on se retrouve tous sur le toit, sans s'être donné rendez-vous. Iris, Clara, Amélie. Personne ne parle de demain."
        narrator "Clara dessine les grues. Amélie raconte des histoires fausses. Iris boit un café sans goût en souriant quand même."
        pensee "Quoi qu'il arrive demain, il y aura eu ce soir."
        $ souvenir("La veille du gala, on s'est tous retrouvés sur le toit, sans rendez-vous.", None, "bg toit")
        return
    $ cnom = prenom_coeur(coeur)
    if coeur == "lucas" and fait("lucas_chasse"):
        narrator "J'attends sur le toit jusqu'à minuit. Il ne vient pas."
        call sms("Lucas", [("lucas", "Pardon."), ("lucas", "Réussis demain. Pour Hugo. Pour toi.")], "Mardi, 23:58")
        pensee "Un seul mot. Et je ne sais pas si c'est moi qui ai eu raison."
        $ souvenir("La veille du gala, Lucas n'est pas venu sur le toit. Un seul mot : « Pardon ».", None, "bg toit")
        return
    $ renpy.show(coeur + " normal", at_list=[centre])
    with fondu
    narrator "[cnom] est déjà là. Deux couvertures, un thermos, et la ville entière en contrebas."
    amour "Demain, quoi qu'il arrive, tout change. Alors je voulais un soir où rien ne change. Juste un."
    menu:
        "Lui dire que je l'aime.":
            moi "[cnom]. Je t'aime. Je voulais le dire avant demain. Au cas où demain prendrait trop de place."
            if coeur == "clara":
                c "Je le savais. Je l'ai dessiné avant toi. Page quarante-deux. Je te la montrerai."
                narrator "Elle pose son front contre le mien. Ses cheveux sentent la peinture à l'eau."
            elif coeur == "iris":
                ir "Je ne sais plus ce que goûtent les choses. Mais ça. Ça, je le sens. Jusqu'au bout des doigts."
                narrator "Elle rit, et pleure, et rit encore. Pour la première fois, elle a l'air d'avoir vingt ans."
            elif coeur == "amelie":
                am "…"
                am "Pour une fois, je n'ai rien à dire. Note-le. Ça n'arrivera plus jamais."
                narrator "Elle m'embrasse sur la joue, très vite, comme on vole quelque chose."
            else:
                lu "Après ce que j'ai fait ? Tu es complètement {g=fou/folle}… Non. Attends. Je réessaie."
                lu "Moi aussi. Depuis le premier croissant."
            $ noter("declaration")
            $ rel[coeur] = min(10, rel.get(coeur, 3) + 2)
            $ souvenir("La veille du gala, sur le toit, j'ai dit « je t'aime » à " + cnom + ".", coeur + " normal", "bg toit")
            $ varier(moral=3)
        "Se taire. Le dire après le gala.":
            narrator "Je ne dis rien. On regarde la ville ensemble. Ses épaules contre les miennes."
            amour "Tu voulais dire quelque chose."
            moi "Après. Quand ce sera fini. Promis."
            amour "Je retiens. Je retiens tout, moi."
            $ noter("declaration_apres")
            $ varier(moral=1)
    $ renpy.hide(coeur)
    with fondu
    return


################################################################################
## Le prix : le Livre reprend aussi le toit
################################################################################

label acte2_prix_coeur:
    if not fait("declaration") or coeur == "iris":
        return
    $ cnom = prenom_coeur(coeur)
    scene bg toit with fondu
    $ renpy.show(coeur + " normal", at_list=[centre])
    with fondu
    $ cpron = "Il" if coeur == "lucas" else "Elle"
    narrator "[cnom] m'attend sur le toit. [cpron] a ce sourire de quelqu'un qui garde un secret à deux."
    amour "Tu te souviens de ce que tu m'as dit, ici, mardi soir ?"
    narrator "Mardi soir. Je cherche. Le gala, la médaille, Ferrière. Et avant… un trou. Un trou propre, aux bords nets, comme découpé aux ciseaux."
    moi "Mardi… J'étais… ici ?"
    narrator "Son sourire tombe. Pas d'un coup. Petit à petit, comme une feuille."
    if coeur == "clara":
        c "Page quarante-deux. Je t'avais dit que je te la montrerais."
        narrator "Elle ouvre son carnet. Deux silhouettes sur un toit, le front l'une contre l'autre. Je ne me souviens de rien."
        c "Alors je te la redessinerai. Autant de fois qu'il faudra. Je suis très patiente, avec les dessins."
    elif coeur == "amelie":
        am "Tu m'as dit quelque chose qui m'a fait taire. Moi. Taire. Tu te rends compte de l'exploit ?"
        am "Et tu ne t'en souviens pas."
        am "Bon. Alors c'est moi qui le dirai, la prochaine fois. Je parle tout le temps, de toute façon. Ça fera une phrase de plus."
    else:
        lu "Tu m'as dit… Non. Je ne vais pas te le dire. Je veux que tu le redises toi-même."
        lu "Je peux attendre. J'ai attendu un croissant entier, la première fois."
    $ noter("declaration_oubliee")
    $ souvenir("Le Livre m'a pris le soir sur le toit. " + cnom + " s'en souvient pour deux.", coeur + " normal", "bg toit")
    $ renpy.hide(coeur)
    with fondu
    return
