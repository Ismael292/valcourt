## Les rebondissements : ce qui fait douter le joueur, jusqu'au bout.

init python:
    PREUVES["lettre_anonyme"] = dict(
        nom="Lettre anonyme",
        image="preuves/lettre_anonyme.png",
        desc="Glissée sous ma porte mardi soir. Papier à en-tête de la direction, frappé d'un V doré. « Une bourse, ça se perd vite. »",
        detail="Tapée à la machine. Les lettres bavent un peu, et le « e » saute au-dessus de la ligne : une vieille machine mécanique.",
    )
    PREUVES["temoignage_clara"] = dict(
        nom="Ce que Clara a vu",
        image="preuves/temoignage_clara.png",
        desc="Clara est retournée chercher son carnet à 22 h 30. Le banc était vide. Par la vitre, elle a vu Iris se disputer avec quelqu'un.",
        detail="« Des cheveux relevés en chignon. Un dossier serré contre elle. Puis un bruit horrible. J'ai couru. J'ai eu tellement peur qu'on m'accuse que j'ai menti. »",
    )

################################################################################
## 1. Mardi soir — la lettre anonyme
################################################################################

label rebond_lettre_anonyme:
    $ son("papier")
    narrator "Au moment d'éteindre la lumière, un froissement. Quelqu'un vient de glisser une enveloppe sous ma porte."
    narrator "J'ouvre aussitôt. Le couloir est vide. Au loin, une porte coupe-feu se referme doucement."
    narrator "Une feuille épaisse, frappée d'un V doré. Quelques lignes tapées à la machine :"
    if fait("vu_eleonore"):
        narrator "{i}« Ce que tu as vu au bal, tu ne l'as pas vu. Une bourse, ça se perd vite. — Un ami de Valcourt. »{/i}"
    else:
        narrator "{i}« Ne t'approche plus d'Iris Delaunay. Une bourse, ça se perd vite. — Un ami de Valcourt. »{/i}"
    $ obtenir("lettre_anonyme")
    $ musique_jouer("tension")
    pensee "Le papier à en-tête de la direction. Et qui, à part la direction, sait que je suis {g=boursier/boursière} ?"
    pensee "Isabella Varga ? Mais pourquoi menacerait-elle {g=un_étudiant/une_étudiante} de première année, au deuxième jour ?"
    $ souvenir("Une lettre anonyme sous ma porte : « Une bourse, ça se perd vite. »")
    menu:
        "Que faire de cette lettre ?"
        "La garder, et ne rien dire à personne.":
            $ noter("lettre_gardee")
            pensee "Si quelqu'un me surveille, mieux vaut qu'il me croie {g=effrayé/effrayée}."
        "La montrer à Clara demain matin.":
            $ noter("lettre_montree_clara")
            $ lien("clara", 1)
            pensee "Je ne veux plus porter ce genre de choses {g=seul/seule}."
        "La brûler et ne plus y penser.":
            $ preuves.remove("lettre_anonyme")
            $ noter("lettre_brulee")
            $ varier(moral=1)
            narrator "La flamme du briquet de Lucas, emprunté au bal, dévore le V doré. Je dors mieux. Pas tout à fait bien."
    return

################################################################################
## 2. Jeudi soir — Dorian a menti
################################################################################

label rebond_dorian:
    $ noter("dorian_appel_connu")
    call sms("Malo Deschamps", [("malo", "Relevé du téléphone d'Iris. Mercredi, 22 h 05 : quatre minutes avec Dorian Varga."), ("malo", "Ton prof n'était plus à la réception à 22 h 20. Il était sur le campus. Il te l'a dit ?")], "Jeudi, 19:12")
    $ recevoir("Malo Deschamps", "Mercredi 22 h 05 : Iris a appelé Dorian Varga. Il était sur le campus à 22 h 20.", "Jeu. 19:12")
    $ musique_jouer("tension")
    pensee "Dorian. Celui qui défend Clara. Celui qui m'a {g=choisi/choisie}, moi, parmi trois cents étudiants."
    pensee "« Je ne peux pas être objectif », a-t-il dit. Il ne m'a pas dit pourquoi."

    scene bg classe with fondu
    $ poser_heure("JEUDI · 19 H 30")
    show dorian normal at centre with fondu
    d "[joueur_nom]. Vous avez une tête de procureur. Qu'y a-t-il ?"
    menu:
        "Le confronter : « Iris vous a appelé mercredi soir. »":
            show dorian pensif
            d "…Malo. Évidemment."
            d "Oui. Iris m'a appelé à vingt-deux heures cinq. Elle voulait que je l'aide à publier son enquête, que je vérifie les aspects juridiques."
            d "Elle m'a dit : « Ça va éclabousser votre sœur. » Et j'ai refusé. Je lui ai demandé d'attendre. Une semaine. Le temps de parler à Isabella."
            d "J'ai raccroché. Puis j'ai eu honte. Je suis allé la chercher pour m'excuser. Le laboratoire était fermé, la cour était vide. Je suis reparti."
            d normal "Si j'avais frappé à cette porte, elle serait peut-être vivante. Voilà ce que je ne vous ai pas dit."
            menu:
                "« Je vous crois. »":
                    $ lien("dorian", 2)
                    $ noter("confiance_dorian")
                    d "Ne me croyez pas trop vite. C'est le premier conseil d'un avocat."
                "« Je ne sais pas si je peux encore vous croire. »":
                    $ lien("dorian", -1)
                    $ noter("doute_dorian")
                    d "C'est votre droit. C'est même votre devoir."
            $ souvenir("Dorian a avoué : Iris l'avait appelé. Il avait refusé de l'aider.", "dorian pensif")
        "Ne rien dire. L'observer.":
            narrator "Je lui pose une question sur Clara. Il répond, posément, comme toujours."
            narrator "Mais ses doigts tapotent la couverture de son code pénal, et il ne me regarde pas dans les yeux."
            pensee "Il cache quelque chose. Reste à savoir quoi."
            $ noter("doute_dorian")
            $ souvenir("Dorian m'a menti par omission. Et je n'ai rien dit.", "dorian normal")
    hide dorian with fondu
    return

################################################################################
## 3. Vendredi après-midi — Clara a menti
################################################################################

label rebond_clara:
    $ noter("clara_mensonge_connu")
    $ son("vibreur")
    $ musique_jouer("tension")
    narrator "Dorian m'appelle. Sa voix est plus sèche que d'habitude."
    d "Un voisin de Clara s'est présenté à la police ce matin. Il l'a vue quitter la résidence mercredi soir, à vingt-deux heures trente. En pyjama, sous la pluie."
    d "Elle nous a dit qu'elle n'était pas ressortie. Elle nous a menti."
    d "Si la procureure l'apprend avant nous, l'audience est perdue. Il faut qu'elle nous dise la vérité. Toute la vérité."
    pensee "Clara. Clara qui pleure dans les bibliothèques. Clara qui m'a juré : « Je n'ai rien fait. »"
    pensee "Et si je m'étais {g=trompé/trompée} sur elle depuis le début ?"
    $ souvenir("Clara nous a menti : elle est ressortie à 22 h 30.", "clara peur")
    return

label parloir_aveu:
    ## Appelé depuis le parloir quand on sait que Clara a menti.
    show clara peur at centre
    if niveau("clara") >= 5 or temperament == "empathique" or fait("promesse_clara"):
        c "Tu sais. Je le vois dans tes yeux. Tu sais que je suis ressortie."
        c triste "Je suis retournée chercher mon carnet, à vingt-deux heures trente. Il n'était plus sur le banc. Quelqu'un l'avait pris."
        c "Et puis j'ai vu de la lumière derrière la vitre. Iris était là. Elle criait sur quelqu'un. Une femme, je crois. Des cheveux relevés en chignon. Un dossier serré contre elle."
        c "Et il y a eu ce bruit. Ce bruit horrible. J'ai couru. Je n'ai pas appelé à l'aide. J'ai couru jusqu'à ma chambre et je me suis cachée sous ma couette comme une enfant."
        c "J'avais tellement peur qu'on m'accuse que j'ai menti. Et on m'a accusée quand même."
        $ obtenir("temoignage_clara")
        $ noter("aveu_clara")
        $ lien("clara", 1)
        menu:
            "« Tu as eu peur. Ce n'est pas un crime. »":
                c "Merci… Merci de ne pas me regarder comme ils me regardent tous."
                $ lien("clara", 1)
            "« Tu aurais pu la sauver. »":
                c "Je sais. Je le sais. Tu crois que je ne me le répète pas toutes les nuits ?"
                $ lien("clara", -2)
                $ varier(moral=-1)
        $ souvenir("Clara a tout avoué : elle a vu la dispute, et elle a fui.", "clara triste")
    else:
        c colere "Je ne suis pas ressortie ! Pourquoi tout le monde veut que j'aie menti ?"
        c triste "Toi aussi, tu ne me crois plus ?"
        narrator "Elle se lève et demande au surveillant de la ramener en cellule. Je n'ai pas su trouver les mots."
        $ noter("clara_nie")
        $ souvenir("Clara a refusé de me parler. Elle cache quelque chose.", "clara colere")
    return

################################################################################
## 3 bis. À l'audience : le voisin
################################################################################

label rebond_voisin_audience:
    scene bg tribunal procureur with fondu
    show saunier normal at centre with fondu
    $ musique_jouer("tension")
    pr "Avant d'entendre mon second témoin, la cour doit savoir une chose."
    pr "Un voisin de l'accusée l'a vue quitter la résidence mercredi à vingt-deux heures trente. Alors qu'elle a juré aux enquêteurs ne pas être ressortie."
    $ foule("{i}(un murmure parcourt la salle){/i}")
    hide saunier with fondu
    if fait("aveu_clara"):
        scene bg tribunal defense with fondu
        moi "La défense le sait, Monsieur le Président, et ne le cache pas."
        moi "Clara Morel est retournée chercher son carnet. Le banc était vide : quelqu'un l'avait déjà pris. Par la vitre, elle a vu Iris se disputer avec une femme aux cheveux relevés en chignon."
        moi "Elle a entendu la chute. Elle a fui, et elle a eu honte. Avoir peur n'est pas un crime. Mais cela fait d'elle un témoin."
        scene bg tribunal juge with fondu
        ju "La cour prend note. Le témoignage de l'accusée sera versé au dossier."
        $ noter("clara_temoin_proces")
    else:
        if fait("clara_mensonge_connu"):
            pensee "Je le savais. Et je n'ai pas réussi à la faire parler à temps."
        else:
            pensee "Quoi ? Clara est ressortie ? Elle m'a menti, à moi aussi ?"
        scene bg tribunal juge with fondu
        $ son("marteau")
        ju "La défense était-elle au courant ? Non ? Voilà qui en dit long sur la confiance que lui accorde sa propre cliente."
        $ marteaux = max(1, marteaux - 1)
        show clara triste at centre with fondu
        c "C'est vrai ! J'y suis retournée ! J'ai vu quelqu'un avec Iris, une femme avec un chignon, et j'ai entendu… j'ai entendu…"
        c "J'ai eu peur ! J'ai menti parce que j'avais peur !"
        narrator "Elle s'effondre en larmes sur le banc des accusés. Le juge la regarde longtemps, sans rien dire."
        $ noter("clara_temoin_proces")
        hide clara with fondu
    $ souvenir("À l'audience, on a révélé que Clara était ressortie cette nuit-là.", "clara triste")
    return

################################################################################
## 4. L'accusation de trop : Éléonore accuse la directrice
################################################################################

label rebond_accuse_isabella:
    scene bg tribunal temoin with fondu
    show eleonore colere at centre with fondu
    $ musique_jouer("tension")
    el "Vous croyez avoir gagné ? Je n'ai fait qu'obéir !"
    el "C'est Madame Varga qui a tout organisé. L'Azur, le port, l'argent qui passait par les donateurs. Moi, je gardais ses clés. Je gardais ses secrets."
    $ foule("{i}(la salle explose){/i}")
    $ son("marteau")
    scene bg tribunal public with fondu
    show isabella colere at centre with fondu
    isa "C'est un mensonge. C'est… un mensonge."
    narrator "Pour la première fois, la voix d'Isabella Varga tremble."
    hide isabella with fondu
    if fait("marche"):
        pensee "Isabella m'a proposé un marché pour tout enterrer. Elle voulait cette clé à tout prix. Et si Éléonore disait vrai ?"
    else:
        pensee "La directrice qui « sait tout de tous ». Aurait-elle pu ignorer ce qui se passait dans son propre laboratoire ?"
    $ peut_refuter = a("badges") or a("agenda") or fait("isabella_temoin") or a("usb")
    menu:
        "Que répond la défense ?"
        "Démontrer qu'Éléonore ment, pièces à l'appui." if peut_refuter:
            moi "Le passe de la direction était dans le tiroir de Mademoiselle Lambert, dont elle seule a la clé : elle nous l'a dit elle-même."
            if a("usb"):
                moi "Le registre d'Iris ne porte que deux initiales : E.L. et N.R. Pas une seule fois I.V."
            if a("agenda") or fait("isabella_temoin"):
                moi "Et à vingt-deux heures trente et une, Madame Varga raccompagnait ses donateurs devant cent témoins."
            moi "Madame Varga a voulu protéger son école. Elle a eu tort, et elle devra s'en expliquer. Mais elle n'a pas tué Iris Delaunay."
            scene bg tribunal temoin
            show eleonore triste at centre
            el "…"
            narrator "Éléonore baisse les yeux. Son dernier mensonge vient de tomber."
            $ noter("isabella_innocentee")
            $ lien("isabella", 3, silencieux=True)
            $ souvenir("Éléonore a tenté d'accuser la directrice. J'ai prouvé qu'elle mentait.", "eleonore triste")
        "Demander que Madame Varga soit poursuivie, elle aussi.":
            moi "La défense demande que la cour entende aussi Madame Isabella Varga sur ces faits."
            scene bg tribunal juge
            ju "La cour en prend note. Madame Varga, vous resterez à la disposition de la justice."
            $ noter("isabella_accusee")
            $ souvenir("J'ai laissé Éléonore entraîner la directrice dans sa chute.", "isabella colere")
        "Ne rien dire. Laisser le doute planer.":
            pensee "Je ne sais plus qui croire. Alors je me tais."
            $ noter("doute_isabella")
            $ souvenir("Éléonore a accusé la directrice. Je n'ai rien dit.", "isabella pensif")
    return
