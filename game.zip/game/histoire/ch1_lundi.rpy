## Jour 1 — Lundi : la rentrée.

label lundi:
    $ chapitre = "lundi"
    $ jour = 1
    $ moment = "matin"
    $ cafes_du_jour = 0
    call titre(1, "Lundi", "13 octobre", "La rentrée")
    $ debut_jour_etat = instantane()

    scene bg academie
    show poussiere
    with fondu_long
    $ musique_jouer("quotidien")
    $ ambiance("oiseaux")
    $ poser_heure("LUNDI · 08 H 12")

    narrator "Le bus me dépose devant les grilles à huit heures douze."
    narrator "L'Académie de Valcourt ressemble aux photos de la brochure, en plus grand, en plus vieux, en plus intimidant."
    narrator "Au-dessus du portail, trois mots sont gravés dans la pierre :"
    narrator "{b}VERITAS · JUSTITIA · LIBERTAS{/b}"
    pensee "Vérité, justice, liberté. Rien que ça."

    narrator "Ma valise pèse le poids d'une vie entière pliée en quatre. Dans ma poche, la lettre d'admission, relue cent fois :"
    narrator "{i}« … {g=admis/admise} au titre de la bourse d'excellence, sous réserve du maintien d'une moyenne de 10/20. »{/i}"
    pensee "Sous réserve. Ces deux mots me suivent depuis l'été."

    $ son("vibreur")
    narrator "Mon téléphone vibre. Je sais qui c'est avant même de regarder."
    $ rencontrer("maelle")
    ma "Alors ? Tu y es ? Raconte !"
    moi "J'y suis. C'est… immense, Maëlle. Il y a des tourelles. De vraies tourelles."
    ma "Maman a pleuré ce matin en partant au travail. Elle dit qu'elle n'a pas fait toutes ces nuits pour rien."
    ma "Alors tu ne gâches pas ça, d'accord ? Tu travailles, tu restes {g=sage/sage}, et tu nous appelles."
    menu:
        "« Promis. Je ne vous décevrai pas. »":
            ma "Je sais. C'est bien pour ça qu'on t'aime, {g=petit_frère/petite_sœur}."
            $ noter("promesse_famille")
        "« Dis à Maman qu'elle peut arrêter les nuits. Je vais tout réussir. »":
            ma "Ne promets pas ce que tu ne contrôles pas. Fais de ton mieux, c'est tout ce qu'on demande."
            $ varier(moral=1)
        "« Je dois y aller, on m'attend. »":
            ma "Toujours pressé{g=/e}. Bon. File. Je t'embrasse."
    $ noter_journal("appeler_maelle", "Rappeler Maëlle dans la semaine.", "Quand je peux")
    $ souvenir("Devant les grilles de Valcourt, la voix de Maëlle : « Ne gâche pas ça. »", "maelle normal")
    $ recevoir("Maëlle", "Maman te fait dire qu'elle est fière. Mange correctement.", "Lun. 08:20")

    ## ---------------------------------------------------------------------
    ## Le discours de la directrice
    ## ---------------------------------------------------------------------
    scene bg amphi with fondu
    $ ambiance("salle")
    $ poser_heure("LUNDI · 09 H 00")
    $ musique_jouer("mystere")

    narrator "L'amphithéâtre de rentrée sent le bois ciré et le trac."
    narrator "Trois cents étudiants s'y entassent. Le silence se fait d'un coup, comme si quelqu'un avait coupé le son."

    show isabella normal at centre
    $ rencontrer("isabella")
    narrator "Une femme s'avance sur l'estrade. Tailleur noir, cheveux sombres, un regard qui fait le tour de la salle et n'oublie personne."
    isa "Bienvenue à Valcourt."
    isa "Je suis Isabella Varga. Je dirige cette Académie depuis douze ans, et je vais vous dire ce que je dis à chaque promotion."
    isa "Ici, personne ne vous doit rien. Ni vos professeurs, ni vos camarades, ni moi."
    isa "Ce que vous obtiendrez, vous le mériterez. Ce que vous perdrez aussi."
    isa sourire "Mais si vous êtes à la hauteur, Valcourt vous ouvrira toutes les portes de ce pays."

    show isabella normal at droite_c
    show eleonore normal at gauche_c
    with fondu
    $ rencontrer("eleonore")
    narrator "Un pas derrière elle, une jeune femme en cardigan sombre tient un dossier frappé d'un V doré. Chignon impeccable, lunettes fines."
    narrator "Elle prend des notes sans regarder sa feuille. Ses yeux, eux, parcourent les rangées."
    pensee "On dirait qu'elle compte. Ou qu'elle cherche quelqu'un."
    isa "Mademoiselle Lambert, mon assistante, vous remettra vos emplois du temps. Elle a les clés de tout ce qui ferme à Valcourt."
    isa "Faites en sorte de ne jamais avoir à lui demander une clé que vous n'êtes pas censés avoir."
    foule "{i}(rires nerveux){/i}"

    hide isabella
    hide eleonore
    with fondu

    ## ---------------------------------------------------------------------
    ## Clara
    ## ---------------------------------------------------------------------
    scene bg couloir with fondu
    $ ambiance(None, canal="ambiance")
    $ poser_heure("LUNDI · 11 H 40")
    $ musique_jouer("quotidien")

    narrator "La résidence est un ancien couvent : des couloirs trop longs, des portes trop lourdes, des plafonds qui font écho."
    narrator "Je cherche la chambre 214 quand une avalanche de crayons de couleur roule jusqu'à mes chaussures."

    show clara surprise at centre, sursaut
    $ son("crayons")
    $ rencontrer("clara")
    c "Oh non, non, non… Pardon ! Ils… ils s'échappent toujours, je ne sais pas comment ils font."
    narrator "Une fille à lunettes rondes est accroupie au milieu du couloir, un carnet serré contre elle, les joues écarlates."

    menu:
        "M'accroupir pour l'aider à les ramasser.":
            narrator "Je m'agenouille et je ramasse le bleu de Prusse, l'ocre, trois gris différents."
            show clara timide
            c "Merci… Personne ne s'arrête, d'habitude. Ils enjambent."
            moi "Les crayons ou toi ?"
            show clara sourire
            c "Les deux, je crois."
            $ lien("clara", 1)
        "Regarder le carnet ouvert qu'elle a laissé tomber.":
            narrator "Le carnet est ouvert sur une aquarelle : le portail de l'Académie, à l'aube, avec la devise à moitié dans la brume."
            moi "C'est toi qui as fait ça ? C'est… on dirait une photo de rêve."
            show clara timide
            c "C'est juste un croquis. Je l'ai fait ce matin, en attendant que la résidence ouvre."
            c "Personne ne regarde jamais mes dessins. Enfin. Si. Mes parents. Pour me dire que ce n'est pas un métier."
            $ lien("clara", 1)
            $ noter("vu_carnet_clara")
        "Lui dire de faire attention, je cherche ma chambre.":
            show clara triste
            c "Oui. Pardon. Je… je me pousse."
            narrator "Elle se colle au mur, ramasse ses crayons un par un. J'ai l'impression d'avoir marché sur quelque chose de fragile."
            $ varier(moral=-1)

    show clara normal
    c "Je suis Clara. Clara Morel. Arts et lettres. Chambre 216."
    moi "[joueur_nom]. Chambre 214. On est voisins, alors."
    show clara sourire
    c "Voisins. D'accord. C'est bien. C'est… très bien, même."
    c "Je ne connais personne, ici. Mes parents ont choisi Valcourt parce que « c'est un nom qui ouvre des portes »."
    c "Moi, je voulais juste un endroit avec de la lumière pour peindre."
    $ souvenir("Ma rencontre avec Clara, ses crayons éparpillés dans le couloir.", "clara sourire")
    hide clara with fondu

    ## ---------------------------------------------------------------------
    ## Le premier cours de Dorian Varga
    ## ---------------------------------------------------------------------
    scene bg classe with fondu
    $ poser_heure("LUNDI · 14 H 00")
    $ musique_jouer("mystere")

    narrator "Le cours d'introduction au droit pénal est obligatoire pour toutes les filières. « Pour que chacun sache ce qu'il risque », dit le programme."

    show dorian normal at centre with fondu
    $ rencontrer("dorian")
    narrator "Le professeur entre sans un mot, pose une sacoche en cuir sur le bureau, et nous observe un long moment."
    d "Dorian Varga. Oui, comme la directrice. Non, cela ne vous servira à rien."
    d "Je vais vous poser une seule question aujourd'hui. Ceux qui ne savent pas y répondre n'ont pas regardé où ils sont entrés ce matin."
    d "Quelle est la devise de Valcourt ?"

    $ reponse = saisie("Quelle est la devise de Valcourt ?", indice="Elle est gravée au-dessus du portail.")
    $ n_mots = sum(1 for g in (["veritas", "verite"], ["justitia", "justice"], ["libertas", "liberte"]) if mentionne(reponse, g))

    if n_mots == 3:
        show dorian pensif
        d "Veritas, Justitia, Libertas. Au moins une personne a des yeux."
        d "Retenez l'ordre. Ce n'est pas un hasard : sans vérité, il n'y a pas de justice. Et sans justice, la liberté n'est qu'un mot."
        $ lien("dorian", 1)
        $ noter("devise_connue")
    elif n_mots >= 1:
        d "Presque. Il en manque. Veritas, Justitia, Libertas."
        d "Une vérité incomplète, en droit, c'est un mensonge qui a bien réussi."
        $ noter("devise_connue")
    else:
        d "Non."
        d "Veritas, Justitia, Libertas. Écrivez-le. Vous ne l'oublierez plus."
        $ noter("devise_connue")

    show dorian normal
    d "Deux choses pour votre agenda, puisque vous semblez tous en avoir un."
    d "Mercredi, dix heures : devoir surveillé de méthodologie. Coefficient trois. Pour les boursiers, il pèse lourd."
    d "Vendredi, neuf heures : oral individuel. Vous défendrez une cause que je vous attribuerai. Je ne fais pas d'exception, ni pour les malades, ni pour les héros."
    $ noter_journal("ds", "Devoir surveillé de méthodologie (coefficient 3).", "Mercredi, 10 h")
    $ noter_journal("oral", "Oral individuel de Dorian Varga.", "Vendredi, 9 h")
    pensee "Coefficient trois. Sous réserve d'une moyenne de 10/20. Les deux phrases tournent dans ma tête comme des mouches."
    $ souvenir("Le premier cours de Dorian Varga. Veritas, Justitia, Libertas.", "dorian normal")
    hide dorian with fondu

    ## ---------------------------------------------------------------------
    ## Iris et le marque-page
    ## ---------------------------------------------------------------------
    scene bg bibliotheque with fondu
    $ poser_heure("LUNDI · 17 H 25")
    $ musique_jouer("boucle")
    $ ambiance("horloge")

    narrator "La bibliothèque de Valcourt est une cathédrale de livres. Des échelles roulantes, des lampes vertes, un silence épais comme du velours."
    narrator "Je choisis une table au fond, près d'une fenêtre qui donne sur le port."

    show iris normal at centre with fondu
    $ rencontrer("iris")
    if persistent.parties >= 1:
        pensee "Cette bibliothèque… J'ai l'étrange impression d'être déjà {g=venu/venue} ici. Plusieurs fois."
    ir_inconnue "Tu as encore choisi la table du fond."
    narrator "Je lève la tête. Une étudiante aux longs cheveux noirs me regarde comme on regarde quelqu'un qu'on connaît depuis longtemps."
    moi "Encore ? On s'est déjà vus ?"
    ir_inconnue "…"
    ir_inconnue "Non. Pardon. Je confonds. Je m'appelle Iris. Iris Delaunay. Troisième année, chimie. Et la Gazette, quand j'ai le temps."
    ir "Tu es {g=le/la} {g=boursier/boursière} de cette année. [joueur_nom], c'est ça ?"
    moi "Comment tu sais mon prénom ?"
    ir "Je sais beaucoup de choses. C'est mon défaut. Et ma seule qualité."

    if deja_vu("ariane"):
        pensee "Un mot me monte aux lèvres, venu de nulle part. Un nom de labyrinthe."
        menu:
            "Murmurer : « Ariane. »":
                show iris normal at centre, tremble
                ir "…"
                ir "Qu'est-ce que tu as dit ?"
                moi "Ariane. Je ne sais pas pourquoi. Il est venu tout seul."
                ir "Tu te souviens. Pas de tout, mais de ça. Alors le Livre ne t'a pas tout repris."
                ir "Écoute-moi bien. Mercredi soir, ne me laisse pas seule. Quoi qu'il arrive, quoi que je dise."
                $ noter("iris_alliee_tot")
                $ lien("iris", 3)
                $ souvenir("Dès le premier jour, j'ai murmuré « Ariane » à Iris. Elle a compris.", "iris normal")
            "Garder ce mot pour moi.":
                pass
    narrator "Elle sort de sa poche un objet qui brille sous la lampe : un marque-page en laiton, fin comme une lame, gravé d'un chêne."
    show marque_page at Transform(xalign=0.5, yalign=0.4, zoom=0.7) with fondu
    ir "Tiens. Garde-le. Quoi qu'il arrive, ne le perds pas."
    moi "Pourquoi moi ?"
    ir "Parce que tu es là. Parce que tu as choisi la table du fond. Parce que…"
    ir "Disons que j'ai un pressentiment."

    menu:
        "Prendre le marque-page.":
            hide marque_page with fondu
            narrator "Le métal est tiède, comme s'il venait d'être tenu longtemps. Je le glisse dans mon carnet."
            $ noter("marque_page")
            $ donner("marque_page")
            $ lien("iris", 1)
            ir "Merci."
            narrator "Elle a l'air soulagée. Vraiment soulagée, comme si je venais de lui rendre quelque chose."
            ir "On se reverra. Plus vite que tu ne le crois."
            $ souvenir("Iris m'a confié un marque-page en laiton : « Ne le perds pas. »", "iris normal")
        "Refuser poliment.":
            hide marque_page with fondu
            moi "C'est gentil, mais je ne peux pas accepter un objet comme ça. On ne se connaît pas."
            show iris normal
            ir "…"
            ir "Pas cette fois, alors."
            narrator "Elle range le marque-page, et quelque chose s'éteint dans son regard. Pas de la vexation. De la fatigue."
            $ souvenir("J'ai refusé le marque-page d'Iris.", "iris normal")
            $ noter("refus_marque_page")
    hide iris with fondu
    narrator "Quand je relève les yeux de mon livre, elle a disparu entre les rayonnages."
    narrator "Je ne l'ai pas entendue partir."

    ## ---------------------------------------------------------------------
    ## Lundi soir : le premier choix d'emploi du temps
    ## ---------------------------------------------------------------------
    scene bg chambre with fondu
    $ ambiance(None)
    $ moment = "soir"
    $ poser_heure("LUNDI · 19 H 30")
    $ musique_jouer("quotidien")

    narrator "Ma chambre est minuscule : un lit, un bureau, une fenêtre sur les toits. Elle est à moi. C'est la première fois que j'ai une chambre à moi."
    narrator "La soirée est devant moi. Une seule. Et déjà, tout le monde en veut un morceau."

    narrator "Sur le bureau, le manuel de méthodologie est ouvert à la page que Dorian Varga a citée. {i}Devoir surveillé, mercredi, coefficient 3.{/i}"
    pensee "Coefficient trois. Pour {g=un_boursier/une_boursière}, une mauvaise note pèse comme une pierre."

    call sms("Maëlle", [("maelle", "Tu m'appelles ce soir ? Maman part travailler à 22 h, elle voudrait entendre ta voix avant.")], "Lundi, 19:34")
    $ recevoir("Maëlle", "Tu m'appelles ce soir ? Maman part travailler à 22 h.", "Lun. 19:34")

    $ son("porte")
    narrator "On frappe. Trois petits coups, presque timides."
    show clara timide at centre with fondu
    c "Pardon de te déranger… Je voulais juste te dire : depuis ma fenêtre, on voit tout le port. Le soleil se couche dessus, c'est…"
    c "Enfin. Si tu veux venir. Ce n'est pas obligé, hein. Vraiment pas."
    hide clara with fondu

    narrator "Par la fenêtre, j'aperçois en bas l'affiche de la cafétéria : {i}« Service du soir, étudiants bienvenus, 20 € »{/i}."
    narrator "Vingt euros. C'est une semaine de cafés. Ou un ticket de train pour rentrer voir Maman."
    pensee "Je ne peux pas tout faire. Qu'est-ce qui compte le plus, ce soir ?"

    $ choix = choisir_creneau("Lundi soir — 19 h 30", [
        ("reviser", "Réviser", "Le devoir de mercredi compte triple. Plus j'avance ce soir, moins j'aurai peur mercredi.", {"etudes": 1, "energie": -1}, True, "", "gui/icone_etudes.png"),
        ("clara", "Le port avec Clara", "Elle a frappé à ma porte. Elle n'a sûrement frappé chez personne d'autre.", {"moral": 1, "energie": -1}, True, "", "medaillons/clara/timide.png"),
        ("maelle", "Appeler Maëlle et Maman", "Maman part à 22 h. Elle voudrait entendre ma voix avant sa nuit de travail.", {"moral": 2}, True, "", "medaillons/maelle/normal.png"),
        ("cafeteria", "Servir à la cafétéria", "Vingt euros la soirée. L'argent de la bourse ne durera pas toute la semaine.", {"argent": 20, "energie": -2}, True, "", "gui/icone_argent.png"),
    ], "Qu'est-ce qui compte le plus, ce soir ?")

    if choix == "reviser":
        narrator "Je révise jusqu'à ce que les mots se mélangent. Syllogisme judiciaire, charge de la preuve, présomption d'innocence."
        narrator "{i}Toute personne est présumée innocente jusqu'à ce que sa culpabilité ait été établie.{/i} Je souligne la phrase deux fois, sans savoir pourquoi."
        $ revisions += 1
        $ varier(etudes=1, energie=-1)
        narrator "À travers le mur, j'entends Clara fredonner. Puis plus rien."
    elif choix == "clara":
        scene bg chambre clara with fondu
        $ musique_jouer("clara")
        show clara sourire at centre with fondu
        c "Tu es venu{g=/e} ! Regarde. D'ici, on voit tout le port."
        narrator "Par la fenêtre, les grues du port découpent le ciel orange. Un cargo bleu glisse sur l'eau, sans bruit."
        show clara pensif
        c "Mes parents disent que je suis ici pour devenir avocate. Moi, je crois que je suis ici pour avoir peur à plein temps."
        c "Peur de rater. Peur de décevoir. Peur qu'ils aient raison."
        if empathie_possible():
            menu:
                "« Tu as le droit d'avoir peur. Ça ne veut pas dire qu'ils ont raison. »":
                    show clara timide
                    c "…Personne ne m'a jamais dit ça comme ça."
                    $ lien("clara", 1)
                "« Moi aussi, j'ai peur. Ma mère travaille la nuit pour que je sois ici. »":
                    show clara triste
                    c "Alors on a peur ensemble. C'est moins lourd à deux, non ?"
                    $ lien("clara", 1)
                    $ noter("confidence_famille")
        else:
            narrator "Je voudrais trouver quelque chose à dire. Les mots ne viennent pas."
        narrator "On reste à la fenêtre jusqu'à ce que les lumières du port s'allument une à une."
        $ varier(moral=1, energie=-1)
    elif choix == "maelle":
        narrator "Maëlle décroche à la première sonnerie."
        ma "Alors ? Raconte tout. La directrice, les profs, les gens. Tu t'es fait des amis ?"
        moi "Une voisine qui dessine. Une fille bizarre qui m'a offert un marque-page. Un prof qui fait peur."
        ma "C'est un bon début. Maman dort, elle commence à vingt-deux heures ce soir."
        ma "Elle fait encore les nuits à la blanchisserie de l'hôpital. Elle dit que ça ne la dérange pas. Elle ment très mal."
        moi "Je sais."
        ma "Alors tiens bon. Pour elle."
        $ cocher("appeler_maelle")
        $ varier(moral=2)
    else:
        scene bg cantine with fondu
        $ ambiance("salle")
        narrator "Quatre heures à empiler des plateaux, essuyer des tables et sourire à des gens qui ne me voient pas."
        show lucas normal at centre with fondu
        $ rencontrer("lucas")
        lu "T'es {g=nouveau/nouvelle} ? Moi c'est Lucas. Je bosse ici le lundi pour payer mes crampons."
        lu "Fais gaffe à Hugo, mon coloc. Il traîne avec des gens bizarres depuis la rentrée. Il dit qu'il a trouvé « un truc pour tenir le rythme »."
        pensee "Un truc pour tenir le rythme. Je range l'information quelque part dans un coin de ma tête."
        $ noter("piste_hugo_tot")
        hide lucas with fondu
        $ varier(argent=20, energie=-2)

    ## ---------------------------------------------------------------------
    ## Nuit
    ## ---------------------------------------------------------------------
    scene bg chambre nuit with noir
    $ moment = "nuit"
    $ poser_heure("LUNDI · 23 H 48")
    $ musique_jouer("boucle")
    narrator "Je m'endors avec la fenêtre entrouverte et le bruit lointain du port."
    if fait("marque_page"):
        narrator "Dans mon carnet, posé sur la table de nuit, le marque-page en laiton brille faiblement."
        narrator "Je pourrais jurer qu'il est encore tiède."

    ## Pendant ce temps…
    scene bg reserve with glissement
    show grain
    $ ambiance("horloge")
    narrator "{i}Pendant ce temps, dans la réserve de la bibliothèque, une lampe reste allumée bien après la fermeture.{/i}"
    show iris normal at centre with fondu
    narrator "{i}Iris est assise devant un vieux livre à la reliure dorée. Elle ne lit pas. Elle compte les pages.{/i}"
    ir "Plus que trois."
    ir "Cette fois, je ne me tromperai pas de personne."
    hide iris with fondu
    scene black with noir_long
    $ ambiance(None)

    call resume_jour("Lundi")
    $ energie = borner(energie + 5)
    jump mardi
