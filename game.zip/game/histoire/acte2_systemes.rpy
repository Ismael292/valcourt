## Acte II — « Le Capitaine » : personnages, preuves, objets, jours et carte.
##
## Les jours de l'Acte II portent des numéros à part (11 = jeudi 16 octobre,
## 17 = mercredi 22) pour que les souvenirs, la cinématique « Ce jour-là » et le
## récit final ne les confondent pas avec la semaine de l'Acte I.

default acte = 1
default echeance_carte = "avant l'audience"
default gazette_nom = ""
default revisions_partiels = 0
default creneau2_idx = 0
default montre_a_malo2 = set()

################################################################################
## Nouvelles voix
################################################################################

define hal = Character("Henri Halvard", image="halvard", who_color="#8fa6c9")
define fe = Character("Commissaire Ferrière", image="ferriere", who_color="#b9a98c")
define fe_inconnu = Character("Un homme en imperméable", image="ferriere", who_color="#b9a98c")
define mam = Character("Maman", image="maman", who_color="#e0a98f")
define infirmiere = Character("L'infirmière", who_color="#a9c4c0")
define employe_port = Character("L'agent de la capitainerie", who_color="#9fb0c0")

init 1 python:

    JOURS.update({11: "Jeudi", 12: "Vendredi", 13: "Samedi", 14: "Dimanche", 15: "Lundi", 16: "Mardi", 17: "Mercredi"})
    DATES.update({11: "16 octobre", 12: "17 octobre", 13: "18 octobre", 14: "19 octobre", 15: "20 octobre",
                  16: "21 octobre", 17: "22 octobre"})

    PREUVES.update({
        "capitainerie": dict(
            nom="Registre de la capitainerie",
            image="preuves/capitainerie.png",
            desc="Quai 7 : l'Ondine, un navire de la compagnie Halvard Maritime, appareille chaque jeudi vers 23 h. Jamais inspectée.",
            detail="Les inspections des douanes sont levées « sur réquisition du commissariat central ». Le tampon est celui de la police, pas celui de l'armateur.",
        ),
        "carnet_pere": dict(
            nom="Carnet de Papa",
            image="preuves/carnet_pere.png",
            desc="Le carnet de docker de mon père, mort en 2018 au quai 7. Maman le gardait dans une boîte à chaussures.",
            detail="« Le Capitaine n'est pas un marin. Il ne monte jamais à bord. Il a les clés du port comme d'autres celles d'une école. »",
        ),
        "toxico": dict(
            nom="Rapport de toxicologie",
            image="preuves/toxico.png",
            desc="Éléonore Lambert a avalé une dose massive d'un sédatif à usage hospitalier, en garde à vue.",
            detail="Ingestion entre 21 h et 22 h, dans sa cellule. À cette heure-là, seuls des policiers avaient accès au sous-sol du commissariat.",
        ),
        "photo_gala": dict(
            nom="Photo du gala de la Fondation",
            image="preuves/photo_gala.png",
            desc="Archives de la Gazette, l'an dernier : Henri Halvard entre Isabella Varga et un homme vu de dos.",
            detail="Agrandie : l'homme de dos porte une chevalière gravée d'une ancre. Halvard lui serre la main en baissant les yeux, comme un employé devant son patron.",
        ),
        "lettre_brulee": dict(
            nom="Lettre à demi brûlée",
            image="preuves/lettre_anonyme.png",
            desc="Ramassée dans le jardin de la villa Halvard, au bord d'un brasero.",
            detail="« …jeudi, comme d'habitude. Sinon la Fondation apprendra d'où vient son argent. — C. » Halvard ne commande pas. Il obéit.",
        ),
    })

    OBJETS.update({
        "billet": dict(nom="Billet de train", image="objets/billet.png",
                       desc="Valcourt – Saint-Aubin, aller-retour. Deux heures de train jusqu'à la maison."),
        "photo_pere": dict(nom="Photo de Papa", image="objets/photo_pere.png",
                           desc="Papa au quai 7, en 2017, un an avant l'« accident ». Il sourit au photographe. J'ai ses yeux, dit Maman."),
        "carte_presse": dict(nom="Carte de presse de la Gazette", image="objets/badge.png",
                             desc="Prêtée par Amélie. « Rédaction de la Gazette de Valcourt. » Elle ouvre plus de portes qu'une carte d'étudiant."),
    })

    FICHES.extend([
        dict(tag="halvard", nom="Henri Halvard", age="61 ans", role="Armateur, président de la Fondation de Valcourt",
             texte=[(None, "Ancien capitaine devenu armateur. Premier donateur de l'Académie. Sa compagnie possède l'Ondine, le « bateau bleu »."),
                    ("halvard_peur", "Il n'a pas l'air d'un homme qui commande. Il a l'air d'un homme qui a peur.")]),
        dict(tag="ferriere", nom="Paul Ferrière", age="58 ans", role="Commissaire divisionnaire, supérieur de Malo",
             texte=[(None, "Trente ans de maison. Paternel, courtois, respecté. C'est lui qui a appris le métier à Malo."),
                    ("chevaliere_vue", "Il porte une chevalière gravée d'une ancre. Curieux, pour un policier.")]),
        dict(tag="maman", nom="Maman", age="52 ans", role="Blanchisseuse de nuit à l'hôpital de Saint-Aubin",
             texte=[(None, "Elle travaille la nuit pour que j'étudie le jour. Elle ne se plaint jamais."),
                    ("verite_papa", "Elle m'avait caché la vérité sur Papa : docker au quai 7 de Valcourt, mort en 2018.")]),
    ])
    for _f in FICHES:
        if _f["tag"] == "iris":
            _f["texte"].append(("acte2", "Vivante. Elle n'avait pas vu de jeudi depuis des mois. Le Livre lui a pris des choses : elle ne dit pas lesquelles."))
        if _f["tag"] == "eleonore":
            _f["texte"].append(("eleonore_coma", "Empoisonnée dans sa cellule, la nuit de son arrestation. Dans le coma."))
        if _f["tag"] == "malo":
            _f["texte"].append(("malo_ecarte", "Son supérieur l'a retiré de l'affaire : « trop proche des étudiants »."))

################################################################################
## Fin d'un acte
################################################################################

screen carte_acte(numero, titre, phrase, suivant="", suivant_titre=""):
    modal True
    add Solid("#0b0907")
    add "gui/vignette.png"
    vbox at titre_apparition:
        xalign 0.5 yalign 0.42
        spacing 14
        text ("Acte %s · terminé" % ("I" * numero)) font F_MACHINE size 22 color DOUX xalign 0.5 kerning 4
        text titre.upper() font F_TITRE size 66 color LAITON_CLAIR xalign 0.5 kerning 8 text_align 0.5
        add "gui/filet.png" xalign 0.5 at filet_trace
        text phrase font F_DISPLAY_IT size 30 color "#cbbfa8" xalign 0.5 text_align 0.5 xsize 900
        if suivant:
            null height 60
            text suivant font F_MACHINE size 20 color DOUX xalign 0.5 kerning 4
            text suivant_titre.upper() font F_TITRE size 44 color PAPIER xalign 0.5 kerning 8
    text "Cliquez pour continuer." font F_MACHINE size 15 color DOUX xalign 0.5 yalign 0.95
    key "dismiss" action Return()

screen a_suivre(titre, phrase):
    modal True
    add Solid("#0b0907")
    add "gui/vignette.png"
    vbox at titre_apparition:
        xalign 0.5 yalign 0.45
        spacing 14
        text "À SUIVRE" font F_MACHINE size 22 color DOUX xalign 0.5 kerning 6
        text titre.upper() font F_TITRE size 56 color PAPIER xalign 0.5 kerning 8 text_align 0.5
        add "gui/filet.png" xalign 0.5 at filet_trace
        text phrase font F_DISPLAY_IT size 28 color "#cbbfa8" xalign 0.5 text_align 0.5 xsize 900
        null height 20
        text "La partie est sauvegardée automatiquement : vous la retrouverez dans « Charger »." font F_CORPS size 18 color DOUX xalign 0.5
    key "dismiss" action Return()

################################################################################
## La carte du week-end (vendredi après-midi → dimanche soir)
################################################################################

define CRENEAUX2 = [
    (12, "après-midi", "VENDREDI · 14 H 00"),
    (12, "soir", "VENDREDI · 19 H 30"),
    (13, "matin", "SAMEDI · 09 H 00"),
    (13, "après-midi", "SAMEDI · 14 H 00"),
    (13, "soir", "SAMEDI · 19 H 00"),
    (13, "nuit", "SAMEDI · 23 H 00"),
    (14, "matin", "DIMANCHE · 09 H 30"),
    (14, "après-midi", "DIMANCHE · 14 H 00"),
    (14, "soir", "DIMANCHE · 19 H 00"),
]

## Créneau où l'on revient de la maison (dimanche après-midi).
define RETOUR_MAISON = 7

init 1 python:

    def lieux_acte2():
        """(code, nom, vignette, note, disponible) pour le créneau courant de l'Acte II."""
        j, mo = store.jour, store.moment
        L = []
        if j == 12 and mo == "après-midi":
            L.append(("cours", "Aller en cours", "images/bg/bg classe.jpg", "Les partiels sont lundi. La moyenne compte encore.", True))

        gare_ok = j == 13 and mo in ("matin", "après-midi") and not fait("rentre_maison")
        gare_note = "Train de %s. Anniversaire de Maman demain." % ("9 h 12" if mo == "matin" else "14 h 05") if gare_ok else \
            ("Les trains pour Saint-Aubin partent samedi." if j == 12 else "Plus de train utile.")
        L.append(("gare", "Gare — rentrer à la maison", "images/bg/bg gare.jpg", gare_note, gare_ok))

        L.append(("hopital", "Hôpital", "images/bg/bg hopital.jpg",
                  "Hugo. Et Éléonore, sous bonne garde." if mo != "nuit" else "Visites terminées.", mo != "nuit"))

        cap_ok = mo in ("matin", "après-midi") and j != 14
        L.append(("capitainerie", "Capitainerie du port", "images/bg/bg capitainerie.jpg",
                  "Les registres des navires." if cap_ok else ("Fermée le dimanche." if j == 14 else "Ouverte en journée."), cap_ok))

        villa_jour = mo in ("après-midi",) and j in (13, 14)
        villa_nuit = mo in ("soir", "nuit") and store.temperament == "audacieux" and j == 13
        villa_note = "Henri Halvard reçoit, parfois." if villa_jour else ("La nuit, le parc n'est pas gardé. (audace)" if villa_nuit else "Halvard reçoit le week-end, l'après-midi.")
        L.append(("villa", "Villa Halvard", "images/bg/bg villa.jpg", villa_note, villa_jour or villa_nuit))

        L.append(("redaction", "Café du port — la Gazette", "images/bg/bg redaction.jpg",
                  "La rédaction clandestine se réunit ici." if mo != "nuit" else "Fermé.", mo != "nuit"))

        L.append(("commissariat2", "Commissariat", "images/bg/bg commissariat.jpg",
                  "Malo, s'il est encore sur l'affaire.", True))

        biblio_ok = mo != "nuit" or possede("marque_page")
        L.append(("bibliotheque2", "Bibliothèque", "images/bg/bg bibliotheque.jpg",
                  "Mme Bernier, le Livre, les révisions." if mo != "nuit" else ("Le marque-page est tiède…" if biblio_ok else "Fermée la nuit."), biblio_ok))

        L.append(("chambre2", "Chambre", "images/bg/bg chambre.jpg", "Dormir, réviser, appeler la maison.", True))
        return L

    def pistes_acte2():
        if store.jour >= 15:
            return pistes_acte2b()
        P = []
        if store.jour == 13 and store.moment in ("matin", "après-midi") and not fait("rentre_maison"):
            P.append(("Gare", "Demain, c'est l'anniversaire de Maman. Deux heures de train. (18 €)"))
        if not fait("hopital_visite"):
            P.append(("Hôpital", "Éléonore a été empoisonnée en cellule. Qui pouvait l'approcher ?"))
        elif not a("toxico"):
            P.append(("Hôpital", "Le rapport de toxicologie dirait quand et comment. Malo, ou un œil de scientifique, pourrait aider."))
        if not a("capitainerie"):
            P.append(("Capitainerie", "Le bateau bleu doit bien être inscrit quelque part. À qui appartient-il ?"))
        if not fait("halvard_vu"):
            P.append(("Villa Halvard", "Henri Halvard ferme la Gazette, et son nom est partout. Trop partout ?"))
        if not a("photo_gala"):
            P.append(("Café du port", "Amélie fouille les archives de la Gazette. Le Capitaine a peut-être déjà été photographié."))
        if (a("capitainerie") or a("toxico") or a("photo_gala")) and not fait("malo_reconnait"):
            P.append(("Commissariat", "Malo devrait voir ce que j'ai trouvé. Même s'il ne va pas aimer."))
        if not fait("livre_page_vue") and possede("marque_page"):
            P.append(("Bibliothèque", "Le marque-page refroidit. Mme Bernier saura ce que le Livre a pris."))
        if store.revisions_partiels < 2:
            P.append(("Chambre / Bibliothèque", "Partiels lundi : %d séance%s de révision seulement." % (store.revisions_partiels, "" if store.revisions_partiels == 1 else "s")))
        if fatigue():
            P.append(("Chambre", "Je suis à bout. Fatigué{}, je vais rater des choses.".format(accord("", "e"))))
        return P[:5]
