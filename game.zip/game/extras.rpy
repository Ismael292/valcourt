## extras.rpy — galerie des fins, scènes vidéo, musique, chapitres, crédits.

define CREDITS = [
    ("Histoire, programmation et mise en scène", ["Projet Valcourt"]),
    ("Personnages et décors principaux", ["Illustrations originales du projet (Clara, Iris, Isabella et Dorian Varga, Éléonore Lambert, Malo Deschamps, tribunal, Académie)"]),
    ("Décors complémentaires", ["Uncle Mugen — alte.itch.io (libres de droits)"]),
    ("Personnages secondaires", ["Breezy — breezy-the-cat.itch.io (CC0)", "4cher — 4cher.itch.io (CC-BY 4.0)", "Fülli — fuelli.itch.io (CC-BY)"]),
    ("Musique", ["Kevin MacLeod — incompetech.com", "Sous licence Creative Commons : By Attribution 4.0", "Potat0Master — potat0master.itch.io (libre de droits)"]),
    ("Bruitages", ["Sons d'ambiance et bruitages synthétisés pour le jeu"]),
    ("Voix du narrateur", ["Piper TTS (licence MIT) — voix « tom », fr_FR (CC-BY 4.0)"]),
    ("Polices", ["Cinzel, Cormorant Garamond, Lora, Caveat — SIL Open Font License", "Special Elite — Apache License 2.0"]),
]

define VIDEOS = [
    ("ouverture", "L'histoire de Valcourt", "La ville, l'Académie, le Livre."),
    ("intro", "Le générique", "Sept jours plus tôt."),
    ("bal", "Le bal d'automne", "Mardi soir, la musique s'arrête."),
    ("drame", "La nuit du laboratoire", "Mercredi, 22 h 50."),
    ("audience", "L'audience", "Samedi, la porte s'ouvre."),
    ("boucle", "Le Livre", "Écrivez votre nom."),
    ("aube", "L'aube", "Le dernier matin."),
]

define CHAPITRES = [
    ("depart_lundi", "Lundi — La rentrée", None),
    ("depart_mercredi", "Mercredi — La nuit du laboratoire", None),
    ("depart_enquete", "Jeudi — L'enquête", None),
    ("depart_audience", "Samedi — L'audience", None),
    ("depart_boucle", "Mercredi, encore", "veritas"),
    ("depart_acte2", "Acte II — Le Capitaine", "sept_jours"),
]

init python:
    musique = MusicRoom(fadeout=1.0)
    PISTES = [
        ("audio/musique/theme.ogg", "Valcourt (thème)"),
        ("audio/musique/quotidien.ogg", "Une rentrée"),
        ("audio/musique/clara.ogg", "Clara"),
        ("audio/musique/mystere.ogg", "Ce que cache l'Académie"),
        ("audio/musique/tension.ogg", "Quelqu'un ment"),
        ("audio/musique/nuit.ogg", "La nuit du laboratoire"),
        ("audio/musique/enquete.ogg", "Enquête"),
        ("audio/musique/tribunal.ogg", "L'audience"),
        ("audio/musique/objection.ogg", "La contradiction"),
        ("audio/musique/tristesse.ogg", "Ce qui ne revient pas"),
        ("audio/musique/boucle.ogg", "Le Livre des Sept Jours"),
        ("audio/musique/espoir.ogg", "L'aube"),
    ]
    for f, _t in PISTES:
        musique.add(f, always_unlocked=False)

screen extras():
    tag menu
    default onglet = "fins"

    use game_menu("Extras", scroll="viewport"):
        vbox:
            spacing 18
            hbox:
                spacing 10
                textbutton "Fins" style "onglet" action SetScreenVariable("onglet", "fins") selected onglet == "fins"
                textbutton "Scènes vidéo" style "onglet" action SetScreenVariable("onglet", "videos") selected onglet == "videos"
                textbutton "Musique" style "onglet" action SetScreenVariable("onglet", "musique") selected onglet == "musique"
                textbutton "Chapitres" style "onglet" action SetScreenVariable("onglet", "chapitres") selected onglet == "chapitres"

            if onglet == "fins":
                text "Fins découvertes : %d / %d" % (len(persistent.fins or ()), len(FINS)) style "texte_machine"
                for code, titre, resume in FINS:
                    hbox:
                        spacing 20
                        add ("gui/sceau.png" if fin_obtenue(code) else "gui/sceau_vide.png") zoom 0.5 yalign 0.5
                        vbox:
                            yalign 0.5
                            if fin_obtenue(code):
                                text titre font F_DISPLAY size 32 color LAITON_CLAIR
                                text resume style "texte_ui"
                                if persistent.films and code in persistent.films and export_possible():
                                    textbutton "Exporter le film de cette fin" style "onglet" action Show("proposer_film", code=code)
                            else:
                                text "Fin non découverte" font F_DISPLAY size 32 color "#6b604f"
                                text "Vos choix mènent ailleurs…" style "texte_doux"

            elif onglet == "videos":
                for code, titre, resume in VIDEOS:
                    $ vue = code in persistent.videos_vues
                    hbox:
                        spacing 18
                        textbutton (titre if vue else "Scène non découverte") style "bouton_ui" xsize 380 action Function(renpy.movie_cutscene, "movies/%s.webm" % code) sensitive vue
                        text (resume if vue else "") style "texte_doux" yalign 0.5

            elif onglet == "musique":
                for f, titre in PISTES:
                    textbutton titre style "onglet" action musique.Play(f)
                null height 10
                hbox:
                    spacing 10
                    textbutton "Arrêter" style "bouton_ui" action musique.Stop()

            else:
                if not persistent.fini_une_fois:
                    text "Terminez une première partie pour débloquer la sélection de chapitre." style "texte_doux"
                else:
                    for etiquette, titre, besoin in CHAPITRES:
                        textbutton titre style "bouton_ui" xsize 520 action Start(etiquette) sensitive (besoin is None or fin_obtenue(besoin))

