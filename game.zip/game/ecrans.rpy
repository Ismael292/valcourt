## ecrans.rpy — les écrans propres à Valcourt (dossier, saisie libre, carte,
## téléphone, titres de jour, notes de relation…). Les écrans standard de
## Ren'Py (dialogue, menus, sauvegarde) sont dans screens.rpy.

################################################################################
## Couleurs et polices
################################################################################

define ENCRE = "#16130f"
define PAPIER = "#efe6d4"
define LAITON = "#c9a45c"
define LAITON_CLAIR = "#f0d79a"
define SANG = "#b4503f"
define AZUR = "#7fa9d6"
define DOUX = "#a89a83"

define F_TITRE = "fonts/Cinzel-Bold.ttf"
define F_TITRE_REG = "fonts/Cinzel-Regular.ttf"
define F_DISPLAY = "fonts/Cormorant-SemiBold.ttf"
define F_DISPLAY_IT = "fonts/Cormorant-Italic.ttf"
define F_CORPS = "fonts/Lora-Regular.ttf"
define F_MACHINE = "fonts/SpecialElite.ttf"
define F_MAIN = "fonts/Caveat-Regular.ttf"

init python:
    config.font_replacement_map["fonts/Lora-Regular.ttf", True, False] = ("fonts/Lora-Bold.ttf", False, False)
    config.font_replacement_map["fonts/Lora-Regular.ttf", False, True] = ("fonts/Lora-Italic.ttf", False, False)
    config.font_replacement_map["fonts/Lora-Regular.ttf", True, True] = ("fonts/Lora-BoldItalic.ttf", False, False)
    config.font_replacement_map["fonts/Cormorant-SemiBold.ttf", False, True] = ("fonts/Cormorant-Italic.ttf", False, False)
    config.font_replacement_map["fonts/Cormorant-SemiBold.ttf", True, False] = ("fonts/Cormorant-Bold.ttf", False, False)

style narration is say_dialogue:
    color "#e9dfcb"

style pensee is say_dialogue:
    italic True
    color "#cbbfa8"

style fenetre_livre is window:
    background None

style ecriture_livre is say_dialogue:
    font F_MAIN
    size 40
    color "#3a2a18"
    xpos 0
    xalign 0.5
    text_align 0.5

style panneau is frame:
    background Frame("gui/cadre.png", 26, 26)
    padding (34, 28)

style panneau_clair is frame:
    background Frame("gui/cadre_clair.png", 26, 26)
    padding (34, 28)

style etiquette_titre is text:
    font F_TITRE
    size 20
    color LAITON
    kerning 3.0

style texte_ui is text:
    font F_CORPS
    size 21
    color PAPIER

style texte_doux is texte_ui:
    color DOUX
    size 18

style texte_machine is text:
    font F_MACHINE
    size 18
    color DOUX

style bouton_ui is button:
    background Frame("gui/bouton_idle.png", 18, 18)
    hover_background Frame("gui/bouton_hover.png", 18, 18)
    selected_background Frame("gui/bouton_hover.png", 18, 18)
    insensitive_background Frame("gui/bouton_idle.png", 18, 18)
    padding (26, 12)
    hover_sound "audio/sons/survol.ogg"
    activate_sound "audio/sons/clic.ogg"

style bouton_ui_text is text:
    font F_DISPLAY
    size 24
    color "#dccfb6"
    hover_color LAITON_CLAIR
    selected_color LAITON_CLAIR
    insensitive_color "#6b604f"
    xalign 0.5
    text_align 0.5

################################################################################
## Note de relation (coin supérieur gauche)
################################################################################

screen note_relation(perso, texte, positif=True):
    zorder 150
    timer 3.6 action Hide("note_relation")
    frame at note_apparition:
        style "panneau"
        xpos 24 ypos 78
        padding (18, 12, 24, 12)
        hbox:
            spacing 14
            add ("gui/plume.png" if positif else "gui/plume_sombre.png") yalign 0.5 zoom 0.55
            text texte font F_DISPLAY_IT size 23 color (LAITON_CLAIR if positif else "#d9a99f") yalign 0.5

transform note_apparition:
    on show:
        alpha 0.0 xoffset -30
        easein .45 alpha 1.0 xoffset 0
    on hide:
        easeout .6 alpha 0.0

################################################################################
## Horodatage (coin supérieur droit)
################################################################################

default horodatage = ""

screen heure():
    zorder 40
    if horodatage:
        text horodatage at fondu_lent:
            font F_MACHINE size 20 color "#d6c9ae" outlines [(2, "#000000a0", 0, 0)]
            xalign 0.98 ypos 22

transform fondu_lent:
    on show:
        alpha 0.0
        linear 1.0 alpha 1.0
    on hide:
        linear .6 alpha 0.0

init python:
    def poser_heure(texte):
        store.horodatage = texte
        if texte:
            renpy.show_screen("heure")
        else:
            renpy.hide_screen("heure")

################################################################################
## Carte de titre d'un jour
################################################################################

screen titre_jour(numero, nom, date, sous_titre=""):
    zorder 200
    modal True
    add Solid("#0d0b09")
    add "gui/vignette.png"
    vbox at titre_apparition:
        xalign 0.5 yalign 0.46
        spacing 10
        text ("Jour %d" % numero if numero else "") font F_MACHINE size 22 color DOUX xalign 0.5 kerning 4
        text nom.upper() font F_TITRE size 84 color PAPIER xalign 0.5 kerning 10
        add "gui/filet.png" xalign 0.5 at filet_trace
        text date font F_DISPLAY_IT size 30 color LAITON xalign 0.5
        if sous_titre:
            null height 16
            text sous_titre font F_DISPLAY_IT size 26 color "#cbbfa8" xalign 0.5
    timer 3.4 action Return()
    key "dismiss" action Return()

transform titre_apparition:
    alpha 0.0 yoffset 14
    easein 1.1 alpha 1.0 yoffset 0

transform filet_trace:
    crop_relative True
    crop (0.0, 0.0, 0.0, 1.0)
    pause .5
    easein 1.0 crop (0.0, 0.0, 1.0, 1.0)

################################################################################
## Nouvelle preuve
################################################################################

screen nouvelle_preuve(code):
    zorder 180
    modal True
    $ p = PREUVES[code]
    add Solid("#000000b8") at fondu_rapide
    on "show" action Play("sound", "audio/sons/papier.ogg")
    frame at preuve_arrivee:
        style "panneau"
        xalign 0.5 yalign 0.45
        xsize 760
        has vbox
        spacing 16
        text "PIÈCE AJOUTÉE AU DOSSIER" style "etiquette_titre" xalign 0.5
        hbox:
            spacing 26
            frame:
                background Frame("gui/cadre_clair.png", 26, 26)
                padding (14, 14)
                yalign 0.5
                add p["image"] fit "contain" xysize (230, 230)
            vbox:
                spacing 10
                yalign 0.5
                xsize 420
                text p["nom"] font F_DISPLAY size 36 color LAITON_CLAIR
                text p["desc"] style "texte_ui"
        text "Le Dossier se consulte à tout moment (touche D)." style "texte_doux" xalign 0.5
    key "dismiss" action Return()

transform fondu_rapide:
    on show:
        alpha 0.0
        linear .3 alpha 1.0

transform preuve_arrivee:
    on show:
        alpha 0.0 zoom 0.94 rotate -2
        easein .45 alpha 1.0 zoom 1.0 rotate 0

################################################################################
## Le Dossier : preuves et personnages
################################################################################

default dossier_onglet = "preuves"
default dossier_choix = None

screen dossier(presenter=False, question=""):
    zorder 160
    modal True
    tag menu_dossier

    add Solid("#0b0907f0")
    add "gui/vignette.png"

    key "game_menu" action (Return(None) if presenter else Hide("dossier"))
    if not presenter:
        key "d" action Hide("dossier")

    frame:
        style "panneau"
        xalign 0.5 yalign 0.5
        xsize 1180 ysize 640
        padding (30, 22)

        vbox:
            spacing 14
            hbox:
                xfill True
                text ("PRÉSENTER UNE PREUVE" if presenter else "LE DOSSIER") font F_TITRE size 30 color LAITON kerning 4 yalign 0.5
                hbox:
                    xalign 1.0
                    spacing 10
                    if not presenter:
                        textbutton "Preuves" style "onglet" action SetVariable("dossier_onglet", "preuves") selected dossier_onglet == "preuves"
                        textbutton "Personnages" style "onglet" action SetVariable("dossier_onglet", "personnages") selected dossier_onglet == "personnages"
                        textbutton "Sac" style "onglet" action SetVariable("dossier_onglet", "sac") selected dossier_onglet == "sac"
                        textbutton "Journal" style "onglet" action SetVariable("dossier_onglet", "journal") selected dossier_onglet == "journal"
                    textbutton ("Annuler" if presenter else "Fermer") style "onglet" action (Return(None) if presenter else Hide("dossier"))
            if question:
                text question font F_DISPLAY_IT size 24 color "#d6c9ae"
            add "gui/filet_long.png" xalign 0.5

            if presenter or dossier_onglet == "preuves":
                use dossier_preuves(presenter)
            elif dossier_onglet == "personnages":
                use dossier_personnages()
            elif dossier_onglet == "sac":
                use dossier_sac()
            else:
                use dossier_journal()

style onglet is button:
    padding (16, 6)
    background None
    hover_background Frame("gui/bouton_hover.png", 18, 18)
    selected_background Frame("gui/bouton_idle.png", 18, 18)
    hover_sound "audio/sons/survol.ogg"
    activate_sound "audio/sons/clic.ogg"

style onglet_text is text:
    font F_DISPLAY
    size 24
    color DOUX
    hover_color LAITON_CLAIR
    selected_color LAITON_CLAIR

screen dossier_preuves(presenter):
    $ courant = dossier_choix if dossier_choix in preuves else (preuves[0] if preuves else None)
    hbox:
        spacing 26
        viewport:
            xsize 520 ysize 500
            scrollbars "vertical"
            mousewheel True
            vpgrid:
                cols 3
                spacing 14
                for code in preuves:
                    $ p = PREUVES[code]
                    button:
                        xysize (158, 178)
                        background Frame("gui/cadre_clair.png", 20, 20)
                        hover_background Frame("gui/cadre_clair_hover.png", 20, 20)
                        selected_background Frame("gui/cadre_clair_hover.png", 20, 20)
                        selected courant == code
                        hover_sound "audio/sons/survol.ogg"
                        action SetVariable("dossier_choix", code)
                        vbox:
                            xalign 0.5 yalign 0.5
                            spacing 4
                            add p["image"] fit "contain" xysize (120, 110) xalign 0.5
                            text p["nom"] font F_CORPS size 15 color "#3a2a18" xalign 0.5 text_align 0.5 layout "subtitle"
                if not preuves:
                    text "Aucune pièce pour l'instant." style "texte_doux"
        if courant:
            $ p = PREUVES[courant]
            vbox:
                xsize 560
                spacing 14
                hbox:
                    spacing 20
                    add p["image"] fit "contain" xysize (200, 200)
                    vbox:
                        yalign 0.5
                        spacing 8
                        text p["nom"] font F_DISPLAY size 38 color LAITON_CLAIR
                        if courant in preuves_examinees:
                            text "Examinée de près" style "texte_machine" color AZUR
                text p["desc"] style "texte_ui"
                if courant in preuves_examinees:
                    text p["detail"] style "texte_ui" color "#e8d3a2" italic True
                null height 8
                hbox:
                    spacing 14
                    if courant not in preuves_examinees:
                        textbutton "Examiner de près" style "bouton_ui" action [Function(examiner, courant), Play("sound", "audio/sons/papier.ogg")]
                    if presenter:
                        textbutton "Présenter cette preuve" style "bouton_ui" action Return(courant)

screen dossier_personnages():
    $ connues = [f for f in FICHES if fiche_connue(f)]
    viewport:
        ysize 500
        scrollbars "vertical"
        mousewheel True
        vbox:
            spacing 14
            for f in connues:
                hbox:
                    spacing 20
                    $ med = "medaillons/%s/normal.png" % f["tag"]
                    if renpy.loadable(med):
                        add med zoom 0.75 yalign 0.0
                    vbox:
                        xsize 900
                        spacing 4
                        hbox:
                            spacing 16
                            text f["nom"] font F_DISPLAY size 32 color LAITON_CLAIR
                            text f["age"] + " — " + f["role"] style "texte_machine" yalign 0.6
                        for condition, ligne in f["texte"]:
                            if condition is None or fait(condition):
                                text ligne style "texte_ui"
                add "gui/filet_long.png" alpha 0.4
            if not connues:
                text "Personne pour l'instant." style "texte_doux"

## Le Dossier s'ouvre aussi avec la touche D pendant le jeu.
init python:
    config.keymap["ouvrir_dossier"] = ["d", "D"]

    class OuvrirDossier(Action):
        def __call__(self):
            if renpy.get_screen("dossier") or store.main_menu or store.chapitre == "prologue":
                return
            renpy.show_screen("dossier")
            renpy.restart_interaction()

    config.underlay.append(renpy.Keymap(ouvrir_dossier=OuvrirDossier()))

################################################################################
## Saisie libre
################################################################################

screen saisie_libre(prompt, indice="", sujets=None, mode="parole"):
    zorder 170
    modal True
    style_prefix "saisie"
    add Solid("#00000088") at fondu_rapide

    frame at saisie_arrivee:
        xalign 0.5 yalign 0.62
        xsize 900
        has vbox
        spacing 14
        text ("VOUS ÉCRIVEZ" if mode == "ecrit" else "VOTRE RÉPONSE") style "etiquette_titre"
        text prompt font F_DISPLAY_IT size 30 color PAPIER
        frame:
            style "saisie_champ"
            hbox:
                spacing 10
                text "›" font F_DISPLAY size 34 color LAITON yalign 0.5
                input id "input" style "saisie_input" pixel_width 760 length 120
        if sujets:
            hbox:
                spacing 10
                text "Pistes :" style "texte_machine" yalign 0.5
                for s in sujets:
                    text s style "saisie_puce"
        if indice:
            text indice style "texte_doux" italic True
        text "Entrée pour valider. Accents et majuscules sont facultatifs." style "texte_machine" size 15

style saisie_frame is frame:
    background Frame("gui/cadre.png", 26, 26)
    padding (36, 26)

style saisie_champ is frame:
    background Frame("gui/champ.png", 14, 14)
    padding (16, 8)
    xfill True

style saisie_input is input:
    font F_CORPS
    size 28
    color "#fff4dc"
    caret "gui/curseur.png"

style saisie_puce is text:
    font F_CORPS
    size 17
    color AZUR

transform saisie_arrivee:
    on show:
        alpha 0.0 yoffset 24
        easein .35 alpha 1.0 yoffset 0

init python:
    def saisie(prompt, indice="", sujets=None, mode="parole", defaut=""):
        """Demande une réponse libre au joueur (toujours non vide)."""
        while True:
            r = renpy.input(prompt, default=defaut, screen="saisie_libre", indice=indice,
                            sujets=sujets, mode=mode).strip()
            if r:
                return r

################################################################################
## Téléphone : messages
################################################################################

screen telephone(contact, messages, heure=""):
    zorder 160
    modal True
    add Solid("#000000a0") at fondu_rapide
    fixed at telephone_arrivee:
        xysize (420, 700)
        xalign 0.5 yalign 0.5
        add "gui/telephone.png"
        vbox:
            xpos 36 ypos 64 xsize 348
            spacing 4
            text contact font F_DISPLAY size 28 color "#f2ece0" xalign 0.5
            if heure:
                text heure font F_MACHINE size 15 color "#9aa3ad" xalign 0.5
            null height 14
            for qui, texte in messages:
                if qui == "moi":
                    frame:
                        xalign 1.0 xmaximum 270
                        background Frame("gui/bulle_moi.png", 16, 16)
                        padding (14, 9)
                        text texte font F_CORPS size 18 color "#f7f2e8"
                else:
                    frame:
                        xalign 0.0 xmaximum 270
                        background Frame("gui/bulle_autre.png", 16, 16)
                        padding (14, 9)
                        text texte font F_CORPS size 18 color "#1d2228"
    key "dismiss" action Return()

transform telephone_arrivee:
    on show:
        yoffset 80 alpha 0.0
        easein .4 yoffset 0 alpha 1.0

################################################################################
## Carte de l'enquête
################################################################################

screen carte_enquete(lieux):
    zorder 100
    modal True
    add "images/bg/bg plan.jpg"
    add Solid("#0b0907a8")
    add "gui/vignette.png"

    vbox:
        xpos 60 ypos 34
        spacing 2
        text "%s — %s" % (nom_jour().upper(), moment.upper()) font F_TITRE size 34 color PAPIER kerning 4
        text "Il reste %d action%s %s." % (actions_restantes, "s" if actions_restantes > 1 else "", echeance_carte) font F_DISPLAY_IT size 26 color LAITON

    hbox:
        xalign 0.95 ypos 40
        spacing 12
        textbutton "Dossier" style "bouton_ui" action Show("dossier")

    $ _pistes = pistes_enquete()
    if _pistes:
        frame:
            style "panneau"
            xalign 0.5 yalign 1.0 yoffset -10
            xsize 1180
            padding (24, 12)
            vbox:
                spacing 4
                text "PISTES" style "etiquette_titre" size 17
                for lieu_p, phrase_p in _pistes:
                    hbox:
                        spacing 12
                        text lieu_p font F_DISPLAY size 19 color LAITON_CLAIR min_width 190
                        text phrase_p font F_CORPS size 16 color "#d9cdb6"

    vpgrid:
        cols 5
        spacing 14
        xalign 0.5 ypos 112
        for code, nom, vignette, note, dispo in lieux:
            button:
                xysize (226, 186)
                background Frame("gui/cadre.png", 26, 26)
                hover_background Frame("gui/cadre_hover.png", 26, 26)
                insensitive_background Frame("gui/cadre.png", 26, 26)
                sensitive dispo
                hover_sound "audio/sons/survol.ogg"
                activate_sound "audio/sons/pas.ogg"
                action Return(code)
                vbox:
                    xalign 0.5 ypos 10
                    spacing 3
                    add vignette xysize (200, 76) fit "cover" matrixcolor (IdentityMatrix() if dispo else SaturationMatrix(0.0) * BrightnessMatrix(-0.35))
                    text nom font F_DISPLAY size 22 color (LAITON_CLAIR if dispo else "#6b604f") xalign 0.5
                    text note font F_CORPS size 13 color ("#cbbfa8" if dispo else "#5a5244") xalign 0.5 text_align 0.5 xsize 206

################################################################################
## Marteaux (patience du juge)
################################################################################

screen marteaux_hud():
    zorder 45
    hbox:
        xalign 0.98 ypos 60
        spacing 6
        for i in range(marteaux_max()):
            add ("gui/marteau.png" if i < marteaux else "gui/marteau_vide.png") zoom 0.5

init python:
    def marteaux_max():
        return 6 if store.filiere == "droit" else 5

################################################################################
## Contre-interrogatoire
################################################################################

screen contre_interro(temoin_nom, declarations, idx, indice_logique=False):
    zorder 90
    $ dcl = declarations[idx]
    use marteaux_hud

    frame:
        xalign 0.5 ypos 26
        background Frame("gui/cadre.png", 26, 26)
        padding (28, 10)
        text "CONTRE-INTERROGATOIRE — %s" % temoin_nom.upper() font F_TITRE size 20 color SANG kerning 3

    frame:
        style "panneau"
        xalign 0.5 yalign 1.0 yoffset -8
        xsize 1240 ysize 210
        vbox:
            spacing 10
            hbox:
                spacing 12
                for i in range(len(declarations)):
                    text ("●" if i == idx else "○") size 18 color (LAITON if i == idx else DOUX) font "DejaVuSans.ttf"
                text " Déclaration %d / %d" % (idx + 1, len(declarations)) style "texte_machine"
                if indice_logique and dcl.get("contradiction"):
                    text "   Quelque chose cloche…" font F_DISPLAY_IT size 22 color AZUR
            text "« %s »" % dcl["texte"] font F_CORPS size 25 color "#7fd0a0" xsize 1160
            hbox:
                spacing 14
                xalign 0.5
                textbutton "‹  Précédente" style "bouton_ui" action Return("precedente") sensitive idx > 0
                textbutton "Presser" style "bouton_ui" action Return("presser")
                textbutton "Présenter une preuve" style "bouton_ui" action Return("presenter")
                textbutton "Suivante  ›" style "bouton_ui" action Return("suivante")
                textbutton "Je n'ai rien à opposer" style "bouton_ui" action Return("renoncer")

    key "K_LEFT" action Return("precedente")
    key "K_RIGHT" action Return("suivante")

################################################################################
## Le Livre des Sept Jours
################################################################################

screen livre_ecrire(prompt):
    zorder 190
    modal True
    add Solid("#000000") at fondu_rapide
    add "gui/livre_ouvert.png" xalign 0.5 yalign 0.5 at livre_respire
    vbox:
        xcenter 0.7 yalign 0.45
        xsize 420
        spacing 22
        text prompt font F_MAIN size 44 color "#4a3420" xalign 0.5 text_align 0.5
        input id "input" font F_MAIN size 60 color "#2a1a0c" xalign 0.5 length 24 caret "gui/curseur_encre.png"

transform livre_respire:
    zoom 1.0
    ease 4.0 zoom 1.012
    ease 4.0 zoom 1.0
    repeat

################################################################################
## Création du personnage
################################################################################

default creation_etape = 0

screen creation():
    modal True
    add "images/bg/bg academie nuit.jpg"
    add Solid("#0b0907c8")
    add "gui/vignette.png"

    vbox:
        xpos 70 ypos 40
        spacing 4
        text "ADMISSION À L'ACADÉMIE DE VALCOURT" font F_TITRE size 30 color LAITON kerning 4
        text "Dossier de l'étudiant·e boursier·e — à remplir avant la rentrée" font F_DISPLAY_IT size 24 color DOUX

    frame:
        style "panneau"
        xpos 60 ypos 118
        xsize 760 ysize 580
        padding (30, 20)
        vbox:
            spacing 9

            text "Prénom" style "etiquette_titre"
            frame:
                style "saisie_champ"
                input value VariableInputValue("joueur_nom") length 16 style "saisie_input" allow "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZàâäçéèêëîïôöùûüÿÀÂÄÇÉÈÊËÎÏÔÖÙÛÜŸ- '"

            text "On vous dit…" style "etiquette_titre"
            hbox:
                spacing 12
                textbutton "« Il » — admis, prêt, attendu" style "bouton_ui" action SetVariable("joueur_genre", "il") selected joueur_genre == "il"
                textbutton "« Elle » — admise, prête, attendue" style "bouton_ui" action SetVariable("joueur_genre", "elle") selected joueur_genre == "elle"

            text "Filière" style "etiquette_titre"
            hbox:
                spacing 12
                textbutton "Droit" style "bouton_ui" action SetVariable("filiere", "droit") selected filiere == "droit"
                textbutton "Sciences" style "bouton_ui" action SetVariable("filiere", "sciences") selected filiere == "sciences"
                textbutton "Lettres & Journalisme" style "bouton_ui" action SetVariable("filiere", "lettres") selected filiere == "lettres"
            text DESCRIPTIONS_FILIERE[filiere] style "texte_doux" xsize 690

            text "Tempérament" style "etiquette_titre"
            hbox:
                spacing 12
                textbutton "Logique" style "bouton_ui" action SetVariable("temperament", "logique") selected temperament == "logique"
                textbutton "Empathique" style "bouton_ui" action SetVariable("temperament", "empathique") selected temperament == "empathique"
                textbutton ("Audacieux" if joueur_genre == "il" else "Audacieuse") style "bouton_ui" action SetVariable("temperament", "audacieux") selected temperament == "audacieux"
            text DESCRIPTIONS_TEMPERAMENT[temperament] style "texte_doux" xsize 690

    frame:
        style "panneau"
        xpos 850 ypos 118
        xsize 370 ysize 580
        vbox:
            xalign 0.5
            spacing 10
            text "Portrait" style "etiquette_titre" xalign 0.5
            add "medaillons/joueur/[joueur_portrait].png" xalign 0.5 zoom 1.35
            hbox:
                xalign 0.5
                spacing 14
                textbutton "‹" style "bouton_ui" action SetVariable("joueur_portrait", (joueur_portrait - 2) % 6 + 1)
                text "%d / 6" % joueur_portrait style "texte_machine" yalign 0.5
                textbutton "›" style "bouton_ui" action SetVariable("joueur_portrait", joueur_portrait % 6 + 1)
            null height 4
            text (joueur_nom.strip() or "…") font F_DISPLAY size 40 color LAITON_CLAIR xalign 0.5
            text "%s · %s" % (NOMS_FILIERE[filiere], NOMS_TEMPERAMENT[temperament][0 if joueur_genre == "il" else 1]) style "texte_doux" xalign 0.5
            null height 10
            textbutton "Signer et entrer" style "bouton_ui" xalign 0.5 action Return(True) sensitive len(joueur_nom.strip()) >= 2

define NOMS_FILIERE = {"droit": "Droit", "sciences": "Sciences", "lettres": "Lettres & Journalisme"}
define NOMS_TEMPERAMENT = {"logique": ("Logique", "Logique"), "empathique": ("Empathique", "Empathique"), "audacieux": ("Audacieux", "Audacieuse")}
define DESCRIPTIONS_FILIERE = {
    "droit": "Vous connaissez la procédure. À l'audience, le juge vous pardonne une erreur de plus.",
    "sciences": "Vous savez lire un laboratoire : analyses, traces, réactifs. Rien ne vous échappe sur une paillasse.",
    "lettres": "Vous avez la plume et l'oreille : les gens vous parlent, et vous comprenez ce qu'ils veulent dire.",
}
define DESCRIPTIONS_TEMPERAMENT = {
    "logique": "Vous repérez les contradictions. Pendant les contre-interrogatoires, votre instinct vous alerte.",
    "empathique": "Les gens s'ouvrent à vous plus facilement, même ceux qui ont peur.",
    "audacieux": "Vous osez : fouiller un bureau, aller seul·e là où il ne faut pas.",
}

################################################################################
## Fondus et effets d'écran utilisés par l'histoire
################################################################################

define flash = Fade(.08, 0.0, .5, color="#ffffff")
define flash_rouge = Fade(.1, 0.0, .6, color="#7a1b12")
define fondu = Dissolve(.6)
define fondu_long = Dissolve(1.4)
define noir = Fade(.6, .4, .6)
define noir_long = Fade(1.2, .8, 1.2)
define glissement = ImageDissolve("gui/transition_encre.png", 1.0, 64)
define souvenir_in = ImageDissolve("gui/transition_encre.png", 1.2, 64, reverse=True)

transform tremblement_ecran:
    xoffset 0 yoffset 0
    linear .04 xoffset -10 yoffset 4
    linear .04 xoffset 9 yoffset -5
    linear .04 xoffset -7 yoffset 3
    linear .04 xoffset 5 yoffset -2
    linear .04 xoffset 0 yoffset 0

transform lente_poussee:
    zoom 1.0 xalign 0.5 yalign 0.5
    linear 30.0 zoom 1.08

transform souvenir_filtre:
    matrixcolor SepiaMatrix() * BrightnessMatrix(-0.05)
    blur 1.5
