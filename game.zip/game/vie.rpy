## vie.rpy — la réalité : énergie, études, moral, argent, emploi du temps,
## obligations et sac. On ne peut pas tout faire : chaque créneau passé à
## enquêter est un cours manqué, une nuit écourtée ou un appel sans réponse.

################################################################################
## Jauges
################################################################################

default energie = 7        # 0 à 10 — à 0, on rate des choses
default etudes = 6         # 0 à 10 — affichée en moyenne sur 20 ; la bourse exige 10/20
default moral = 6          # 0 à 10 — en dessous de 3, l'empathie se ferme
default argent = 60        # euros pour la semaine (bourse hebdomadaire)

default cafes_du_jour = 0
default nuits_blanches = 0
default revisions = 0      # séances de révision avant le devoir de mercredi
default note_ds = None     # note du devoir surveillé (sur 20)
default note_oral = None   # note de l'oral de vendredi (sur 20)
default appels_manques = 0 # appels de Maëlle restés sans réponse

## Journal : obligations et objectifs, affichés dans le Dossier.
default journal = []

## Sac : objet -> quantité.
default sac = {"telephone": 1, "carte_etudiant": 1, "cafe": 1}
## Historique des messages reçus (relisibles depuis le téléphone du sac).
default messagerie = []

init -8 python:

    def borner(v):
        return max(0, min(10, v))

    JAUGES = {
        "energie": ("Énergie", "gui/icone_energie.png"),
        "etudes": ("Études", "gui/icone_etudes.png"),
        "moral": ("Moral", "gui/icone_moral.png"),
    }

    def varier(**deltas):
        """varier(energie=-2, etudes=+1, moral=-1, argent=-15) avec notification compacte."""
        morceaux = []
        for nom, d in deltas.items():
            if not d:
                continue
            if nom == "argent":
                store.argent = store.argent + d
                morceaux.append(("%+d €" % d, d > 0))
            else:
                setattr(store, nom, borner(getattr(store, nom) + d))
                etiquette = JAUGES[nom][0]
                morceaux.append(("%s %s" % (etiquette, "▲" * d if d > 0 else "▼" * (-d)), d > 0))
        if morceaux:
            renpy.show_screen("note_jauges", morceaux=morceaux, _tag="note_jauges")
            renpy.restart_interaction()

    def moyenne():
        return store.etudes * 2

    def bourse_en_danger():
        return moyenne() < 10

    def epuise():
        return store.energie <= 1

    def fatigue():
        return store.energie <= 3

    def moral_bas():
        return store.moral <= 3

    def empathie_possible():
        """Les répliques les plus délicates demandent un minimum de moral."""
        return store.moral >= 3 or store.temperament == "empathique"

    ############################################################################
    ## Sac
    ############################################################################

    OBJETS = {
        "telephone": dict(nom="Téléphone", image="objets/telephone.png",
                          desc="Batterie à moitié. Les messages de la semaine y sont tous.", utiliser="lire"),
        "carte_etudiant": dict(nom="Carte d'étudiant", image="objets/carte.png",
                               desc="Académie de Valcourt — boursier. Ouvre la bibliothèque et la résidence. Pas le laboratoire."),
        "cafe": dict(nom="Café de la machine", image="objets/cafe.png",
                     desc="Amer, tiède, efficace. Rend un peu d'énergie (deux par jour au plus).", utiliser="boire"),
        "marque_page": dict(nom="Marque-page en laiton", image="objets/marque_page.png",
                            desc="Gravé d'un chêne. Iris me l'a donné le premier jour. Il est toujours tiède, comme s'il venait d'être tenu."),
        "lettre_iris": dict(nom="Lettre d'Iris", image="objets/lettre.png",
                            desc="Trouvée dans le Livre. « Si tu lis ceci, j'ai encore échoué. Dis-moi ARIANE, et je te croirai. »"),
        "chocolats": dict(nom="Boîte de chocolats", image="objets/chocolats.png",
                          desc="Achetée pour Clara. Les visites au parloir sont tristes ; ceci les rend moins tristes."),
        "badge_visiteur": dict(nom="Autorisation de visite", image="objets/badge.png",
                               desc="Signée par Dorian Varga. Permet de voir Clara au parloir."),
        "plan": dict(nom="Plan du campus", image="objets/plan.png",
                     desc="Distribué le jour de la rentrée. Quelqu'un y a entouré le laboratoire au crayon rouge."),
        "photo_imprimee": dict(nom="Tirage de la photo du bal", image="preuves/photo.png",
                               desc="Imprimée à la Gazette. Plus nette que sur un écran."),
    }

    def donner(objet, n=1, silencieux=False):
        store.sac[objet] = store.sac.get(objet, 0) + n
        if not silencieux:
            renpy.show_screen("note_jauges", morceaux=[("+ %s" % OBJETS[objet]["nom"], True)], _tag="note_jauges")
            renpy.restart_interaction()

    def retirer(objet, n=1):
        if store.sac.get(objet, 0) <= n:
            store.sac.pop(objet, None)
        else:
            store.sac[objet] -= n

    def possede(objet):
        return store.sac.get(objet, 0) > 0

    def acheter(objet, prix):
        if store.argent < prix:
            renpy.notify("Pas assez d'argent.")
            return False
        varier(argent=-prix)
        donner(objet, silencieux=True)
        return True

    def utiliser_objet(objet):
        o = OBJETS[objet]
        if o.get("utiliser") == "boire":
            if store.cafes_du_jour >= 2:
                renpy.notify("Un troisième café ne ferait que trembler vos mains.")
                return
            retirer("cafe")
            store.cafes_du_jour += 1
            varier(energie=2)
            renpy.sound.play("audio/sons/cafe.ogg")
        elif o.get("utiliser") == "lire":
            renpy.show_screen("messagerie_ecran")

    ############################################################################
    ## Messages et journal
    ############################################################################

    def recevoir(contact, texte, heure=""):
        store.messagerie.append((contact, texte, heure))

    def noter_journal(code, texte, quand=""):
        for e in store.journal:
            if e["code"] == code:
                return
        store.journal.append(dict(code=code, texte=texte, quand=quand, etat="a_faire"))

    def cocher(code, etat="fait"):
        for e in store.journal:
            if e["code"] == code:
                e["etat"] = etat

################################################################################
## Agenda : choisir l'activité d'un créneau
################################################################################
##
## Chaque option : (code, titre, description, effets, disponible, raison)
## effets : dict comme pour varier() — sert seulement à l'affichage.

screen agenda(titre, options, sous_titre=""):
    zorder 120
    modal True

    ## La scène reste derrière : seul le bas s'assombrit, comme pour les choix.
    add "gui/voile_bas.png" at fondu_rapide

    frame at agenda_haut:
        style "panneau"
        xalign 0.5 ypos 78
        padding (30, 12)
        vbox:
            spacing 2
            text titre.upper() font F_TITRE size 26 color PAPIER kerning 5 xalign 0.5
            if sous_titre:
                text sous_titre font F_DISPLAY_IT size 24 color LAITON xalign 0.5 text_align 0.5

    use jauges_hud()

    $ n = len(options)
    $ largeur = min(300, (1240 - 12 * (n - 1)) // n)
    hbox:
        xalign 0.5 yalign 1.0 yoffset -14
        spacing 12
        for k, opt in enumerate(options):
            $ code, nom, desc, effets, dispo, raison = opt[:6]
            $ vignette = opt[6] if len(opt) > 6 else None
            button at agenda_carte(k * 0.07):
                xsize largeur ysize 250
                background Frame("gui/cadre.png", 26, 26)
                hover_background Frame("gui/cadre_hover.png", 26, 26)
                insensitive_background Frame("gui/cadre.png", 26, 26)
                padding (18, 14)
                sensitive dispo
                hover_sound "audio/sons/survol.ogg"
                activate_sound "audio/sons/choix.ogg"
                action Return(code)
                vbox:
                    spacing 7
                    hbox:
                        spacing 10
                        if vignette:
                            add vignette fit "contain" xysize (54, 54) yalign 0.5 matrixcolor (IdentityMatrix() if dispo else SaturationMatrix(0.0))
                        text nom font F_DISPLAY size 25 color (LAITON_CLAIR if dispo else "#6b604f") yalign 0.5
                    text desc font F_CORPS size 16 color ("#d9cdb6" if dispo else "#5a5244")
                    hbox:
                        spacing 10
                        for cle, val in effets.items():
                            if cle == "argent":
                                text "%+d €" % val font F_CORPS size 15 color ("#9fd39a" if val > 0 else "#e0907f")
                            else:
                                text "%s %s" % (JAUGES[cle][0], ("+%d" % val) if val > 0 else ("%d" % val)) font F_CORPS size 15 color ("#9fd39a" if val > 0 else "#e0907f")
                    if not dispo and raison:
                        text raison font F_DISPLAY_IT size 18 color "#d9a99f"

transform agenda_haut:
    alpha 0.0 yoffset -16
    easein .4 alpha 1.0 yoffset 0

transform agenda_carte(delai):
    alpha 0.0 yoffset 30
    pause delai
    easein .35 alpha 1.0 yoffset 0

init python:
    def choisir_creneau(titre, options, sous_titre=""):
        """Affiche l'agenda et renvoie le code choisi."""
        renpy.sound.play("audio/sons/horloge.ogg")
        return renpy.call_screen("agenda", titre=titre, options=options, sous_titre=sous_titre)

################################################################################
## Jauges à l'écran
################################################################################

default jauges_visibles = True

screen jauges_hud(grand=False):
    zorder 44
    frame:
        style "panneau"
        padding (16, 10)
        xalign (0.5 if grand else 0.0)
        xoffset (0 if grand else 18)
        ypos (118 if grand else 16)
        hbox:
            spacing 22
            for cle in ("energie", "etudes", "moral"):
                $ v = getattr(store, cle)
                hbox:
                    spacing 6
                    add JAUGES[cle][1] zoom 0.5 yalign 0.5
                    if cle == "etudes":
                        text "%d/20" % moyenne() font F_MACHINE size 18 color ("#e0907f" if bourse_en_danger() else PAPIER) yalign 0.5
                    else:
                        bar value StaticValue(v, 10) xsize 70 ysize 10 yalign 0.5 left_bar Solid(("#e0907f" if v <= 3 else LAITON)) right_bar Solid("#3a3226")
            hbox:
                spacing 6
                add "gui/icone_argent.png" zoom 0.5 yalign 0.5
                text "%d €" % argent font F_MACHINE size 18 color (PAPIER if argent >= 10 else "#e0907f") yalign 0.5

screen jauges():
    zorder 44
    if jauges_visibles and chapitre != "prologue" and not main_menu and not renpy.get_screen("agenda") and not renpy.get_screen("titre_jour"):
        use jauges_hud()

screen note_jauges(morceaux):
    zorder 151
    timer 2.8 action Hide("note_jauges")
    hbox at note_apparition:
        xpos 24 ypos 136
        spacing 16
        for t, positif in morceaux:
            text t font F_CORPS size 19 color ("#9fd39a" if positif else "#e0907f") outlines [(2, "#000000c0", 0, 0)]

init python:
    config.overlay_screens.append("jauges")

################################################################################
## Téléphone : relire ses messages
################################################################################

screen messagerie_ecran():
    zorder 175
    modal True
    add Solid("#000000a0")
    fixed:
        xysize (420, 700)
        xalign 0.5 yalign 0.5
        add "gui/telephone.png"
        vbox:
            xpos 36 ypos 64 xsize 348
            spacing 8
            text "Messages" font F_DISPLAY size 30 color "#f2ece0" xalign 0.5
            viewport:
                ysize 520
                mousewheel True
                yinitial 1.0
                vbox:
                    spacing 8
                    for contact, texte, heure in messagerie:
                        frame:
                            background Frame("gui/bulle_autre.png", 16, 16)
                            padding (12, 8)
                            xfill True
                            vbox:
                                text "%s  %s" % (contact, heure) font F_MACHINE size 13 color "#55606b"
                                text texte font F_CORPS size 17 color "#1d2228"
                    if not messagerie:
                        text "Aucun message." font F_CORPS size 18 color "#9aa3ad"
    key "game_menu" action Hide("messagerie_ecran")
    key "dismiss" action Hide("messagerie_ecran")

################################################################################
## Onglets « Sac » et « Journal » du Dossier
################################################################################

default sac_choix = None

screen dossier_sac():
    $ objets = [o for o in sac if sac[o] > 0]
    $ courant = sac_choix if sac_choix in objets else (objets[0] if objets else None)
    hbox:
        spacing 26
        viewport:
            xsize 520 ysize 500
            scrollbars "vertical"
            mousewheel True
            vpgrid:
                cols 3
                spacing 14
                for code in objets:
                    $ o = OBJETS[code]
                    button:
                        xysize (158, 178)
                        background Frame("gui/cadre_clair.png", 20, 20)
                        hover_background Frame("gui/cadre_clair_hover.png", 20, 20)
                        selected_background Frame("gui/cadre_clair_hover.png", 20, 20)
                        selected courant == code
                        hover_sound "audio/sons/survol.ogg"
                        action SetVariable("sac_choix", code)
                        vbox:
                            xalign 0.5 yalign 0.5
                            spacing 4
                            add o["image"] fit "contain" xysize (110, 100) xalign 0.5
                            text (o["nom"] + (" ×%d" % sac[code] if sac[code] > 1 else "")) font F_CORPS size 15 color "#3a2a18" xalign 0.5 text_align 0.5 layout "subtitle"
        vbox:
            xsize 560
            spacing 14
            text "Argent : %d €" % argent font F_DISPLAY size 30 color LAITON_CLAIR
            if courant:
                $ o = OBJETS[courant]
                hbox:
                    spacing 20
                    add o["image"] fit "contain" xysize (180, 180)
                    text o["nom"] font F_DISPLAY size 36 color LAITON_CLAIR yalign 0.5
                text o["desc"] style "texte_ui"
                if o.get("utiliser") == "boire":
                    textbutton "Boire" style "bouton_ui" action Function(utiliser_objet, courant)
                elif o.get("utiliser") == "lire":
                    textbutton "Lire les messages" style "bouton_ui" action Function(utiliser_objet, courant)

screen dossier_journal():
    viewport:
        ysize 500
        scrollbars "vertical"
        mousewheel True
        vbox:
            spacing 12
            hbox:
                spacing 40
                text "Moyenne : %d/20" % moyenne() font F_DISPLAY size 30 color ("#e0907f" if bourse_en_danger() else LAITON_CLAIR)
                if note_ds is not None:
                    text "Devoir de mercredi : %d/20" % note_ds style "texte_machine" yalign 0.5
                if note_oral is not None:
                    text "Oral de vendredi : %d/20" % note_oral style "texte_machine" yalign 0.5
            if bourse_en_danger():
                text "La bourse exige une moyenne d'au moins 10/20. Le conseil se réunit vendredi soir." style "texte_ui" color "#e0907f"
            add "gui/filet_long.png" alpha 0.4
            for e in journal:
                hbox:
                    spacing 14
                    text {"a_faire": "○", "fait": "●", "rate": "✕"}[e["etat"]] font F_CORPS size 24 color {"a_faire": LAITON, "fait": "#9fd39a", "rate": "#e0907f"}[e["etat"]]
                    vbox:
                        text e["texte"] style "texte_ui" color ("#6b604f" if e["etat"] != "a_faire" else PAPIER)
                        if e["quand"]:
                            text e["quand"] style "texte_machine" size 15
            if not journal:
                text "Rien de prévu. Pour l'instant." style "texte_doux"
