## script.rpy — point d'entrée. L'histoire est découpée par jour dans histoire/.

label start:
    $ monde = tirer_monde()
    $ quick_menu = False
    scene black
    $ video("ouverture")
    $ musique_jouer("theme", 3.0)
    call screen creation with fondu
    $ joueur_nom = joueur_nom.strip()
    $ joueur_nom = joueur_nom[:1].upper() + joueur_nom[1:]
    if filiere == "droit":
        $ marteaux = 6
    $ quick_menu = True
    jump prologue
