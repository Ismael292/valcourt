## film.rpy — les souvenirs du joueur, la cinématique de fin de journée,
## et l'export d'un film MP4 personnel à chaque fin.

default souvenirs = []
default debut_jour_etat = {}
default persistent.films = {}

init -4 python:
    import re as _re_film

    def texte_plat(s):
        """Résout les accords {g=…} et retire les autres balises."""
        s = _re_film.sub(r"\{g=([^}/]*)/([^}]*)\}", lambda m: (m.group(2) if store.joueur_genre == "elle" else m.group(1)).replace("_", " "), s)
        s = _re_film.sub(r"\{[^}]*\}", "", s)
        return renpy.substitute(s, translate=False) if "[" in s else s

    def souvenir(texte, perso=None, bg=None):
        """Garde un moment marquant pour la cinématique du jour et le film final."""
        if bg is None:
            attrs = renpy.get_attributes("bg")
            bg = ("bg " + " ".join(attrs)) if attrs else None
        store.souvenirs.append(dict(jour=store.jour, boucle=store.boucle, texte=texte_plat(texte), bg=bg, perso=perso))

    import hashlib as _hl_voix

    def cle_voix(texte):
        return _hl_voix.md5(texte.strip().encode("utf-8")).hexdigest()[:16]

    def voix_de(texte):
        """Fichier de narration d'une phrase de souvenir, et sa durée (ou None, 0)."""
        k = cle_voix(texte)
        f = "audio/voix/%s.ogg" % k
        if renpy.loadable(f):
            return f, getattr(store, "VOIX_DUREES", {}).get(k, 3.0)
        return None, 0.0

    def instantane():
        return dict(energie=store.energie, etudes=store.etudes, moral=store.moral, argent=store.argent,
                    rel=dict(store.rel), preuves=list(store.preuves), appels=store.appels_manques)

################################################################################
## « Ce jour-là » : cinématique de fin de journée
################################################################################

transform resume_travelling:
    xalign 0.5 yalign 0.5 zoom 1.0
    linear 4.0 zoom 1.07

transform resume_portrait:
    xalign 0.86 yanchor 1.0 ypos 0.92 zoom 0.72 alpha 0.0
    easein .6 alpha 1.0

screen resume_legende(jour_nom, texte, n, total):
    zorder 60
    add "gui/voile_bas.png"
    vbox:
        xpos 70 ypos 40
        text "CE JOUR-LÀ" font F_TITRE size 22 color LAITON kerning 6
        text jour_nom font F_DISPLAY_IT size 30 color PAPIER
    text "%d / %d" % (n, total) font F_MACHINE size 18 color DOUX xalign 0.96 ypos 46
    text texte at legende_apparition:
        font F_DISPLAY_IT size 36 color "#f3ead8" xpos 80 xmaximum 900 yanchor 1.0 ypos 0.9
        outlines [(2, "#000000a0", 0, 1)]

transform legende_apparition:
    alpha 0.0 yoffset 12
    easein .7 alpha 1.0 yoffset 0

screen bilan_jour(jour_nom, avant):
    modal True
    zorder 70
    add Solid("#0b0907e8")
    add "gui/vignette.png"
    frame:
        style "panneau"
        xalign 0.5 yalign 0.5
        xsize 900
        padding (40, 30)
        vbox:
            spacing 14
            text ("BILAN — " + jour_nom.upper()) style "etiquette_titre" size 24 xalign 0.5
            add "gui/filet.png" xalign 0.5
            hbox:
                xalign 0.5
                spacing 40
                for cle, nom in (("energie", "Énergie"), ("etudes", "Études"), ("moral", "Moral")):
                    $ d = getattr(store, cle) - avant.get(cle, getattr(store, cle))
                    vbox:
                        text nom font F_DISPLAY size 26 color LAITON_CLAIR xalign 0.5
                        text ("%d/20" % moyenne() if cle == "etudes" else "%d/10" % getattr(store, cle)) font F_CORPS size 22 color PAPIER xalign 0.5
                        text ("%+d" % (d * 2 if cle == "etudes" else d) if d else "=") font F_CORPS size 18 color ("#9fd39a" if d > 0 else ("#e0907f" if d < 0 else DOUX)) xalign 0.5
                vbox:
                    text "Argent" font F_DISPLAY size 26 color LAITON_CLAIR xalign 0.5
                    text "%d €" % argent font F_CORPS size 22 color PAPIER xalign 0.5
                    $ d = argent - avant.get("argent", argent)
                    text ("%+d €" % d if d else "=") font F_CORPS size 18 color ("#9fd39a" if d > 0 else ("#e0907f" if d < 0 else DOUX)) xalign 0.5
            $ rel_av = avant.get("rel", {})
            $ changes = [(NOMS_RELATION[k], v - rel_av.get(k, v)) for k, v in rel.items() if v != rel_av.get(k, v)]
            if changes:
                text "Ce que les autres retiendront" style "etiquette_titre" size 17
                hbox:
                    spacing 26
                    for nom, d in changes:
                        text "%s %s" % (nom, "▲" * min(3, d) if d > 0 else "▼" * min(3, -d)) font F_CORPS size 19 color ("#9fd39a" if d > 0 else "#e0907f")
            $ nouvelles = [PREUVES[p]["nom"] for p in preuves if p not in avant.get("preuves", [])]
            if nouvelles:
                text "Nouvelles pièces au dossier : " + ", ".join(nouvelles) font F_CORPS size 18 color AZUR
            if appels_manques > avant.get("appels", appels_manques):
                text "Un appel de Maëlle est resté sans réponse." font F_DISPLAY_IT size 22 color "#e0907f"
            null height 6
            textbutton "Continuer" style "bouton_ui" xalign 0.5 action Return()

label resume_jour(jour_nom):
    $ _plans = [s for s in souvenirs if s["jour"] == jour and s["boucle"] == boucle and s["bg"]]
    if not _plans:
        return
    window hide
    $ poser_heure("")
    $ musique_jouer("boucle", 1.5)
    scene black with fondu
    $ _n = 0
    while _n < len(_plans):
        $ _s = _plans[_n]
        $ renpy.scene()
        $ renpy.show(_s["bg"], at_list=[resume_travelling])
        $ renpy.show("grain")
        if _s["perso"]:
            $ renpy.show(_s["perso"], at_list=[resume_portrait], tag="resume_perso")
        show screen resume_legende(jour_nom, _s["texte"], _n + 1, len(_plans))
        with Dissolve(0.8)
        $ _f, _d = voix_de(_s["texte"])
        if _f:
            $ renpy.sound.play(_f, channel="voice")
        $ renpy.pause(max(3.6, _d + 0.8))
        $ renpy.sound.stop(channel="voice")
        $ _n += 1
    hide screen resume_legende
    scene black with fondu
    call screen bilan_jour(jour_nom, debut_jour_etat)
    $ debut_jour_etat = instantane()
    return

################################################################################
## Le récit final : toute la partie, racontée sur les images des choix
################################################################################

default preferences.emphasize_audio = True
define config.emphasize_audio_channels = ["voice"]
define config.emphasize_audio_volume = 0.35

screen recit_titre(titre, sous_titre=""):
    zorder 65
    vbox at titre_apparition:
        xalign 0.5 yalign 0.45
        spacing 10
        text titre font F_TITRE size 64 color PAPIER kerning 10 xalign 0.5
        if sous_titre:
            text sous_titre font F_DISPLAY_IT size 32 color LAITON xalign 0.5
    text "Cliquez pour passer au moment suivant." font F_MACHINE size 15 color DOUX xalign 0.5 yalign 0.96

label recit_final:
    $ _tous = [s for s in souvenirs if s["bg"]]
    if not _tous:
        return
    window hide
    $ poser_heure("")
    $ musique_jouer("theme", 2.0)
    scene black with fondu_long
    show screen recit_titre("LE RÉCIT", "L'histoire de " + joueur_nom)
    $ renpy.pause(3.5)
    hide screen recit_titre
    $ _prec = None
    $ _n = 0
    while _n < len(_tous):
        $ _s = _tous[_n]
        if (_s["jour"], _s["boucle"]) != _prec:
            $ _prec = (_s["jour"], _s["boucle"])
            scene black with fondu
            show screen recit_titre(JOURS.get(_s["jour"], "").upper(), ("Encore une fois" if _s["boucle"] > 1 and _s["jour"] <= 7 else DATES.get(_s["jour"], "")))
            $ renpy.pause(2.0)
            hide screen recit_titre
        $ renpy.scene()
        $ renpy.show(_s["bg"], at_list=[resume_travelling])
        $ renpy.show("grain")
        if _s["perso"]:
            $ renpy.show(_s["perso"], at_list=[resume_portrait], tag="resume_perso")
        show screen resume_legende(JOURS.get(_s["jour"], ""), _s["texte"], _n + 1, len(_tous))
        with Dissolve(0.8)
        $ _f, _d = voix_de(_s["texte"])
        if _f:
            $ renpy.sound.play(_f, channel="voice")
        $ renpy.pause(max(3.4, _d + 0.8))
        $ renpy.sound.stop(channel="voice")
        $ _n += 1
    hide screen resume_legende
    scene black with fondu_long
    return

################################################################################
## Le film de votre histoire (export MP4 avec ffmpeg)
################################################################################

init python:
    import os as _os_f
    import subprocess as _sp
    import threading as _th
    import time as _time_f

    film_etat = dict(en_cours=False, message="", progression=0.0, fichier=None, erreur=None)

    def chemin_ffmpeg():
        if not renpy.windows:
            return None
        for c in (_os_f.path.join(config.basedir, "outils", "ffmpeg.exe"),
                  _os_f.path.join(config.basedir, "..", "_outils", "ffmpeg", "ffmpeg.exe")):
            if _os_f.path.exists(c):
                return _os_f.path.abspath(c)
        return None

    def export_possible():
        return chemin_ffmpeg() is not None

    def fichier_portrait(nom_image):
        tag, _, expr = nom_image.partition(" ")
        for e in [expr] + REPLIS.get(expr, []) + ["normal"]:
            f = "persos/%s/%s.png" % (tag, e)
            if renpy.loadable(f):
                return f
        return None

    def memoriser_film(code, numero, titre, phrase):
        if persistent.films is None:
            persistent.films = {}
        choisis = [s for s in store.souvenirs if s["bg"]]
        if len(choisis) > 18:
            pas = len(choisis) / 18.0
            choisis = [choisis[int(i * pas)] for i in range(18)]
        persistent.films[code] = dict(numero=numero, titre=titre, phrase=phrase, joueur=store.joueur_nom,
                                      plans=[dict(jour=JOURS.get(s["jour"], ""), texte=s["texte"], voix=voix_de(s["texte"])[0],
                                                  duree=max(4.2, voix_de(s["texte"])[1] + 1.0),
                                                  bg="images/bg/%s.jpg" % s["bg"],
                                                  perso=fichier_portrait(s["perso"]) if s["perso"] else None)
                                             for s in choisis],
                                      date=_time_f.strftime("%d/%m/%Y"))
        renpy.save_persistent()

    def _extraire(chemin_jeu, dossier, nom):
        dest = _os_f.path.join(dossier, nom)
        with renpy.open_file(chemin_jeu) as f, open(dest, "wb") as o:
            o.write(f.read())
        return nom

    def _ecrire_texte(dossier, nom, texte):
        with open(_os_f.path.join(dossier, nom), "w", encoding="utf-8", newline="\n") as f:
            f.write(texte)
        return nom

    def _couper(texte, n=46):
        mots, lignes, cur = texte.split(), [], ""
        for m in mots:
            if len(cur) + len(m) + 1 > n and cur:
                lignes.append(cur); cur = m
            else:
                cur = (cur + " " + m).strip()
        if cur:
            lignes.append(cur)
        return "\n".join(lignes)

    def _monter_film(code):
        film = persistent.films[code]
        ff = chemin_ffmpeg()
        tmp = _os_f.path.join(config.savedir, "film_tmp")
        _os_f.makedirs(tmp, exist_ok=True)
        for f in _os_f.listdir(tmp):
            try:
                _os_f.remove(_os_f.path.join(tmp, f))
            except Exception:
                pass
        sortie_dir = _os_f.path.join(_os_f.path.expanduser("~"), "Videos", "Valcourt")
        _os_f.makedirs(sortie_dir, exist_ok=True)
        nom_sortie = "Valcourt - %s - %s.mp4" % (film["titre"].replace("—", "-"), film["joueur"])
        nom_sortie = "".join(c for c in nom_sortie if c not in '\\/:*?"<>|')
        sortie = _os_f.path.join(sortie_dir, nom_sortie)

        _extraire("fonts/Cinzel-Bold.ttf", tmp, "titre.ttf")
        _extraire("fonts/Cormorant-Italic.ttf", tmp, "texte.ttf")
        _extraire("fonts/SpecialElite.ttf", tmp, "machine.ttf")
        _extraire("audio/musique/theme.ogg", tmp, "musique.ogg")
        _extraire("images/bg/bg academie nuit.jpg", tmp, "fond_titre.jpg")

        cfg = ["-y", "-loglevel", "error"]
        enc = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-r", "25"]
        plans = []
        total = len(film["plans"]) + 3

        def lancer(args, n):
            film_etat["progression"] = n / float(total + 1)
            r = _sp.run([ff] + cfg + args, cwd=tmp, capture_output=True,
                        creationflags=getattr(_sp, "CREATE_NO_WINDOW", 0))
            if r.returncode != 0:
                raise Exception(r.stderr.decode("utf-8", "replace")[-600:])

        # 1. Générique d'ouverture
        film_etat["message"] = "Générique…"
        _ecrire_texte(tmp, "t_titre.txt", "VALCOURT")
        _ecrire_texte(tmp, "t_sous.txt", "Les Sept Jours")
        _ecrire_texte(tmp, "t_qui.txt", "L'histoire de %s" % film["joueur"])
        vf = ("[0:v]scale=1280:720,boxblur=6,eq=brightness=-0.25,"
            "drawtext=fontfile=titre.ttf:textfile=t_titre.txt:fontsize=110:fontcolor=0xEFE6D4:x=(w-tw)/2:y=h*0.30:alpha='min(1,t/1.2)',"
            "drawtext=fontfile=texte.ttf:textfile=t_sous.txt:fontsize=52:fontcolor=0xC9A45C:x=(w-tw)/2:y=h*0.50:alpha='min(1,max(0,(t-0.8)/1.2))',"
            "drawtext=fontfile=texte.ttf:textfile=t_qui.txt:fontsize=40:fontcolor=0xD9CDB6:x=(w-tw)/2:y=h*0.64:alpha='min(1,max(0,(t-1.6)/1.2))',"
            "fade=t=in:d=0.8,fade=t=out:st=4.2:d=0.8[v]")
        lancer(["-loop", "1", "-t", "5", "-i", "fond_titre.jpg", "-filter_complex", vf, "-map", "[v]"] + enc + ["p00.mp4"], 0)
        plans.append("p00.mp4")

        # 2. Un plan par souvenir
        for k, p in enumerate(film["plans"]):
            film_etat["message"] = "Plan %d sur %d…" % (k + 1, len(film["plans"]))
            fond = _extraire(p["bg"], tmp, "f%02d.jpg" % k)
            _ecrire_texte(tmp, "l%02d.txt" % k, _couper(p["texte"]))
            _ecrire_texte(tmp, "j%02d.txt" % k, p["jour"].upper())
            d = round(p.get("duree", 4.2), 1)
            sens = "1" if k % 2 == 0 else "-1"
            vf = ("[0:v]scale=1440:810,crop=1280:720:x='80+%s*70*t/%.1f':y='45-20*t/%.1f'[b];" % (sens, d, d))
            entrees = ["-loop", "1", "-t", str(d), "-i", fond]
            if p["perso"]:
                perso = _extraire(p["perso"], tmp, "c%02d.png" % k)
                entrees += ["-loop", "1", "-t", str(d), "-i", perso]
                vf += "[1:v]scale=-1:430,format=rgba,fade=t=in:st=0.3:d=0.8:alpha=1[c];[b][c]overlay=W-w-40:H-h-30[b2];"
            else:
                vf += "[b]null[b2];"
            vf += ("[b2]drawbox=y=ih-210:w=iw:h=210:color=black@0.55:t=fill,"
                   "drawtext=fontfile=machine.ttf:textfile=j%02d.txt:fontsize=26:fontcolor=0xC9A45C:x=60:y=40,"
                   "drawtext=fontfile=texte.ttf:textfile=l%02d.txt:fontsize=40:line_spacing=8:fontcolor=0xF3EAD8:x=60:y=h-185:alpha='min(1,max(0,(t-0.4)/0.8))',"
                   "fade=t=in:d=0.6,fade=t=out:st=%.1f:d=0.6[v]" % (k, k, d - 0.6))
            lancer(entrees + ["-filter_complex", vf, "-map", "[v]"] + enc + ["p%02d.mp4" % (k + 1)], k + 1)
            plans.append("p%02d.mp4" % (k + 1))

        # 3. Carte de fin et générique
        film_etat["message"] = "Carte de fin…"
        _ecrire_texte(tmp, "t_fin.txt", "FIN %d / %d" % (film["numero"], len(FINS)))
        _ecrire_texte(tmp, "t_titrefin.txt", film["titre"].upper())
        _ecrire_texte(tmp, "t_phrase.txt", _couper(film["phrase"], 50))
        _ecrire_texte(tmp, "t_credit.txt", "Joué par %s — %s\nValcourt, un visual novel Ren'Py" % (film["joueur"], film["date"]))
        vf = ("color=c=0x0B0907:s=1280x720:d=6[n];[n]"
              "drawtext=fontfile=machine.ttf:textfile=t_fin.txt:fontsize=28:fontcolor=0xA89A83:x=(w-tw)/2:y=h*0.30,"
              "drawtext=fontfile=titre.ttf:textfile=t_titrefin.txt:fontsize=68:fontcolor=0xF0D79A:x=(w-tw)/2:y=h*0.40:alpha='min(1,t/1.2)',"
              "drawtext=fontfile=texte.ttf:textfile=t_phrase.txt:fontsize=40:fontcolor=0xCBBFA8:x=(w-tw)/2:y=h*0.56:alpha='min(1,max(0,(t-1)/1.2))',"
              "drawtext=fontfile=texte.ttf:textfile=t_credit.txt:fontsize=26:fontcolor=0x8F8270:x=(w-tw)/2:y=h*0.82:alpha='min(1,max(0,(t-2)/1.2))',"
              "fade=t=in:d=0.8,fade=t=out:st=5.0:d=1.0[v]")
        lancer(["-f", "lavfi", "-i", "anullsrc", "-filter_complex", vf, "-map", "[v]", "-t", "6"] + enc + ["p99.mp4"], total - 1)
        plans.append("p99.mp4")

        # 4. Assemblage, musique et voix du narrateur
        film_etat["message"] = "Assemblage, musique et narration…"
        _ecrire_texte(tmp, "liste.txt", "\n".join("file '%s'" % p for p in plans))
        durees = [round(p.get("duree", 4.2), 1) for p in film["plans"]]
        duree = 5 + sum(durees) + 6
        entrees = ["-f", "concat", "-safe", "0", "-i", "liste.txt", "-stream_loop", "-1", "-i", "musique.ogg"]
        filtres = ["[1:a]atrim=0:%.1f,afade=t=in:d=2,afade=t=out:st=%.1f:d=3,volume=0.45[m]" % (duree, duree - 3)]
        voix = []
        debut = 5.0
        for k, p in enumerate(film["plans"]):
            if p.get("voix"):
                _extraire(p["voix"], tmp, "v%02d.ogg" % k)
                entrees += ["-i", "v%02d.ogg" % k]
                n = 2 + len(voix)
                ms = int((debut + 0.5) * 1000)
                filtres.append("[%d:a]adelay=%d|%d,volume=1.4[v%d]" % (n, ms, ms, len(voix)))
                voix.append("[v%d]" % len(voix))
            debut += durees[k]
        filtres.append("[m]" + "".join(voix) + "amix=inputs=%d:duration=first:normalize=0[a]" % (len(voix) + 1))
        lancer(entrees + ["-filter_complex", ";".join(filtres),
                "-map", "0:v", "-map", "[a]", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart",
                "-t", "%.1f" % duree, sortie], total)
        film_etat["fichier"] = sortie
        film_etat["progression"] = 1.0
        film_etat["message"] = "Votre film est prêt."

    def _fil_export(code):
        try:
            _monter_film(code)
        except Exception as e:
            film_etat["erreur"] = str(e)
            film_etat["message"] = "Le montage a échoué."
        film_etat["en_cours"] = False

    def exporter_film(code, attendre=False):
        if film_etat["en_cours"] or not export_possible():
            return
        film_etat.update(en_cours=True, message="Préparation…", progression=0.0, fichier=None, erreur=None)
        if attendre:
            _fil_export(code)
        else:
            _th.Thread(target=_fil_export, args=(code,), daemon=True).start()

    def ouvrir_dossier_films():
        d = _os_f.path.join(_os_f.path.expanduser("~"), "Videos", "Valcourt")
        if renpy.windows and _os_f.path.isdir(d):
            _os_f.startfile(d)

screen proposer_film(code):
    modal True
    zorder 210
    add Solid("#0b0907f0")
    add "gui/vignette.png"
    timer 0.25 repeat True action Function(renpy.restart_interaction)
    frame:
        style "panneau"
        xalign 0.5 yalign 0.5 xsize 820
        padding (40, 30)
        vbox:
            spacing 16
            xfill True
            text "LE FILM DE VOTRE HISTOIRE" style "etiquette_titre" size 24 xalign 0.5
            add "gui/filet.png" xalign 0.5
            if not export_possible():
                text "L'export vidéo est disponible sur la version PC du jeu." style "texte_ui" xalign 0.5
            elif film_etat["en_cours"]:
                text film_etat["message"] font F_DISPLAY_IT size 28 color PAPIER xalign 0.5
                bar value StaticValue(film_etat["progression"], 1.0) xsize 600 ysize 12 xalign 0.5 left_bar Solid(LAITON) right_bar Solid("#3a3226")
                text "Le montage prend une à trois minutes. Vous pouvez patienter ici." style "texte_doux" xalign 0.5
            elif film_etat["fichier"]:
                text "Votre film est prêt !" font F_DISPLAY size 34 color LAITON_CLAIR xalign 0.5
                text film_etat["fichier"] style "texte_machine" xalign 0.5 text_align 0.5 xmaximum 740
                text "Partagez-le avec vos amis : c'est votre histoire, vos choix, votre fin." style "texte_doux" xalign 0.5
                textbutton "Ouvrir le dossier" style "bouton_ui" xalign 0.5 action Function(ouvrir_dossier_films)
            else:
                text "Valcourt peut monter un court film de votre partie : vos choix, vos moments, votre fin. Une vidéo MP4 à garder et à partager." style "texte_ui" xalign 0.5 text_align 0.5
                if film_etat["erreur"]:
                    text "Le dernier montage a échoué. Vous pouvez réessayer." style "texte_doux" color "#e0907f" xalign 0.5
                textbutton "Exporter mon film" style "bouton_ui" xalign 0.5 action Function(exporter_film, code)
            textbutton ("Continuer" if not film_etat["en_cours"] else "Continuer sans attendre") style "bouton_ui" xalign 0.5 action Return()
