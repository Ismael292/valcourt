## personnages.rpy — qui parle, et comment on les montre.
##
## Les portraits vivent dans game/persos/<tag>/<expression>.png (hors du dossier
## images/, pour que Ren'Py ne les nomme pas tout seul). Chaque personnage peut
## utiliser les 12 expressions ci-dessous : si un fichier manque, on prend
## l'expression la plus proche qui existe.

init -5 python:

    EXPRESSIONS = ["normal", "sourire", "joie", "triste", "colere", "souci", "timide",
                          "peur", "surprise", "pensif", "determine", "fatigue"]

    REPLIS = {
        "sourire": ["joie", "normal"],
        "joie": ["sourire", "normal"],
        "triste": ["fatigue", "souci", "normal"],
        "colere": ["determine", "normal"],
        "souci": ["triste", "pensif", "normal"],
        "timide": ["souci", "sourire", "normal"],
        "peur": ["surprise", "souci", "normal"],
        "surprise": ["peur", "normal"],
        "pensif": ["souci", "normal"],
        "determine": ["colere", "normal"],
        "fatigue": ["triste", "souci", "normal"],
        "normal": ["sourire", "pensif"],
    }

    ## Mise en avant de celui qui parle : les autres portraits s'assombrissent
    ## doucement. L'état est gardé par personnage pour ne pas « clignoter »
    ## quand l'expression change.
    _eclat = {}

    def _focus(tag):
        def f(trans, st, at):
            parlant = renpy.get_say_image_tag()
            if parlant is None or parlant == tag or not renpy.showing(parlant):
                cible = 1.0
            else:
                cible = 0.0
            v = _eclat.get(tag, cible)
            v += (cible - v) * 0.22
            if abs(cible - v) < 0.01:
                v = cible
            _eclat[tag] = v
            trans.matrixcolor = BrightnessMatrix((v - 1.0) * 0.22) * SaturationMatrix(0.55 + 0.45 * v)
            return 0.04
        return f

    def _enregistrer_portraits():
        fichiers = {}
        for chemin in renpy.list_files():
            if chemin.startswith("persos/") and chemin.endswith(".png"):
                morceaux = chemin.split("/")
                if len(morceaux) == 3:
                    tag, expr = morceaux[1], morceaux[2][:-4]
                    fichiers.setdefault(tag, {})[expr] = chemin
        for tag, exprs in fichiers.items():
            for e in set(EXPRESSIONS) | set(exprs):
                source = exprs.get(e)
                if source is None:
                    for r in REPLIS.get(e, []) + ["normal"]:
                        if r in exprs:
                            source = exprs[r]
                            break
                if source is None:
                    source = sorted(exprs.values())[0]
                renpy.image((tag, e), At(source, Transform(function=_focus(tag))))
                med = "medaillons/%s/%s.png" % (tag, e)
                if not renpy.loadable(med):
                    med = "medaillons/%s/%s.png" % (tag, source.split("/")[-1][:-4])
                if renpy.loadable(med):
                    renpy.image(("side", tag, e), med)
            ## Médaillon par défaut, quand on parle sans préciser d'expression.
            defaut = "medaillons/%s/normal.png" % tag
            if renpy.loadable(defaut):
                renpy.image(("side", tag), defaut)

    _enregistrer_portraits()

## Le portrait du joueur suit son choix à la création.
image side joueur = "medaillons/joueur/[joueur_portrait].png"

################################################################################
## Positions : des cartes posées au-dessus de la boîte de dialogue.
################################################################################

transform carte(x=0.5):
    xcenter x
    yanchor 1.0
    ypos 0.86
    zoom 0.86
    on show:
        alpha 0.0 yoffset 18
        easein .45 alpha 1.0 yoffset 0
    on replace:
        alpha 1.0 yoffset 0
    on hide:
        easeout .3 alpha 0.0 yoffset 10

transform gauche:
    carte(0.25)
transform gauche_c:
    carte(0.36)
transform centre:
    carte(0.5)
transform droite_c:
    carte(0.64)
transform droite:
    carte(0.75)

## Petits sursauts pour les émotions fortes.
transform sursaut:
    yoffset 0
    easeout .08 yoffset -14
    easein .14 yoffset 0

transform tremble:
    xoffset 0
    linear .05 xoffset -6
    linear .05 xoffset 6
    linear .05 xoffset -4
    linear .05 xoffset 4
    linear .05 xoffset 0

################################################################################
## Les voix
################################################################################

define narrator = Character(None, what_style="narration")
define pensee = Character(None, what_style="pensee")
define moi = Character("[joueur_nom]", image="joueur", who_color="#e7c98a")

define c = Character("Clara", image="clara", who_color="#e2b98f")
define ir = Character("Iris", image="iris", who_color="#b9c7e8")
define ir_inconnue = Character("Étudiante", image="iris", who_color="#b9c7e8")
define d = Character("Dorian Varga", image="dorian", who_color="#c8b27a")
define isa = Character("Isabella Varga", image="isabella", who_color="#d08a7a")
define el = Character("Éléonore Lambert", image="eleonore", who_color="#b8c9a3")
define m = Character("Malo Deschamps", image="malo", who_color="#9fc0b4")
define m_inconnu = Character("Inspecteur", image="malo", who_color="#9fc0b4")
define ob = Character("Mme Bernier", image="bernier", who_color="#c9b7d6")
define am = Character("Amélie", image="amelie", who_color="#f0a878")
define na = Character("Nathan", image="nathan", who_color="#a9b4c2")
define lu = Character("Lucas", image="lucas", who_color="#d9cf8a")
define hu = Character("Hugo", image="hugo", who_color="#c2a9a0")
define ma = Character("Maëlle", image="maelle", who_color="#e6a3b8")
define pr = Character("Procureure Saunier", image="saunier", who_color="#b6a6c9")
define ju = Character("Président Leclerc", image="leclerc", who_color="#d6c08f")
define voix = Character("Une voix", who_color="#a89a83")
define foule = Character("La salle", who_color="#a89a83")
define agent = Character("Agent de police", who_color="#9fb0c0")
define livre = Character(None, what_style="ecriture_livre", window_style="fenetre_livre")
