## systemes.rpy — le moteur de Valcourt : joueur, accords, relations, preuves,
## compréhension du texte tapé, fins. Les écrans qui affichent tout cela sont
## dans ecrans.rpy ; l'histoire elle-même est dans histoire/.

################################################################################
## Le joueur
################################################################################

default joueur_nom = "Alex"
default joueur_genre = "il"            # "il" ou "elle" : pilote tous les accords
default joueur_portrait = 1            # 1 à 6
default filiere = "droit"              # "droit", "sciences", "lettres"
default temperament = "logique"        # "logique", "empathique", "audacieux"

################################################################################
## L'état de la partie
################################################################################

default jour = 0                       # 1 = lundi … 6 = samedi
default moment = ""                    # "matin", "après-midi", "soir", "nuit"
default boucle = 1                     # 2 = le mercredi revécu
default chapitre = "prologue"

## Relations : de 0 à 10.
default rel = {"clara": 3, "malo": 2, "dorian": 3, "isabella": 2, "iris": 3, "amelie": 3}

## Drapeaux d'histoire (choix faits, choses vues, souvenirs).
default faits = set()

## Preuves en possession, dans l'ordre d'obtention.
default preuves = []
## Preuves examinées de près (révèle le détail caché).
default preuves_examinees = set()

## Audience.
default marteaux = 5
default contradictions = set()

## Enquête.
default actions_restantes = 0
default lieux_visites = set()

init -10 python:

    import re
    import unicodedata

    ############################################################################
    ## Accords grammaticaux : {g=admis/admise}
    ############################################################################

    def _balise_genre(tag, argument):
        masc, _, fem = argument.partition("/")
        texte = fem if store.joueur_genre == "elle" else masc
        return [(renpy.TEXT_TEXT, texte.replace("_", " "))]

    config.self_closing_custom_text_tags["g"] = _balise_genre

    def accord(masc, fem):
        """Version Python des accords, pour les chaînes construites en code."""
        return fem if store.joueur_genre == "elle" else masc

    ############################################################################
    ## Faits
    ############################################################################

    def fait(nom):
        return nom in store.faits

    def noter(*noms):
        for n in noms:
            store.faits.add(n)

    def oublier(*noms):
        for n in noms:
            store.faits.discard(n)

    ############################################################################
    ## Relations
    ############################################################################

    NOMS_RELATION = {
        "clara": "Clara", "malo": "Malo", "dorian": "Dorian", "isabella": "Isabella Varga",
        "iris": "Iris", "amelie": "Amélie",
    }

    PHRASES_RELATION = {
        "clara": ("Clara s'en souviendra.", "Clara s'en souviendra."),
        "malo": ("Malo vous accorde un peu plus de confiance.", "Malo se méfie un peu plus de vous."),
        "dorian": ("Dorian apprécie.", "Dorian est déçu."),
        "isabella": ("Isabella Varga vous observe avec intérêt.", "Isabella Varga vous tient à distance."),
        "iris": ("Iris s'en souviendra.", "Iris s'en souviendra."),
        "amelie": ("Amélie vous trouve sympathique.", "Amélie vous trouve distant[e]."),
    }

    def lien(perso, delta, silencieux=False):
        """Fait varier une relation et affiche une note discrète (façon « s'en souviendra »)."""
        avant = store.rel.get(perso, 0)
        apres = max(0, min(10, avant + delta))
        store.rel[perso] = apres
        if silencieux or delta == 0:
            return
        phrase = PHRASES_RELATION.get(perso, ("", ""))[0 if delta > 0 else 1]
        phrase = phrase.replace("[e]", accord("", "e"))
        renpy.show_screen("note_relation", perso=perso, texte=phrase, positif=(delta > 0), _tag="note_relation")
        renpy.restart_interaction()

    def niveau(perso):
        return store.rel.get(perso, 0)

    ############################################################################
    ## Normalisation et compréhension du texte tapé
    ############################################################################

    def normaliser(texte):
        texte = unicodedata.normalize("NFD", (texte or "").lower())
        texte = "".join(c for c in texte if unicodedata.category(c) != "Mn")
        texte = texte.replace("œ", "oe").replace("æ", "ae").replace("'", " ").replace("’", " ")
        texte = re.sub(r"[^a-z0-9 ]", " ", texte)
        return " ".join(texte.split())

    def _distance(a, b, limite):
        """Distance de Levenshtein, abandonnée dès qu'elle dépasse la limite."""
        if abs(len(a) - len(b)) > limite:
            return limite + 1
        precedent = list(range(len(b) + 1))
        for i, ca in enumerate(a, 1):
            courant = [i]
            meilleur = i
            for j, cb in enumerate(b, 1):
                v = min(precedent[j] + 1, courant[j - 1] + 1, precedent[j - 1] + (ca != cb))
                courant.append(v)
                meilleur = min(meilleur, v)
            if meilleur > limite:
                return limite + 1
            precedent = courant
        return precedent[-1]

    def tolerance():
        """Lettres & Journalisme : le jeu comprend mieux les formulations approximatives."""
        return 2 if store.filiere == "lettres" else 1

    def mentionne(texte, mots):
        """Vrai si le texte contient l'un des mots-clés (accents, majuscules et fautes tolérés)."""
        t = normaliser(texte)
        if not t:
            return False
        jetons = t.split()
        for mot in mots:
            m = normaliser(mot)
            if not m:
                continue
            if " " in m:
                if m in t:
                    return True
                continue
            for j in jetons:
                if j == m:
                    return True
                # Les mots courts doivent être exacts, sinon « rat » trouverait « art ».
                if len(m) >= 5 and len(j) >= 4:
                    if j.startswith(m[:-1]) or m.startswith(j) and len(j) >= len(m) - 2:
                        return True
                    if _distance(j, m, tolerance()) <= tolerance():
                        return True
        return False

    def comprendre(texte, sujets):
        """Renvoie la clé du premier sujet reconnu dans le texte, ou None.

        sujets : liste de (clé, [mots-clés]) — l'ordre compte : on met les sujets
        les plus précis en premier.
        """
        for cle, mots in sujets:
            if mentionne(texte, mots):
                return cle
        return None

    MOTS_SOUTIEN = [
        "confiance", "crois en toi", "je crois", "la pour toi", "là pour toi", "avec toi", "ensemble",
        "fiere", "fier", "courage", "capable", "tu vas y arriver", "tu peux", "pas seule", "je suis la",
        "je reste", "ami", "amie", "ecoute", "comprends", "soutien", "t aider", "aider", "bravo", "talent",
        "magnifique", "forte", "pas grave", "respire", "ca va aller", "ça va aller",
    ]
    MOTS_DURS = [
        "nulle", "nul", "pathetique", "ridicule", "arrete de pleurer", "pleurnich", "tant pis", "ta faute",
        "debrouille", "m en fiche", "m en fous", "pas mon probleme", "exagere", "faible",
    ]

    def ton_reponse(texte):
        """Classe une réponse libre : 'soutien', 'dur' ou 'neutre'."""
        if mentionne(texte, MOTS_DURS):
            return "dur"
        if mentionne(texte, MOTS_SOUTIEN):
            return "soutien"
        return "neutre"

    ############################################################################
    ## Preuves
    ############################################################################

    PREUVES = {
        "carnet": dict(
            nom="Carnet de Clara",
            image="preuves/carnet.png",
            desc="Le carnet d'aquarelle de Clara, retrouvé près du corps. La dernière page représente le laboratoire de nuit.",
            detail="En regardant de près : l'horloge du dessin indique 21 h 30. Dans le coin, une silhouette floue, cheveux relevés en chignon, un dossier sous le bras.",
        ),
        "rapport": dict(
            nom="Rapport de police",
            image="preuves/rapport.png",
            desc="Iris Delaunay, 20 ans. Décès estimé vers 22 h 40. Chute contre l'angle d'une paillasse. Traces de lutte.",
            detail="Une mention manuscrite de Malo : « Pas d'effraction. La porte a été ouverte avec un badge. »",
        ),
        "message": dict(
            nom="Dernier message d'Iris",
            image="preuves/message.png",
            desc="Reçu mercredi à 22 h 12 : « Elle a les clés de tout. Viens au labo. Pas la police. »",
            detail="« Elle ». Iris savait qui la menaçait, et cette personne avait « les clés de tout ».",
        ),
        "epingle": dict(
            nom="Épingle à cheveux dorée",
            image="preuves/epingle.png",
            desc="Trouvée sous la paillasse du laboratoire, hors du périmètre fouillé par la police.",
            detail="Une épingle fine, de bonne facture, comme on en utilise pour tenir un chignon. Clara a les cheveux lâchés.",
        ),
        "badges": dict(
            nom="Registre des badges",
            image="preuves/badges.png",
            desc="Journal électronique des portes. Laboratoire de chimie, mercredi : ouverture à 22 h 31.",
            detail="Le badge utilisé est le passe de la DIRECTION. Seules deux personnes l'utilisent : Isabella Varga et son assistante.",
        ),
        "usb": dict(
            nom="Clé USB d'Iris",
            image="preuves/usb.png",
            desc="Cachée dans le Livre des Sept Jours. Contient le « Registre Azur ».",
            detail="Livraisons au Quai 7 chaque jeudi. Deux initiales reviennent : E.L. pour les paiements, N.R. pour la « production ».",
        ),
        "azur": dict(
            nom="Sachet d'Azur",
            image="preuves/azur.png",
            desc="Petites pastilles bleu pâle, trouvées dans les affaires de Hugo. Vendues comme « aide pour réviser ».",
            detail="L'analyse révèle un réactif marqué du lot VAL-23 : il sort du stock du laboratoire de l'Académie.",
        ),
        "photo_bal": dict(
            nom="Photo du bal",
            image="preuves/photo.png",
            desc="Prise par Amélie mardi soir. Au fond, près de l'escalier, deux silhouettes.",
            detail="Agrandie : Éléonore Lambert remet une enveloppe épaisse à Nathan Roussel.",
        ),
        "video": dict(
            nom="Vidéo du couloir",
            image="preuves/video.png",
            desc="Sauvegarde partielle récupérée par Malo. Couloir des sciences, mercredi, 22 h 35.",
            detail="Une silhouette passe devant la caméra : chignon, veste sombre, un dossier frappé d'un V.",
        ),
        "temoignage": dict(
            nom="Aveu de Nathan",
            image="preuves/temoignage.png",
            desc="Nathan Roussel reconnaît fabriquer l'Azur la nuit, au laboratoire, sur ordre d'une « femme de la direction ».",
            detail="« Elle avait les clés, les horaires, tout. Elle m'a dit qu'Iris allait tout gâcher. »",
        ),
        "agenda": dict(
            nom="Agenda de la direction",
            image="preuves/agenda.png",
            desc="Tenu par Éléonore Lambert. Mercredi : « Réception des donateurs, 19 h – 22 h ».",
            detail="La réception s'est terminée à 22 h précises, et non à 23 h.",
        ),
    }

    def a(code):
        return code in store.preuves

    def obtenir(code, silencieux=False):
        """Ajoute une preuve au Dossier et l'annonce à l'écran."""
        if code in store.preuves:
            return
        store.preuves.append(code)
        if not silencieux:
            renpy.call_screen("nouvelle_preuve", code=code)

    def examiner(code):
        store.preuves_examinees.add(code)

    ############################################################################
    ## Fiches des personnages (onglet du Dossier)
    ############################################################################

    FICHES = [
        dict(tag="clara", nom="Clara Morel", age="18 ans", role="Arts et lettres, première année",
             texte=[(None, "Timide, attentive, elle dessine tout ce qu'elle voit. Ses parents attendent beaucoup d'elle."),
                    ("drame", "Accusée du meurtre d'Iris Delaunay. Elle affirme être partie du laboratoire avant 22 h.")]),
        dict(tag="iris", nom="Iris Delaunay", age="20 ans", role="Chimie, troisième année — la Gazette",
             texte=[(None, "Brillante, pressée, elle semble toujours savoir ce qui va arriver."),
                    ("drame", "Retrouvée morte au laboratoire mercredi soir."),
                    ("lettre_iris", "Elle avait déjà vécu ces jours. Plusieurs fois.")]),
        dict(tag="dorian", nom="Dorian Varga", age="35 ans", role="Professeur de droit pénal",
             texte=[(None, "Exigeant, froid en apparence. Il déteste l'injustice et l'incompétence."),
                    ("drame", "Il défend Clara et vous a choisi·e comme assistant·e.")]),
        dict(tag="isabella", nom="Isabella Varga", age="45 ans", role="Directrice de l'Académie",
             texte=[(None, "Dirige Valcourt d'une main de fer. Sait tout de tous. Protège l'Académie à tout prix."),
                    ("marche", "Elle vous a proposé un marché pour enterrer l'affaire.")]),
        dict(tag="eleonore", nom="Éléonore Lambert", age="28 ans", role="Assistante de la directrice",
             texte=[(None, "Efficace, discrète, loyale. Gère l'emploi du temps et les clés de la direction."),
                    ("soupcon_eleonore", "Elle a menti sur son emploi du temps du mercredi soir.")]),
        dict(tag="malo", nom="Malo Deschamps", age="26 ans", role="Inspecteur de police",
             texte=[(None, "Débrouillard, cynique, loyal. Déteste ceux qui se croient au-dessus des lois."),
                    ("piste_azur", "Il enquête sur une drogue qui circule parmi les étudiants : l'Azur.")]),
        dict(tag="bernier", nom="Odile Bernier", age="62 ans", role="Bibliothécaire",
             texte=[(None, "Gardienne de la réserve. Connaît chaque livre, et chaque légende.")]),
        dict(tag="amelie", nom="Amélie Roux", age="19 ans", role="Rédactrice en chef de la Gazette",
             texte=[(None, "Bavarde, généreuse, toujours un appareil photo autour du cou.")]),
        dict(tag="nathan", nom="Nathan Roussel", age="21 ans", role="Chimie, troisième année",
             texte=[(None, "Brillant et silencieux. On dit qu'il a des dettes."),
                    ("aveu_nathan", "Il fabrique l'Azur sous la contrainte.")]),
        dict(tag="lucas", nom="Lucas Ferrand", age="19 ans", role="Droit, deuxième année",
             texte=[(None, "Sportif au grand cœur, colocataire de Hugo.")]),
        dict(tag="hugo", nom="Hugo Martel", age="19 ans", role="Droit, deuxième année",
             texte=[(None, "Épuisé par la pression des examens."),
                    ("malaise_hugo", "A fait un malaise au bal d'automne. Hors de danger.")]),
    ]

    def fiche_connue(f):
        return f["tag"] in store.persos_rencontres

    ############################################################################
    ## Fins
    ############################################################################

    FINS = [
        ("erreur", "Erreur judiciaire", "Clara est renvoyée devant la cour d'assises."),
        ("silence", "Le Silence de Valcourt", "La vérité a été vendue contre une bourse."),
        ("mauvais", "Le Mauvais Coupable", "Un innocent paie, l'Azur circule toujours."),
        ("veritas", "Veritas", "La vérité éclate, mais elle a coûté cher."),
        ("sept_jours", "Les Sept Jours", "La vraie fin."),
        ("page_blanche", "La Page blanche", "Le mercredi recommence, encore et encore."),
        ("port_engloutit", "Le port engloutit tout", "Le Capitaine a gagné. La Gazette s'est tue."),
        ("prix_bourse", "Le Prix d'une bourse", "La protection d'Halvard, contre le silence."),
        ("lumieres_port", "Les Lumières du port", "Le Capitaine est tombé, devant tout Valcourt."),
    ]

    def debloquer_fin(code):
        if persistent.fins is None:
            persistent.fins = set()
        persistent.fins.add(code)
        renpy.save_persistent()

    def fin_obtenue(code):
        return persistent.fins is not None and code in persistent.fins

    ############################################################################
    ## Jours
    ############################################################################

    JOURS = {1: "Lundi", 2: "Mardi", 3: "Mercredi", 4: "Jeudi", 5: "Vendredi", 6: "Samedi", 7: "Dimanche"}
    DATES = {1: "13 octobre", 2: "14 octobre", 3: "15 octobre", 4: "16 octobre", 5: "17 octobre",
             6: "18 octobre", 7: "19 octobre"}

    def nom_jour():
        return JOURS.get(store.jour, "")

default persos_rencontres = set()
default persistent.fins = set()
default persistent.videos_vues = set()
default persistent.fini_une_fois = False

init python:

    def rencontrer(*tags):
        for t in tags:
            store.persos_rencontres.add(t)
