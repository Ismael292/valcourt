## mise_en_scene.rpy — musique, ambiances, météo, vidéos, téléphone.

init python:
    renpy.music.register_channel("ambiance", "sfx", loop=True, tight=True)
    renpy.music.register_channel("ambiance2", "sfx", loop=True, tight=True)

    def musique_jouer(nom, fondu=2.0):
        """Joue une piste de audio/musique/ en fondu, sans la relancer si elle passe déjà."""
        renpy.music.play("audio/musique/%s.ogg" % nom, channel="music", fadein=fondu, fadeout=fondu, if_changed=True)

    def musique_stop(fondu=2.0):
        renpy.music.stop(channel="music", fadeout=fondu)

    def ambiance(nom, fondu=1.5, canal="ambiance"):
        if nom:
            renpy.music.play("audio/ambiances/%s.ogg" % nom, channel=canal, fadein=fondu, fadeout=fondu, if_changed=True)
        else:
            renpy.music.stop(channel=canal, fadeout=fondu)

    def son(nom):
        renpy.sound.play("audio/sons/%s.ogg" % nom)

    def video(code):
        """Joue une scène vidéo plein écran (un clic la passe) et la débloque dans les Extras."""
        if persistent.videos_vues is None:
            persistent.videos_vues = set()
        persistent.videos_vues.add(code)
        renpy.music.stop(channel="ambiance", fadeout=0.5)
        renpy.movie_cutscene("movies/%s.webm" % code, stop_music=True)

################################################################################
## Météo et lumière (images superposées aux décors)
################################################################################

image pluie = SnowBlossom("gui/goutte.png", count=110, border=80, xspeed=(-60, -30), yspeed=(900, 1200), start=0.0, fast=True, horizontal=False)
image pluie_fine = SnowBlossom("gui/goutte.png", count=45, border=80, xspeed=(-40, -20), yspeed=(700, 900), start=0.0, fast=True, horizontal=False)
image poussiere = SnowBlossom("gui/poussiere.png", count=26, border=40, xspeed=(-12, 12), yspeed=(-14, -4), start=0.0, fast=True, horizontal=True)
image confettis_or = SnowBlossom("gui/paillette.png", count=40, border=40, xspeed=(-20, 20), yspeed=(30, 70), start=0.0, fast=True, horizontal=True)

image grain:
    "gui/grain1.png"
    pause 0.06
    "gui/grain2.png"
    pause 0.06
    "gui/grain3.png"
    pause 0.06
    "gui/grain4.png"
    pause 0.06
    repeat

image vignette = "gui/vignette.png"
image vignette_forte = "gui/vignette_forte.png"

## Gyrophares : un voile bleu puis rouge qui pulse.
image gyrophares:
    Solid("#1f4fd680")
    alpha 0.0
    block:
        linear .25 alpha 0.6
        linear .25 alpha 0.0
        Solid("#d61f1f80")
        linear .25 alpha 0.55
        linear .25 alpha 0.0
        Solid("#1f4fd680")
        repeat

## Néon qui grésille.
image neon_gresille:
    Solid("#00000000")
    block:
        pause 1.6
        Solid("#000000c0")
        pause 0.05
        Solid("#00000000")
        pause 0.08
        Solid("#000000a0")
        pause 0.04
        Solid("#00000000")
        pause 2.4
        repeat

## Éclair d'orage.
image eclair:
    Solid("#ffffff")
    alpha 0.0
    pause 0.2
    linear 0.04 alpha 0.85
    linear 0.12 alpha 0.0
    linear 0.03 alpha 0.6
    linear 0.4 alpha 0.0

## Halo doré (souvenir, Livre).
image halo_or:
    "gui/halo.png"
    xalign 0.5 yalign 0.5
    alpha 0.0
    linear 1.2 alpha 0.8
    block:
        ease 2.0 alpha 0.55 zoom 1.04
        ease 2.0 alpha 0.8 zoom 1.0
        repeat

## Le marque-page en laiton, montré en gros plan.
image marque_page = "gui/marque_page.png"
image livre_ferme = "gui/livre.png"

## Silhouette noire de l'ombre qui s'enfuit.
image ombre_fuite:
    "gui/silhouette.png"
    xalign 0.85 yalign 1.0 alpha 0.0
    linear 0.15 alpha 0.9
    linear 0.6 xalign 1.25 alpha 0.0

################################################################################
## Petits rituels réutilisables
################################################################################

label titre(numero, nom, date, sous_titre=""):
    $ poser_heure("")
    window hide
    $ son("horloge")
    call screen titre_jour(numero, nom, date, sous_titre)
    return

label sms(contact, messages, heure=""):
    window hide
    $ son("vibreur")
    call screen telephone(contact, messages, heure)
    return
