## rejouabilite.rpy — le monde change à chaque partie, le Livre se souvient,
## et chaque fin est notée : Veritas, Justitia, Libertas. Jamais les trois à la fois.

default monde = {}
default persistent.parties = 0
default persistent.deja_vu = set()
default persistent.meilleures_notes = {}

init python:
    import random as _rnd

    MOTS_DEVISE = [("veritas", "premier"), ("justitia", "deuxième"), ("libertas", "troisième")]

    def tirer_monde():
        """Les détails qui changent d'une partie à l'autre."""
        r = _rnd.Random()
        mdp, rang = r.choice(MOTS_DEVISE)
        return dict(
            mdp=mdp, rang_mdp=rang,
            cache_usb=r.choice(["livre", "gazette"]),
            epingle=r.choice(["paillasse", "escalier"]),
            malaise=r.choice([4, 5]),
            graine=r.randint(1000, 9999),
        )

    def M(cle, defaut=None):
        return store.monde.get(cle, defaut)

    def deja_vu(cle):
        return persistent.deja_vu is not None and cle in persistent.deja_vu

    def retenir_deja_vu():
        """En fin de partie, le Livre garde une trace de ce que l'on a compris."""
        if persistent.deja_vu is None:
            persistent.deja_vu = set()
        for f, cle in (("lettre_iris", "ariane"), ("soupcon_eleonore", "eleonore"), ("quai7_tot", "quai7"),
                       ("livre_trouve", "livre"), ("aveu_clara", "clara_ressortie"), ("dorian_appel_connu", "dorian_appel")):
            if fait(f):
                persistent.deja_vu.add(cle)
        if a("usb"):
            persistent.deja_vu.add("quai7")
        renpy.save_persistent()

    ############################################################################
    ## Veritas, Justitia, Libertas
    ############################################################################

    BASES = {"erreur": (1, 0, 2), "silence": (0, 1, 4), "mauvais": (1, 1, 2), "veritas": (3, 3, 2),
             "sept_jours": (4, 4, 2), "page_blanche": (0, 0, 0),
             "port_engloutit": (2, 0, 1), "prix_bourse": (1, 0, 3), "lumieres_port": (4, 4, 2)}

    def notes_fin(code):
        v, j, l = BASES.get(code, (1, 1, 1))
        # Veritas : la vérité a-t-elle éclaté, entièrement ?
        if len(store.contradictions) >= 4:
            v += 1
        if fait("clara_temoin_proces") or fait("aveu_clara"):
            v += 1
        if fait("isabella_accusee"):
            v -= 1
        # Justitia : les innocents protégés, les coupables jugés.
        if fait("isabella_innocentee"):
            j += 1
        if fait("aveu_nathan") or fait("reseau_demantele"):
            j += 1
        if fait("isabella_accusee"):
            j -= 2
        # Libertas : sa propre vie — la bourse, la famille, les amis.
        if not fait("bourse_suspendue") and moyenne() >= 12:
            l += 1
        if store.appels_manques == 0:
            l += 1
        if fait("aide_maman"):
            l += 1
        if niveau("clara") >= 8:
            l += 1
        if store.nuits_blanches >= 2:
            l -= 1
        if fait("bourse_suspendue") and code != "silence":
            l -= 1
        prix = None
        if store.boucle > 1:
            ## Le Livre réclame toujours un prix.
            l = min(l, 3)
            prix = "Le Livre réclame toujours un prix."
        elif code == "silence":
            v, j = min(v, 0), min(j, 1)
        borne = lambda x: max(0, min(5, x))
        return borne(v), borne(j), borne(l), prix

    def ce_qui_aurait_pu_etre(code):
        P = []
        if not fait("marque_page"):
            P.append("Un marque-page en laiton attendait d'être accepté.")
        if not fait("numero_iris"):
            P.append("Mercredi soir, Iris aurait voulu pouvoir vous écrire.")
        if fait("clara_mensonge_connu") and not fait("aveu_clara"):
            P.append("Clara n'attendait qu'un signe de confiance pour tout dire.")
        if store.appels_manques > 0:
            P.append("Quelqu'un, chez vous, a attendu votre appel.")
        if not a("temoignage"):
            P.append("Au quai 7, un étudiant voulait parler à quelqu'un.")
        if fait("bourse_suspendue"):
            P.append("Votre bourse aurait pu être sauvée.")
        if not fait("isabella_temoin") and code not in ("silence",):
            P.append("La directrice aurait pu devenir une alliée.")
        if a("lettre_anonyme") and not fait("lettre_machine"):
            P.append("La lettre anonyme portait une signature invisible.")
        if code != "sept_jours":
            P.append("Il existe un mercredi où Iris ne meurt pas.")
        else:
            P.append("Même le plus beau des mercredis a coûté quelque chose.")
        if not P:
            P.append("Vous avez tout vu. Ou presque.")
        r = _rnd.Random(store.monde.get("graine", 0))
        r.shuffle(P)
        return P[:3]

    def etoiles(n):
        return "●" * n + "○" * (5 - n)

screen notes_de_fin(code):
    $ v, j, l, prix = notes_fin(code)
    vbox:
        xalign 0.5
        spacing 6
        hbox:
            xalign 0.5
            spacing 50
            for nom, n in (("VERITAS", v), ("JUSTITIA", j), ("LIBERTAS", l)):
                vbox:
                    text nom font F_TITRE size 20 color LAITON kerning 4 xalign 0.5
                    text etoiles(n) font "DejaVuSans.ttf" size 24 color LAITON_CLAIR xalign 0.5
        if prix:
            text prix font F_DISPLAY_IT size 22 color "#d9a99f" xalign 0.5
        null height 10
        text "CE QUI AURAIT PU ÊTRE" font F_TITRE size 16 color DOUX kerning 4 xalign 0.5
        for ligne in ce_qui_aurait_pu_etre(code):
            text "— " + ligne font F_DISPLAY_IT size 22 color "#cbbfa8" xalign 0.5
        null height 6
        text "Parties jouées : %d · Fins découvertes : %d / %d" % (persistent.parties, len(persistent.fins or ()), len(FINS)) font F_MACHINE size 15 color DOUX xalign 0.5
